﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Threading;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;
using DALSA.SaperaLT.SapClassBasic;
using DALSA.SaperaProcessing.CPro;
using AK.GP.ICW;
using AK.Tools;
using AK.ICW.Proc;
using AK.Define.PSS;

namespace AK.HW.Camera
{
    //滨松相机
    public class CameraHama : ICameraTDI
    {
        private static CameraHama _instance = null;
        public static CameraHama Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new CameraHama();
                return _instance;
            }
        }

        [DllImport("msvcrt.dll", EntryPoint = "memcpy", CallingConvention = CallingConvention.Cdecl, SetLastError = false)]
        public static extern IntPtr memcpy(IntPtr dest, IntPtr src, int count);

        private SerialPort _comCamera = null;
        private SapAcquisition _sapAcquisition = null;
        private SapBuffer _sapBuffer = null;
        private SapAcqToBuf _sapXfer = null;
        private SapLocation _sapLocation = null;
        private AutoResetEvent _evtLineReady = new AutoResetEvent(false);
        private bool _bScanDirection = false;
        private int _iRunID = 0;
        private volatile int _iChannel = 0;
        private volatile int _iRow = 0;
        private HashSet<int> _hashImageList = new HashSet<int>();
        private ParamBaseAOI _paramAOI = null;

        private List<ScanRowItem> _lsScanItem = null;
        private volatile int _iColIdx = 0;
        private Dictionary<int, int> _dictRowAcqIdxCol = new Dictionary<int, int>();  //当前行待采集列表
        private volatile int _iRowScanFrameNum = 0;
        private volatile int _iBufferIndex = 0;

        public CameraHama()
        {
        }
        ~CameraHama()
        {
            Uninitialize();
        }


        /// 初始化
        public bool Initialize(string sType)
        {
            if (sType == "DF")
                _paramAOI = GPICW.ParamDFAOI;
            else if (sType == "PL")
                _paramAOI = GPICW.ParamPLAOI;
            else if (sType == "PLX")
                _paramAOI = GPICW.ParamPLXAOI;
            else if (sType == "DF2")
                _paramAOI = GPICW.ParamDF2AOI;
            else
                _paramAOI = GPICW.ParamBFAOI;
            string sCcfFileName = Application.StartupPath + "\\" + _paramAOI.CcfFile;
            bool res = InitCamera(sCcfFileName, _paramAOI.CameraPort, _paramAOI.ImgWidthOri, _paramAOI.FrameCount);

            ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"Hama相机初始化结果:{res},COM:{_paramAOI.CameraPort},W：{_paramAOI.ImgWidthOri}，Frame:{_paramAOI.FrameCount}");
            return res;

        }

        /// <summary>
        /// 反初始化
        /// </summary>
        public void Uninitialize()
        {
            FreeCamera();
        }


        //public bool OnAlgoEvent(string sEventType, params object[] aEventParam)
        //{
        //    if (aEventParam.Length <= 0)
        //        return false;
        //    IntPtr hPack = (IntPtr)aEventParam[0];
        //    RunManager.Instance.OnPackReceived(hPack, IntPtr.Zero);
        //    return true;
        //}

        //相机外触发设置：
        //AMD T---tdi mode
        //TMD E---external control
        //SMD N---normal mode
        //ADS 12---12bit
        //ESC I---Camera link CC1
        //ATP N—negative
        //TRD R--REVERSE


        /// <summary>
        /// 初始化相机
        /// </summary>
        /// <param name="sCcfFile">CCF文件</param>
        /// <param name="sCameraPort">相机串口</param>
        /// <param name="iFrameLines">帧行数</param>
        /// <param name="iFrameCount">帧数</param>
        /// <returns></returns>
        private bool InitCamera(string sCcfFile, string sCameraPort, int iFrameLines, int iFrameCount)
        {
            //打开相机串口
            int iTryNum = 3;
            while (iTryNum > 0)
            {
                iTryNum--;
                try
                {
                    _comCamera = new SerialPort();
                    _comCamera.PortName = sCameraPort;
                    //_comCamera.BaudRate = 115200;
                    _comCamera.BaudRate = 38400;
                    _comCamera.DataBits = 8;
                    _comCamera.StopBits = StopBits.One;
                    _comCamera.NewLine = "\r";
                    _comCamera.Parity = Parity.None;  //新增，原来没有。20230310
                    _comCamera.DataReceived += new SerialDataReceivedEventHandler(OnDataReceived);
                    _comCamera.Open();
                    if (_comCamera.IsOpen)
                        break;
                }
                catch (System.Exception ex)
                {
                    //ZlxgLog.Instance.WriteLog("HAMA打开串口失败"+ex.ToString());
                    ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, "HAMA打开串口失败", ex);
                    _comCamera.Close();
                    _comCamera.Dispose();
                    _comCamera = null;
                    Thread.Sleep(1000);
                    continue;
                }
            }
            if (_comCamera == null)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Warn, "HAMA打开串口失败");

                return false;
            }
            if (!_comCamera.IsOpen)
                return false;




            //相机TDI模式
            //dyy 由于tdi相机某个时刻不能切换到线阵模式，所有多次执行了同样的指令来切换，效果带测试
            Thread.Sleep(100);
            _comCamera.Write($"AMD {_paramAOI.AMDModel}\r");

            //相机外同步模式
            Thread.Sleep(100);
            _comCamera.Write($"TMD {_paramAOI.TMDModel}\r");
            Thread.Sleep(100);
            // _comCamera.Write("ATP N\r");
            _comCamera.Write($"ATP {_paramAOI.ATP}\r");
            Thread.Sleep(100);
            //  _comCamera.Write("TRD R\r");//反向扫描

            _comCamera.Write($"TRD {_paramAOI.TRD}\r");

            Thread.Sleep(100);

            _comCamera.Write($"SMD {_paramAOI.SMDModel}\r");
            Thread.Sleep(100);

            _comCamera.Write($"ADS {_paramAOI.ADS}\r");
            Thread.Sleep(100);

            _comCamera.Write($"ESC {_paramAOI.ESCModel}\r");
            Thread.Sleep(100);

            _comCamera.Write($"SPX {_paramAOI.SPX}\r");
            Thread.Sleep(100);

            _comCamera.Write($"CEG {_paramAOI.CEG}\r");
            Thread.Sleep(100);

            Thread.Sleep(100);
            _comCamera.Write("?TRD\r");

            //获取相机参数
            //Thread.Sleep(100);
            //_comCamera.Write("gcp\r\n");

            //Thread.Sleep(100);
            //m_comCamera.Write("scd 1\r\n");//正向扫描

            //设置采集参数
            //string sServerName = "Xcelera-HS_PX8_1";
            //string sServerName = "Xtium2-CLHS_PX8_1";
            string sServerName = _paramAOI.CameraServerName;

            int nResourceIndex = 0;

            _sapLocation = new SapLocation(sServerName, nResourceIndex);
            _sapAcquisition = new SapAcquisition(_sapLocation, sCcfFile);

            // 创建采集对象
            if (_sapAcquisition != null && !_sapAcquisition.Initialized)
            {
                if (_sapAcquisition.Create() == false)
                {
                    ZlxgLog.Instance.WriteLog(Log4NetLevel.Fatal, "HAMA _sapAcquisition 创建对象失败");

                    DestroyObjects();
                    return false;
                }
            }

            //采集行数
            _sapAcquisition.SetParameter(SapAcquisition.Prm.CROP_HEIGHT, iFrameLines, true);

            //_sapAcquisition.SetParameter(SapAcquisition.Cap.LINESCAN_DIRECTION)
            //_sapAcquisition.SetParameter(SapAcquisition.Cap.PIXEL_DEPTH)

            //申请Buffers
            if (SapBuffer.IsBufferTypeSupported(_sapLocation, SapBuffer.MemoryType.ScatterGather))
                _sapBuffer = new SapBufferWithTrash(iFrameCount, _sapAcquisition, SapBuffer.MemoryType.ScatterGather);
            else
                _sapBuffer = new SapBufferWithTrash(iFrameCount, _sapAcquisition, SapBuffer.MemoryType.ScatterGatherPhysical);

            // 创建SapAcqToBuf
            _sapXfer = new SapAcqToBuf(_sapAcquisition, _sapBuffer);

            //数据回调事件
            _sapXfer.Pairs[0].EventType = SapXferPair.XferEventType.EndOfFrame;
            _sapXfer.XferNotify += new SapXferNotifyHandler(Data_XferNotify);
            _sapXfer.XferNotifyContext = _sapBuffer;

            //m_pBuf[nIndex]->SetState(m_pBuf[nIndex]->GetIndex(),SapBuffer::StateEmpty);

            //状态回调事件
            _sapAcquisition.SignalNotify += new SapSignalNotifyHandler(GetSignalStatus);
            _sapAcquisition.SignalNotifyContext = this;

            //创建对象
            if (!CreateObjects())
            {
                DestroyObjects();
                return false;
            }
            return SetCameraScanDirection(_paramAOI.FirstScanDirection);

        }

        public bool UpdateCameraGain(int iGain)
        {
            //打开相机串口
            ParamBaseAOI _paramAOI = GPICW.ParamPLAOI;
            int iTryNum = 3;
            while (iTryNum > 0)
            {
                iTryNum--;
                try
                {
                    if (_comCamera == null)
                    {
                        _comCamera = new SerialPort();
                        _comCamera.PortName = _paramAOI.CameraPort;
                        //_comCamera.BaudRate = 115200;
                        _comCamera.BaudRate = 38400;
                        _comCamera.DataBits = 8;
                        _comCamera.StopBits = StopBits.One;
                        _comCamera.NewLine = "\r";
                        _comCamera.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(OnDataReceived);

                    }
                    else
                    {
                        if (!_comCamera.IsOpen)
                        {
                            _comCamera.Open();
                        }
                        Thread.Sleep(100);
                        _comCamera.Write($"CEG {iGain}\r");
                        break;
                    }

                }
                catch (System.Exception ex)
                {
                    if (_comCamera != null)
                    {
                        _comCamera.Close();
                        _comCamera.Dispose();
                        _comCamera = null;
                        Thread.Sleep(1000);
                    }
                    continue;
                }
            }
            return true;
        }
        /// <summary>
        /// 释放相机
        /// </summary>
        private void FreeCamera()
        {
            if (_comCamera == null)
                return;
            if (_comCamera.IsOpen)
                _comCamera.Close();
            _comCamera = null;
            DestroyObjects();
        }


        //相机复位功能
        public bool CAMERA_RESET(bool bResetServer, string sType = "")
        {
            bool bRet = false;
            try
            {
                Thread.Sleep(1000);
                StopGrab();
                Thread.Sleep(1000);
                FreeCamera();
                Thread.Sleep(1000);
                if (sType != "") UpdateParam(sType);
                if (bResetServer)
                {
                    //string sServerName = "Xcelera-HS_PX8_1";
                    //string sServerName = "Xtium2-CLHS_PX8_1";
                    string sServerName = _paramAOI.CameraServerName;
                    int nResourceIndex = 0;
                    SapLocation sapLocation = new SapLocation(sServerName, nResourceIndex);
                    SapManager.ResetServer(sapLocation, true);
                    Thread.Sleep(1000);
                }

                string sCcfFileName = Application.StartupPath + "\\" + _paramAOI.CcfFile;

                bRet = InitCamera(sCcfFileName, _paramAOI.CameraPort, _paramAOI.ImgWidthOri, _paramAOI.FrameCount);
                Thread.Sleep(1000);
            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, "Hama CAMERA_RESET Exception", ex);
            }
            return bRet;
        }

        /// <summary>
        /// 创建对象
        /// </summary>
        /// <returns></returns>
        private bool CreateObjects()
        {
            if (_sapBuffer != null && !_sapBuffer.Initialized)
            {
                if (!_sapBuffer.Create())
                {
                    DestroyObjects();
                    return false;
                }
                _sapBuffer.Clear();
            }
            if (_sapXfer != null && !_sapXfer.Initialized)
            {
                if (!_sapXfer.Create())
                {
                    DestroyObjects();
                    return false;
                }
            }
            return true;
        }


        private object _objLockFree = new object();
        /// <summary>
        /// 销毁对象
        /// </summary>
        private void DestroyObjects()
        {
            try
            {
                lock (_objLockFree)
                {
                    if (_sapXfer != null)
                    {
                        if (_sapXfer.Initialized)
                            _sapXfer.Destroy();
                        _sapXfer.Dispose();
                        _sapXfer = null;
                    }
                    if (_sapBuffer != null)
                    {
                        if (_sapBuffer.Initialized)
                            _sapBuffer.Destroy();
                        _sapBuffer.Dispose();
                        _sapBuffer = null;
                    }
                    if (_sapAcquisition != null)
                    {
                        if (_sapAcquisition.Initialized)
                            _sapAcquisition.Destroy();
                        _sapAcquisition.Dispose();
                        _sapAcquisition = null;
                    }
                    if (_sapLocation != null)
                    {
                        _sapLocation.Dispose();
                        _sapLocation = null;
                    }
                }
            }
            catch (System.Exception ex)
            {
            }
        }

        string sRecvText = "";
        AutoResetEvent comMsgEvent = new AutoResetEvent(false);
        /// <summary>
        /// 串口数据接收
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnDataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                sRecvText = _comCamera.ReadLine();
                this.RespondMessageEvent?.Invoke(sRecvText);
                comMsgEvent.Set();
            }
            catch (System.Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"{ex.Message},{ex.StackTrace}");
                return;
            }
            string[] split = sRecvText.Split(new char[] { ':' });
            if (split.Length != 2)
                return;
            string sItemName = split[0].Trim();
            string sItemValue = split[1].Trim();
        }


        /// <summary>
        /// 全幅扫描开始
        /// </summary>
        /// <param name="hPack"></param>
        public void CAMERA_SCANBEGIN(int iRunID, int iChannel)
        {
            _iRunID = iRunID;
            _iChannel = iChannel;
            _iRow = -1;

            _lsScanItem = null;
            if (_paramAOI.OptimizeScanPath && _paramAOI.DictExtraParam.ContainsKey("ScanPath"))
                _lsScanItem = (List<ScanRowItem>)_paramAOI.DictExtraParam["ScanPath"];


            if (_paramAOI is ParamDFAOI && (_paramAOI as ParamDFAOI).ScanWithBF
             || _paramAOI is ParamPLAOI && (_paramAOI as ParamPLAOI).ScanWithBF
             || _paramAOI is ParamPLXAOI && (_paramAOI as ParamPLXAOI).ScanWithBF)
            {
                _lsScanItem = (List<ScanRowItem>)GPICW.ParamBFAOI.DictExtraParam["ScanPath"];
            }

            ImageProcess.Instance.ScanBegin(iRunID, iChannel);
            _hashImageList.Clear();

            GPICW.ReScanLine = false;
            GPICW.ReScanLineCount = 0;
        }


        /// 全幅扫描结束
        public void CAMERA_SCANEND(int iRunID, int iChannel)
        {
            ImageProcess.Instance.ScanEnd(iRunID, iChannel);
        }



        /// 单行扫描开始
        public bool CAMERA_LINEBEGIN(int iRunID, int iChannel, int iRow)
        {
            AcqCProImageBuffer acqBuf = AcqCProImageBuffer.Instance(iChannel);
            CameraTDI.GetAcqImageList(_paramAOI, _lsScanItem, iRow, ref _dictRowAcqIdxCol);
            _iRowScanFrameNum = _dictRowAcqIdxCol.Count;
            //不是自动分配内存,解决内存不够的情况
            if (!acqBuf.AutoResize)
            {
                while (acqBuf.BufferSize < _paramAOI.FrameCount)
                {
                    Thread.Sleep(1000);
                    // Debug.WriteLine($"$$$###%%%-Waiting For AcqCProImageBuffer : {acqBuf.BufferSize} / {acqBuf.BufferTotal}");
                    ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"$$$###%%%-Waiting For AcqCProImageBuffer : {acqBuf.BufferSize} / {acqBuf.BufferTotal}");
                }
            }

            _iRow = iRow;
            _bScanDirection = _paramAOI.FirstScanDirection;
            if ((int)_paramAOI.ScanMode == 0 || (int)_paramAOI.ScanMode == 2)
            {
                if (iRow % 2 == 0)
                    _bScanDirection = _paramAOI.FirstScanDirection;
                else
                    _bScanDirection = !_paramAOI.FirstScanDirection;
            }
            else if ((int)_paramAOI.ScanMode == 1)
            {
                _bScanDirection = _paramAOI.FirstScanDirection;
            }
            SetCameraScanDirection(_bScanDirection);
            _evtLineReady.Reset();

            _iColIdx = 0;
            _iBufferIndex = 0;
            StartGrab(_iRowScanFrameNum);
            Thread.Sleep(100); //to avoid frame lost..
            return true;
        }


        /// <summary>
        /// 设置弓形扫描时的相机方向
        /// </summary>
        /// <param name="Direction">Reverse Forward</param>
        private bool SetCameraScanDirection(bool bDirection = true)
        {
            try
            {
                if (bDirection)
                {
                    _comCamera.Write("TRD F\r");//正向扫描
                    //Thread.Sleep(100);
                    //_comCamera.Write("TRD F\r");//正向扫描
                    int count = 0;
                    do
                    {  //询问是否设置成功
                        comMsgEvent.Reset();
                        Thread.Sleep(100);
                        _comCamera.Write("?TRD\r");
                        count++;
                        if (comMsgEvent.WaitOne(1000))
                        {
                            if (this.sRecvText.Contains("TRD F"))
                            {
                                if (count > 1)
                                    ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"After {count} times try,TRD F succeed.");
                                return true;
                            }
                            else
                            {
                                Thread.Sleep(100);
                                _comCamera.Write("TRD F\r");//正向扫描
                                ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"{count} times try,TRD F sent.");
                            }
                        }
                        else
                            ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"After {count} times try,TRD F timeout.");
                    } while (count < 5);
                    if (count >= 5)
                    {
                        ZlxgLog.Instance.WriteLog(Log4NetLevel.Warn, $"After {count} times try. TRD F  Failed.");
                        return false;
                    }
                }
                else
                {
                    _comCamera.Write("TRD R\r");//反向扫描
                    //Thread.Sleep(100);
                    //_comCamera.Write("TRD R\r");//反向扫描
                    int count = 0;
                    do
                    {  //询问是否设置成功
                        comMsgEvent.Reset();
                        Thread.Sleep(100);
                        _comCamera.Write("?TRD\r");
                        count++;
                        if (comMsgEvent.WaitOne(1000))
                        {
                            if (this.sRecvText.Contains("TRD R"))
                            {
                                if (count > 1)
                                    ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"After {count} times try,TRD R succeed.");
                                return true;
                            }
                            else
                            {
                                Thread.Sleep(100);
                                _comCamera.Write("TRD R\r");//正向扫描
                            }
                        }
                        else
                            ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"After {count} times try,TRD R timeout.");
                    } while (count < 5);
                    if (count >= 5)
                    {
                        ZlxgLog.Instance.WriteLog(Log4NetLevel.Warn, $"After {count} times try. TRD R  Failed.");
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, "SetCameraScanDirection " + ex.ToString());
                Debug.WriteLine("SetCameraScanDirection Error." + ex.Message);
                return false;
            }
            return true;
        }

        public void SendCommand(string c)
        {
            _comCamera.Write($"{c}\r");//正向扫描
        }

        public delegate void COMRespond(string msg);
        public event COMRespond RespondMessageEvent;



        /// 单行扫描结束
        public void CAMERA_LINEEND(int iRunID, int iChannel, int iRow)
        {
            bool bTimeout = false;
            if (!_evtLineReady.WaitOne(_paramAOI.LineScanTimeout))
            {
                _sapXfer.Abort();
                bTimeout = true;
                GPICW.ReScanLine = true;
            }
            if (GPICW.ReScanLine)
            {
                string sText = "中间丢帧";
                if (bTimeout)
                    sText = "行尾丢帧,超时";
                sText = string.Format("$$$$$$$$######## {0},{1},{2},{3}", sText, _iRunID, _iRow, _iColIdx);
                Debug.WriteLine(sText);
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Warn, sText);
                GPICW.waferlog = sText;
            }
        }

        private bool StartGrab(int iFrameNum)
        {
            _sapBuffer.ResetIndex();
            Thread.Sleep(10);
            return _sapXfer.Snap(iFrameNum);
        }


        private void StopGrab()
        {
            //m_Xfer.Abort();
            _sapBuffer.Clear();
            _sapBuffer.ResetIndex();
        }

        void Data_XferNotify(object sender, SapXferNotifyEventArgs argsNotify)
        {
            if (_iRow > _paramAOI.ScanNum - 1)
                return;
            if (_iColIdx > _iRowScanFrameNum - 1)
                return;
            //int iAcqCount = _iRow * _paramAOI.FrameCount + _iCol;

            //获取图像和顺序号
            SapBuffer buf = argsNotify.Context as SapBuffer;
            //int iBufferIndex = buf.Index;
            int iBufferIndex = _iBufferIndex;
            int iCol = -1;
            lock (_dictRowAcqIdxCol)
            {
                if (_dictRowAcqIdxCol.ContainsKey(_iColIdx))
                    iCol = _dictRowAcqIdxCol[_iColIdx];
            }
            Debug.WriteLine($"-------------------------->$$$%%%### - Data_XferNotify - 1 : ROW:{_iRow},COL:{_iColIdx};INDEX:{iBufferIndex};Width:{buf.Width};Height:{buf.Height}");

            long ltimeAll = Environment.TickCount;
            /*
            //模拟丢帧检测   
            if (_iRow == GPICW.TryLostFrameRow && iBufferIndex == GPICW.TryLostFrameCol && GPICW.TryLostFrameNum > 0) 
            {
                GPICW.TryLostFrameNum--;
                return;
            }
            if (iBufferIndex != _iCol)
            {
                //m_Xfer.Abort();
                _evtLineReady.Set();
                GPICW.ReScanLine = true;
            }
            if (GPICW.ReScanLine)
                return;

            if (_hashImageList.Contains(_iCol))
            {
                //_iCol++;
                Interlocked.Increment(ref _iCol);
                return;
            }
            _hashImageList.Add(_iCol);
            */
            //复制图像
            IntPtr hBuf = IntPtr.Zero;
            buf.GetAddress(buf.Index, out hBuf);
            int iBufWidth = buf.Width;
            int iBufHeight = buf.Height;
            int iBufPitch = buf.Pitch;
            CProImage img = AcqCProImageBuffer.Instance(_iChannel).GetImageBuffer();
            IntPtr hImg = img.GetData();
            int iImgWidth = img.Width;
            int iImgHeight = img.Height;

            int iBytes = 1;
            if (_paramAOI.ColorDepth != EnumColorDepth.Bit8)
                iBytes = 2;
            unsafe
            {
                if (_paramAOI.ImgHeightOri == iBufWidth)  //没有裁切,没有软Binning,直接拷贝到队列Buf（采集和处理图像一样大小）
                {
                    memcpy(hImg, hBuf, iBufWidth * iBufHeight * iBytes);
                }
                else if (_paramAOI.ImgHeightOri < iBufWidth)  //需要裁切,没有软Binning,直接裁切到队列Buf（采集和处理图像一样大小）
                {
                    int iDataOffset = _paramAOI.CCDCropPos;
                    int iDataLength = _paramAOI.ImgHeightOri;
                    if (iDataOffset + iDataLength > iBufWidth)
                        iDataOffset = (iBufWidth - iDataLength) / 2;
                    for (int i = 0; i < _paramAOI.ImgWidthOri; i++)
                    {
                        IntPtr hLineSrc = IntPtr.Add(hBuf, (iDataOffset + iBufWidth * i) * iBytes);
                        IntPtr hLineDst = IntPtr.Add(hImg, iDataLength * i * iBytes);
                        memcpy(hLineDst, hLineSrc, iDataLength * iBytes);
                    }
                }
            }
            ImageInfo info = new ImageInfo();
            info.RunID = _iRunID;
            info.Img = img;
            info.Channel = _iChannel;
            info.Row = _iRow;
            info.Col = -1;
            lock (_dictRowAcqIdxCol)
            {
                if (_dictRowAcqIdxCol.ContainsKey(_iColIdx))
                {
                    info.Col = _dictRowAcqIdxCol[_iColIdx];
                    _dictRowAcqIdxCol.Remove(_iColIdx);
                }
            }
            ImageProcess.Instance.PushImage(info);
            Debug.WriteLine($"-------------------------->$$$%%%### - Data_XferNotify - 3  ROW:{_iRow},COL:{_iColIdx};INDEX:{iBufferIndex};Data_XferNotify_Time:{ltimeAll}");
            if (_iColIdx == _iRowScanFrameNum - 1)
            {
                _evtLineReady.Set();
                _dictRowAcqIdxCol.Clear();
                GPICW.ReScanLineCount = 0;
            }
            else
            {
                Interlocked.Increment(ref _iColIdx);
            }
            Interlocked.Increment(ref _iBufferIndex);
            ltimeAll = Environment.TickCount - ltimeAll;
        }



        /// <summary>
        /// 信号回调
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="argsSignal"></param>
        static void GetSignalStatus(object sender, SapSignalNotifyEventArgs argsSignal)
        {
        }

        public void UpdateParam(string sType)
        {

            if (sType == "DF")
                _paramAOI = GPICW.ParamDFAOI;
            else if (sType == "PL")
                _paramAOI = GPICW.ParamPLAOI;
            else if (sType == "PLX")
                _paramAOI = GPICW.ParamPLXAOI;
            else if (sType == "DF2")
                _paramAOI = GPICW.ParamDF2AOI;
            else
                _paramAOI = GPICW.ParamBFAOI;
        }
    }
}
