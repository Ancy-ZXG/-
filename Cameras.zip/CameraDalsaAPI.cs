﻿/*
 * 双卡采图，明暗场切换，Feature替代Virtual COM设置参数
*/

using AK.FX.Define;
using AK.ICW.Proc;
using AK.Tools;
using ApuDefine;
using DALSA.SaperaLT.SapClassBasic;
//using DALSA.SaperaProcessing.CPro;
using OpenCvSharp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace AK.HW.Camera
{
    public class CameraDalsaAPI : ICameraTDI
    {
        private static Dictionary<int, CameraDalsaAPI> _dicInstance = new Dictionary<int, CameraDalsaAPI>();
        public static CameraDalsaAPI Instance(int Index)
        {
            CameraDalsaAPI camera = null;
            lock (_dicInstance)
            {
                if (!_dicInstance.ContainsKey(Index))
                {
                    camera = new CameraDalsaAPI();
                    camera.Index = Index;
                    _dicInstance.Add(Index, camera);
                }
                else
                {
                    camera = _dicInstance[Index];
                }
            }
            return camera;
        }

        private int Index { get; set; } = 0;
        private SapAcquisition _sapAcquisition = null;
      
        private SapAcqToBuf _sapXfer = null;
        private SapLocation _sapLocation = null;
        private SapBuffer _sapBuffer = null;
        private SapAcqDevice _sapAcqDevice = null;

    
        private string _iRunID = "";
        private int _iChannel = 0;
        private  int _iRow = 0;
        private  int _iColIdx = 0;


        //private int _iCallbackCount = 0;
        private bool _bInitialized = false;
        

        public int _preScanRowNum = 7;
        public int _preScanFrameNum = 7;
        public bool _preScanMode = false;
      
        PreCamParam preCamParam = null;
        public int GetCallBackTimes()
        {
            return _iColIdx;
        }
        public CameraDalsaAPI()
        {
            //_sapAcquisition = new SapAcquisition();
            //_sapLocation = new SapLocation();
            preCamParam = new PreCamParam();
        }
        ~CameraDalsaAPI()
        {
            Uninitialize();
        }

        [System.Runtime.InteropServices.DllImport("kernel32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        public static extern void OutputDebugString(string message);
        /// 初始化
        public bool Initialize(int EnableCh )
        {
            
            UpdateParam(EnableCh);
            if (_bInitialized)
            {
                //if (preCamParam.ccfFile != _paramAOI.CcfFile
                //  || preCamParam.userSet != _paramAOI.UserSet
                //  || preCamParam.PreFrameCount != _paramAOI.FrameCount
                //  || preCamParam.PreImageWidth != _paramAOI.ImgWidth
                //  || preCamParam.PreImageHeight != _paramAOI.ImgHeight
                //  || preCamParam.PreImageDepth != _paramAOI.ColorDepth)
                //{
                Uninitialize();
                //}
                //else
                //    return true;

                Thread.Sleep( 1500 );
            }
            

            string sCcfFileName = Application.StartupPath + "\\config\\" + _paramAOI.CcfFile;

            //_bInitialized = true;
            _bInitialized = InitCamera(sCcfFileName, _paramAOI.UserSet, _paramAOI.ImgHeightOri, _paramAOI.FrameCount);
            ZlxgLog.Instance.WriteLog(Log4NetLevel.Info,$"Camera Init Result:{_bInitialized},CH:{EnableCh},CCF:{sCcfFileName},H:{_paramAOI.ImgHeightOri},Frame:{_paramAOI.FrameCount}");
            //if(_bInitialized)
            //{
            //    preCamParam.ccfFile = _paramAOI.CcfFile;
            //    preCamParam.userSet = _paramAOI.UserSet;
            //    preCamParam.PreFrameCount = _paramAOI.FrameCount;
            //    preCamParam.PreImageWidth = _paramAOI.ImgWidth;
            //    preCamParam.PreImageHeight = _paramAOI.ImgHeight;
            //    preCamParam.PreImageDepth = _paramAOI.ColorDepth;
            //}
            return _bInitialized;
        }

        /// 释放
        public void Uninitialize()
        {
            StopGrab();
            FreeCamera();
            _bInitialized = false;
        }

        private ParamAOI _paramAOI = null;


        public void UpdateParam(int EnableCh)
        {
          
            _paramAOI = FXGP.Instance.GetChannelAOIParam(EnableCh);
        }

     

        /// 初始化相机
        private bool InitCamera(string sCcfFile1, string sUserSet, int iFrameLines, int iFrameCount)
        {
            try
            {

                #region dalsa相机初始化
                SapManager.DisplayStatusMode = SapManager.StatusMode.Log;
                //设置采集参数
                //string sServerName = "Xcelera-HS_PX8_1";
                //string sServerName = "Xtium2-CLHS_PX8_1";
                string sServerName = _paramAOI.CameraServerName;

                // 创建采集对象
                int nResourceIndex = 0;
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "1-InitCamera");
                _sapLocation = new SapLocation(/*"Xtium2-CLHS_PX8_1"*/sServerName, nResourceIndex);
                _sapAcquisition = new SapAcquisition(_sapLocation, sCcfFile1);
                if (_sapAcquisition != null && !_sapAcquisition.Initialized)
                {
                    if (_sapAcquisition.Create() == false)
                    {
                        DestroyObjects();
                        return false;
                    }
                }
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "2-InitCamera");
                //创建设备对象,用于设置Feature
                _sapAcqDevice = new SapAcqDevice(_sapLocation, false);
                if (!_sapAcqDevice.Create())
                {
                    return false;
                }


                _sapAcquisition.SetParameter(SapAcquisition.Prm.CROP_HEIGHT, iFrameLines, true);//采集行数
                                                                                                //Load UserSet
                _sapAcqDevice.SetFeatureValue("UserSetSelector", sUserSet);
                _sapAcqDevice.SetFeatureValue("UserSetLoad", true);
                //FFC
                //_sapAcqDevice.SetFeatureValue("flatfieldCorrectionCurrentActiveSet", sUserSet);
                //_sapAcqDevice.SetFeatureValue("flatfieldCalibrationLoad", true);


                ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "3-InitCamera");
                //申请Buffers
                bool acq0SupportSG = SapBuffer.IsBufferTypeSupported(_sapAcquisition.Location, SapBuffer.MemoryType.ScatterGather);
                if (acq0SupportSG && acq0SupportSG)
                {
                    _sapBuffer = new SapBufferWithTrash( FXGP.Instance.APUSystem.nRamRadio, _sapAcquisition, SapBuffer.MemoryType.ScatterGather);
                    //_sapBuffer = new SapBufferWithTrash();
                    //_buffers = new SapBufferRoi(_sapBuffer);
                    ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "4-1-InitCamera");
                }
                else
                {
                    bool acq0SupportSGP = SapBuffer.IsBufferTypeSupported(_sapAcquisition.Location, SapBuffer.MemoryType.ScatterGatherPhysical);
                    if (acq0SupportSGP)
                    {
                        _sapBuffer = new SapBufferWithTrash(FXGP.Instance.APUSystem.nRamRadio, _sapAcquisition, SapBuffer.MemoryType.ScatterGatherPhysical);
                        //_sapBuffer = new SapBufferWithTrash();
                        //_buffers = new SapBufferRoi(_sapBuffer);
                        ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "4-2-InitCamera");
                    }
                    else
                    {
                        ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "4-3-InitCamera");
                        DestroyObjects();
                        return false;
                    }
                }

                // 创建SapAcqToBuf
                _sapXfer = new SapAcqToBuf(_sapAcquisition, _sapBuffer);

                //数据回调事件
                _sapXfer.Pairs[0].EventType = SapXferPair.XferEventType.EndOfFrame;
                _sapXfer.XferNotify += new SapXferNotifyHandler(Data_XferNotify);
                _sapXfer.XferNotifyContext = _sapBuffer;

                //_sapBuffer.set_State(_sapBuffer.Index,SapBuffer.DataState.Empty);

                //状态回调事件
                _sapAcquisition.SignalNotify += new SapSignalNotifyHandler(GetSignalStatus);
                _sapAcquisition.SignalNotifyContext = this;
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "4-5-InitCamera");
                //创建对象
                if (!CreateObjects())
                {
                    ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "4-5-1-InitCamera");
                    DisposeObjects();
                    return false;
                }
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "4-6-InitCamera");
                #endregion
                return true;
            }
            catch(Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, ex);
                return false;
            }
        }


        /// <summary>
        /// 释放相机
        /// </summary>
        private void FreeCamera()
        {
            DestroyObjects();
        }

        public double MonitorCameraTemperature()
        {
            if (_sapAcqDevice == null)
                return -1;
            string[] sFeatureNames = _sapAcqDevice.FeatureNames;
            double temp = 0;
            _sapAcqDevice.GetFeatureValue("DeviceTemperature", out temp);
            return temp;
        }


        //相机复位功能
        public bool CAMERA_RESET(bool bResetServer, int sType)
        {
            bool bRet = false;
            try
            {
                Thread.Sleep(1000);
                StopGrab();
                Thread.Sleep(1000);
                FreeCamera();
                Thread.Sleep(1000);
                if (sType >0) UpdateParam(sType);
                if (bResetServer)
                {
                    //string sServerName = "Xcelera-HS_PX8_1";
                    //string sServerName = "Xtium2-CLHS_PX8_1";
                    string sServerName = _paramAOI.CameraServerName;
                    int nResourceIndex = 0;
                    SapLocation sapLocation = new SapLocation(sServerName, nResourceIndex);
                    SapManager.ResetServer(sapLocation, true);
                    Thread.Sleep(1000);
                }

                string sCcfFileName = Application.StartupPath + "\\config\\" + _paramAOI.CcfFile;
                bRet = InitCamera(sCcfFileName, _paramAOI.UserSet, _paramAOI.ImgWidthOri,_paramAOI.FrameCount);
                Thread.Sleep(1000);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"CameraDalsa Error:{ex.Message},{ex.StackTrace}");
            }
            return bRet;
        }

        /// <summary>
        /// 创建对象
        /// </summary>
        /// <returns></returns>
        private bool CreateObjects(int iFrameCount = 1)
        {
            //_sapBuffer.Count = iFrameCount;
            //_sapBuffer.Width = _sapAcquisition.XferParams.Width;
            //_sapBuffer.Height = _sapAcquisition.XferParams.Height;
            //_sapBuffer.Format = _sapAcquisition.XferParams.Format;
            //_sapBuffer.PixelDepth = _sapAcquisition.XferParams.PixelDepth;
            if (_sapBuffer != null && !_sapBuffer.Initialized)
            {
                if (!_sapBuffer.Create())
                {
                    DestroyObjects();
                    return false;
                }
                _sapBuffer.ResetIndex();
            }
            //_buffers.SetRoi(0, 0, _sapAcquisition.XferParams.Width, _sapAcquisition.XferParams.Height);
            //if (_buffers != null && !_buffers.Initialized)
            //{
            //    if (_buffers.Create() == false)
            //    {
            //        DestroyObjects();
            //        return false;
            //    }
            //}

            if (_sapXfer != null && !_sapXfer.Initialized)
            {
                if (!_sapXfer.Create())
                {
                    DestroyObjects();
                    return false;
                }
            }

            return true;
        }


        private object _objLockFree = new object();
        /// <summary>
        /// 销毁对象
        /// </summary>
        private void DestroyObjects()
        {
            try
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, " Camera Destroy Objects ");
                lock (_objLockFree)
                {
                    if (_sapXfer != null && _sapXfer.Grabbing)
                        _sapXfer.Abort();

                    if (_sapXfer != null && _sapXfer.Initialized)
                        _sapXfer.Destroy();
                    if (_sapXfer != null) _sapXfer.Dispose();
                    _sapXfer = null;

                    //if (_buffers != null && _buffers.Initialized)
                    //{
                    //    _buffers.Destroy();
                    //}
                    //if (_buffers != null) _buffers.Dispose();
                    //_buffers = null;

                    if (_sapBuffer != null && _sapBuffer.Initialized)
                    {
                        _sapBuffer.Destroy();
                    }
                    if (_sapBuffer != null) _sapBuffer.Dispose();
                    _sapBuffer = null;

                    if (_sapAcquisition != null && _sapAcquisition.Initialized)
                    {
                        _sapAcquisition.Destroy();
                    }
                    if (_sapAcquisition != null) _sapAcquisition.Dispose();
                    _sapAcquisition = null;

                    if (_sapAcqDevice != null && _sapAcqDevice.Initialized)
                    {
                        _sapAcqDevice.Destroy();
                    }
                    if (_sapAcqDevice != null) _sapAcqDevice.Dispose();
                    _sapAcqDevice = null;
                }
            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, "Destroy Objects Failed", ex);
            }
            finally
            {
                _sapXfer = null;
                _sapBuffer = null; 
                _sapAcqDevice = null;
                //_buffers = null;
                _sapAcquisition = null;
            }
        }


        private void DisposeObjects()
        {
            try
            {
                if (_sapXfer != null)
                {
                    _sapXfer.Dispose();
                    _sapXfer = null;
                }
                //if (_buffers != null)
                //{
                //    _buffers.Dispose();
                //    _buffers = null;
                //}
                if (_sapBuffer != null)
                {
                    _sapBuffer.Dispose();
                    _sapBuffer = null;
                }
                if (_sapAcquisition != null)
                {
                    _sapAcquisition.Dispose();
                    _sapAcquisition = null;
                }
            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, "Dispose Objects Failed", ex);
            }
            finally
            {
                _sapXfer = null;
                //_buffers = null;
                _sapBuffer = null;
                _sapAcquisition = null;
            }
        }


        /// 全幅扫描开始
        public bool CAMERA_SCANBEGIN(string iRunID, int iChannel)
        {

            UpdateParam(iChannel);
            _iRunID = iRunID;
            _iChannel = iChannel;
            
            return CAMERA_LINEBEGIN(iRunID, iChannel, 0);
        }


        /// 全幅扫描结束
        /// <param name="hPack"></param>
        public void CAMERA_SCANEND(string iRunID, int iChannel)
        {
            CAMERA_LINEEND(iRunID,iChannel, _iRow);
        }


        /// 单行扫描开始
        public bool CAMERA_LINEBEGIN(string iRunID, int iChannel, int iRow)
        {
            _iRow = iRow;
            
            _iColIdx = 0;
            if(!StartGrab()) return false;
            return true;
        }

        
       
        public void CAMERA_LINEEND(string iRunID, int iChannel, int iRow)
        {
             StopGrab();  
        }

        private bool StartGrab()
        {
            //try
            //{
            //    double dTemp = MonitorCameraTemperature();
            //    //ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"---------------------------------开始采集时相机温度：{dTemp:F}");
            //    //Debug.WriteLine($"{DateTime.Now},{_iRunID},{dTemp}");
            //    using (System.IO.StreamWriter file = new System.IO.StreamWriter($"{AppDomain.CurrentDomain.BaseDirectory}Log\\CameraTemp_{_iChannel}.log", true))
            //    {
            //        file.WriteLine(DateTime.Now.ToString() + $",{_iRunID},{dTemp}");
            //    }
            //}
            //catch (Exception ex)
            //{
            //    ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, ex);
            //}
            lock (grabplock)
            {
                _sapXfer.Abort();

                //_sapBuffer.Clear();

                _sapBuffer.ResetIndex();
                Thread.Sleep(10);

                bool bResult0 = _sapXfer.Grab();

                return bResult0;
            }
                
        }
        private object grabplock = new object();
        private void StopGrab()
        {
            lock(grabplock)
            {
                _sapXfer?.Abort();
            }
            
            //try
            //{
            //    //_sapBuffer.Clear();
            //    double dTemp = MonitorCameraTemperature();
            //    using (System.IO.StreamWriter file = new System.IO.StreamWriter($"{AppDomain.CurrentDomain.BaseDirectory}Log\\CameraTemp_{_iChannel}.log", true))
            //    {
            //        file.WriteLine(DateTime.Now.ToString() + $",{_iRunID},{dTemp}");
            //    }
            //}
            //catch (Exception ex)
            //{
            //    ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, ex);
            //}
            
        }

        public void GetCameraFeature(string featureName, out string featureValue)
        {
            featureValue = "";
            try
            {
                //_comCamera.Write("scd 1\r\n");//正向扫描
                _sapAcqDevice.GetFeatureValue(featureName, out featureValue);//正向扫描

            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, "GetCameraFeature Error." + ex.Message);
            }
        }
        public void SetCameraFeature(string featureName, string featureValue)
        {
            // featureValue = "";
            try
            {
                //_comCamera.Write("scd 1\r\n");//
                _sapAcqDevice.SetFeatureValue(featureName, featureValue);//

            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "SetCameraFeature Error." + ex.Message);
            }
        }
        public void SetCameraFeature(string featureName, bool featureValue)
        {
            // featureValue = "";
            try
            {
                //_comCamera.Write("scd 1\r\n");//
                _sapAcqDevice.SetFeatureValue(featureName, featureValue);//

            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, "SetCameraFeature Error." + ex.Message);
            }
        }
        public void SetCameraFeature(string featureName, float featureValue)
        {
            // featureValue = "";
            try
            {
                //_comCamera.Write("scd 1\r\n");//
                _sapAcqDevice.SetFeatureValue(featureName, featureValue);//

            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, "SetCameraFeature Error." + ex.Message);
            }
        }
        /// 单行扫描结束


        Stopwatch swData_XferNotify = Stopwatch.StartNew();
    
        void Data_XferNotify(object sender, SapXferNotifyEventArgs argsNotify)
        {
            if (argsNotify.Trash)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, _iRunID+"go into Trash...........................");
                return;
            }
          
            //获取图像和顺序号
            SapBuffer buf = argsNotify.Context as SapBuffer;
            
            //复制图像
            IntPtr hBuf = IntPtr.Zero;
            buf.GetAddress(buf.Index, out hBuf);
            int iBufWidth = buf.Width;
            int iBufHeight = buf.Height;
        
            GrabImageInfo info = new GrabImageInfo();
            info.RunID = _iRunID;

            info.Channel = _iChannel;
            info.Row = _iRow;
            info.Col = _iColIdx;

            //ImageProcess.Instance.PushImage(info);

            int iBytes = 1;
            if (_paramAOI.ColorDepth != FX.Define.EnumColorDepth.Bit8)
                iBytes = 2;
            info.CameraImageData = hBuf;
            info.CameraImageWidth = iBufWidth;
            info.CameraImageHeight = iBufHeight;
            info.CameraImageBytes = iBytes;
            info.CameraImageIndex = buf.Index;

            info.subAreaHeight = _paramAOI.SubBlockWidth;
            info.subAreaWidth = _paramAOI.SubBlockWidth;
            info.ValidSubArea = new List<int>() {
                            1, 2, 3, 4,5,6,7,8,9,10,11,12,13,14,15,16 ,
                            17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,
                            33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,
                            49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64
                        };
            ImageCopy.Instance.PushImage(info);

         
            Interlocked.Increment(ref _iColIdx);

            ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"RunID={_iRunID},Image {_iColIdx} Call back Time intervals：{swData_XferNotify.ElapsedMilliseconds}ms");
            //OutputDebugString($"第{_iColIdx}张回调间隔：：{swData_XferNotify.ElapsedMilliseconds}ms, buf.Index:{buf.Index},RunID={_iRunID}");

            swData_XferNotify.Restart();
        }

        /// 信号回调
        static void GetSignalStatus(object sender, SapSignalNotifyEventArgs argsSignal)
        {
            //SapAcquisition.AcqSignalStatus signalStatus = argsSignal.SignalStatus;

            //bool m_IsSignalDetected = (signalStatus != SapAcquisition.AcqSignalStatus.None);
            //if (m_IsSignalDetected == false)
            //    ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "Online... No camera signal detected");
            //else 
            //    ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "Online... Camera signal detected");
        }
      
    }
}
