﻿/*
 * 双卡采图，明暗场切换，Feature替代Virtual COM设置参数
*/

using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Threading;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;
using DALSA.SaperaLT.SapClassBasic;
using DALSA.SaperaProcessing.CPro;
using AK.GP.ICW;
using AK.Tools;
using AK.ICW.Proc;
using AK.Define.PSS;
using AK.AOI.APU;
using System.Threading.Tasks;

namespace AK.HW.Camera
{
    public class CameraDoubleBD : ICameraTDI
    {
        private static CameraDoubleBD _instance = null;
        public static CameraDoubleBD Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new CameraDoubleBD();
                return _instance;
            }
        }

        [DllImport("msvcrt.dll", EntryPoint = "memcpy", CallingConvention = CallingConvention.Cdecl, SetLastError = false)]
        public static extern IntPtr memcpy(IntPtr dest, IntPtr src, int count);

        private SapAcquisition[] _sapAcquisition = null;
        private SapBufferRoi[] _buffers = null;
        private SapAcqToBuf[] _sapXfer = null;
        private SapLocation[] _sapLocation = null;
        private SapBuffer _sapBuffer = null;
        private SapAcqDevice _sapAcqDevice = null;
        private SapAcqDevice _sapAcqDevice2 = null;

        private AutoResetEvent _evtLineReady = new AutoResetEvent(false);
        private bool _bScanDirection = false;
        private int _iRunID = 0;
        private int _iChannel = 0;
        private volatile int _iRow = 0;
        private HashSet<int> _hashImageList = new HashSet<int>();
        private volatile int _iColIdx = 0;
        private Dictionary<int, int> _dictRowAcqIdxCol = new Dictionary<int, int>();  //当前行待采集列表
        private volatile int _iRowScanFrameNum = 0;

        private volatile int _iCallbackCount = 0;
        private volatile int _iBufferIndex = 0;
        private bool _bInitialized = false;
        private string _sType = "";

        bool debug = false;

        public CameraDoubleBD()
        {
            _sapAcquisition = new SapAcquisition[2];
            _buffers = new SapBufferRoi[2];
            _sapXfer = new SapAcqToBuf[2];
            _sapLocation = new SapLocation[2];
        }
        ~CameraDoubleBD()
        {
            Uninitialize();
        }


        /// 初始化
        public bool Initialize(string sType)
        {
            CProManager.errorMode = CProManager.ErrorModeEnum.ErrorNone;

            if (_bInitialized)
                return true;
            _sType = sType;
            UpdateParam(_sType);

            string sCcfFileName = Application.StartupPath + "\\" + _paramAOI.CcfFile;
            string sCcfFileName2 = Application.StartupPath + "\\" + _paramAOI.CcfFile2;

            _bInitialized = InitCamera(sCcfFileName, sCcfFileName2, _paramAOI.UserSet, _paramAOI.ImgWidthOri, _paramAOI.FrameCount);
            return _bInitialized;
        }

        /// 释放
        public void Uninitialize()
        {

            FreeCamera();
            _bInitialized = false;
        }

        private ParamBaseAOI _paramAOI = null;
        private List<ScanRowItem> _lsScanItem = null;

        public void UpdateParam(string sType)
        {
            _paramAOI = GetChannelAOIParam(sType);
        }

        public static ParamBaseAOI GetChannelAOIParam(string sType)
        {
            switch (sType)
            {
                case "DF": return GPICW.ParamDFAOI;
                case "PL": return GPICW.ParamPLAOI;
                case "PLX": return GPICW.ParamPLXAOI;
                case "DF2": return GPICW.ParamDF2AOI;
            }
            return GPICW.ParamBFAOI;
        }
        public static ParamBaseAOI GetChannelAOIParam(int iCH)
        {
            switch (iCH)
            {
                case 1: return GPICW.ParamDFAOI;
                case 2: return GPICW.ParamPLAOI;
                case 3: return GPICW.ParamPLXAOI;
                case 4: return GPICW.ParamDF2AOI;
            }
            return GPICW.ParamBFAOI;
        }

        /// 初始化相机
        private bool InitCameraParaltest(string sCcfFile1, string sCcfFile2, string sUserSet, int iFrameLines, int iFrameCount)
        {
            SapManager.DisplayStatusMode = SapManager.StatusMode.Log;
            //设置采集参数
            //string sServerName = "Xcelera-HS_PX8_1";
            //string sServerName = "Xtium2-CLHS_PX8_1";
            string sServerName = _paramAOI.CameraServerName;

            if (debug) Debug.WriteLine("init camera start...");
            // 创建采集对象
            int nResourceIndex = 0;
            bool acq1SupportSG = false;
            bool acq0SupportSG = false;


            Task<bool> tskLocation1 = Task.Run(() =>
               {
                   _sapLocation[0] = new SapLocation("Xtium2-CLHS_PX8_1", nResourceIndex);
                   _sapAcquisition[0] = new SapAcquisition(_sapLocation[0], sCcfFile1);
                   if (_sapAcquisition[0] != null && !_sapAcquisition[0].Initialized)
                   {
                       if (_sapAcquisition[0].Create() == false)
                       {
                           DestroyObjects();
                           return false;
                       }
                   }
                   if (debug) Debug.WriteLine("location  acquistion 1 over....");
                   //创建设备对象,用于设置Feature
                   _sapAcqDevice = new SapAcqDevice(_sapLocation[0], false);
                   if (!_sapAcqDevice.Create())
                   {
                       return false;
                   }
                   _sapAcquisition[0].SetParameter(SapAcquisition.Prm.CROP_HEIGHT, iFrameLines, true);//采集行数
                                                                                                      //Load UserSet
                   _sapAcqDevice.SetFeatureValue("UserSetSelector", sUserSet);
                   _sapAcqDevice.SetFeatureValue("UserSetLoad", true);
                   //FFC
                   _sapAcqDevice.SetFeatureValue("flatfieldCorrectionCurrentActiveSet", sUserSet);
                   _sapAcqDevice.SetFeatureValue("flatfieldCalibrationLoad", true);


                   acq0SupportSG = SapBuffer.IsBufferTypeSupported(_sapAcquisition[0].Location, SapBuffer.MemoryType.ScatterGather);
                   if (debug) Debug.WriteLine("Xtium2-CLHS_PX8_1  over....");
                   return true;
               });


            Task<bool> tskLocation2 = Task.Run(() =>
            {
                // 创建采集对象2
                int nResourceIndex2 = 0;
                _sapLocation[1] = new SapLocation("Xtium2-CLHS_PX8_2", nResourceIndex2);
                _sapAcquisition[1] = new SapAcquisition(_sapLocation[1], sCcfFile2);
                if (_sapAcquisition[1] != null && !_sapAcquisition[1].Initialized)
                {
                    if (_sapAcquisition[1].Create() == false)
                    {
                        DestroyObjects();
                        return false;
                    }
                }
                _sapAcquisition[1].SetParameter(SapAcquisition.Prm.CROP_HEIGHT, iFrameLines, true);//采集行数
                acq1SupportSG = SapBuffer.IsBufferTypeSupported(_sapAcquisition[1].Location, SapBuffer.MemoryType.ScatterGather);
                if (debug) Debug.WriteLine("Xtium2-CLHS_PX8_2  over....");
                return true;
            });
            //申请Buffers
            Task.WaitAll(tskLocation1, tskLocation2);

            if (!tskLocation1.Result || !tskLocation2.Result)
            {
                return false;
            }

            if (acq0SupportSG && acq0SupportSG)
            {
                //_sapBuffer = new SapBufferWithTrash(iFrameCount, _sapAcquisition, SapBuffer.MemoryType.ScatterGather);
                _sapBuffer = new SapBufferWithTrash();
                _buffers[0] = new SapBufferRoi(_sapBuffer);
                _buffers[1] = new SapBufferRoi(_sapBuffer);
            }
            else
            {
                bool acq0SupportSGP = SapBuffer.IsBufferTypeSupported(_sapAcquisition[0].Location, SapBuffer.MemoryType.ScatterGatherPhysical);
                bool acq1SupportSGP = SapBuffer.IsBufferTypeSupported(_sapAcquisition[1].Location, SapBuffer.MemoryType.ScatterGatherPhysical);
                if (acq0SupportSGP && acq1SupportSGP)
                {
                    //_sapBuffer = new SapBufferWithTrash(iFrameCount, _sapAcquisition, SapBuffer.MemoryType.ScatterGatherPhysical);
                    _sapBuffer = new SapBufferWithTrash();
                    _buffers[0] = new SapBufferRoi(_sapBuffer);
                    _buffers[1] = new SapBufferRoi(_sapBuffer);
                }
                else
                {
                    DestroyObjects();
                    return false;
                }
            }

            // 创建SapAcqToBuf
            _sapXfer[0] = new SapAcqToBuf(_sapAcquisition[0], _buffers[0]);
            _sapXfer[1] = new SapAcqToBuf(_sapAcquisition[1], _buffers[1]);

            //数据回调事件
            _sapXfer[0].Pairs[0].EventType = SapXferPair.XferEventType.EndOfFrame;
            _sapXfer[0].XferNotify += new SapXferNotifyHandler(Data_XferNotify);
            _sapXfer[0].XferNotifyContext = _sapBuffer;

            _sapXfer[1].Pairs[0].EventType = SapXferPair.XferEventType.EndOfFrame;
            _sapXfer[1].XferNotify += new SapXferNotifyHandler(Data_XferNotify);
            _sapXfer[1].XferNotifyContext = _sapBuffer;

            //m_pBuf[nIndex]->SetState(m_pBuf[nIndex]->GetIndex(),SapBuffer::StateEmpty);

            //状态回调事件
            _sapAcquisition[0].SignalNotify += new SapSignalNotifyHandler(GetSignalStatus);
            _sapAcquisition[0].SignalNotifyContext = this;
            _sapAcquisition[1].SignalNotify += new SapSignalNotifyHandler(GetSignalStatus);
            _sapAcquisition[1].SignalNotifyContext = this;


            //创建对象
            if (!CreateObjects(iFrameCount))
            {
                DisposeObjects();
                return false;
            }

            return true;
        }



        /// 初始化相机
        private bool InitCamera(string sCcfFile1, string sCcfFile2, string sUserSet, int iFrameLines, int iFrameCount)
        {
            SapManager.DisplayStatusMode = SapManager.StatusMode.Log;
            //设置采集参数
            //string sServerName = "Xcelera-HS_PX8_1";
            //string sServerName = "Xtium2-CLHS_PX8_1";
            string sServerName = _paramAOI.CameraServerName;

            if (debug) Debug.WriteLine("init camera start...");
            // 创建采集对象
            int nResourceIndex = 0;
            _sapLocation[0] = new SapLocation("Xtium2-CLHS_PX8_1", nResourceIndex);
            _sapAcquisition[0] = new SapAcquisition(_sapLocation[0], sCcfFile1);
            if (_sapAcquisition[0] != null && !_sapAcquisition[0].Initialized)
            {
                if (_sapAcquisition[0].Create() == false)
                {
                    DestroyObjects();
                    return false;
                }
            }
            if (debug) Debug.WriteLine("location  acquistion over....");
            //创建设备对象,用于设置Feature
            _sapAcqDevice = new SapAcqDevice(_sapLocation[0], false);
            if (!_sapAcqDevice.Create())
            {
                return false;
            }

            _sapAcquisition[0].SetParameter(SapAcquisition.Prm.CROP_HEIGHT, iFrameLines, true);//采集行数
            //Load UserSet
            _sapAcqDevice.SetFeatureValue("UserSetSelector", sUserSet);
            _sapAcqDevice.SetFeatureValue("UserSetLoad", true);
            //FFC
            _sapAcqDevice.SetFeatureValue("flatfieldCorrectionCurrentActiveSet", sUserSet);
            _sapAcqDevice.SetFeatureValue("flatfieldCalibrationLoad", true);


            // 创建采集对象2
            int nResourceIndex2 = 0;
            _sapLocation[1] = new SapLocation("Xtium2-CLHS_PX8_2", nResourceIndex2);
            _sapAcquisition[1] = new SapAcquisition(_sapLocation[1], sCcfFile2);
            if (_sapAcquisition[1] != null && !_sapAcquisition[1].Initialized)
            {
                if (_sapAcquisition[1].Create() == false)
                {
                    DestroyObjects();
                    return false;
                }
            }
            _sapAcquisition[1].SetParameter(SapAcquisition.Prm.CROP_HEIGHT, iFrameLines, true);//采集行数

            //申请Buffers
            bool acq0SupportSG = SapBuffer.IsBufferTypeSupported(_sapAcquisition[0].Location, SapBuffer.MemoryType.ScatterGather);
            bool acq1SupportSG = SapBuffer.IsBufferTypeSupported(_sapAcquisition[1].Location, SapBuffer.MemoryType.ScatterGather);
            if (acq0SupportSG && acq0SupportSG)
            {
                //_sapBuffer = new SapBufferWithTrash(iFrameCount, _sapAcquisition, SapBuffer.MemoryType.ScatterGather);
                _sapBuffer = new SapBufferWithTrash();
                _buffers[0] = new SapBufferRoi(_sapBuffer);
                _buffers[1] = new SapBufferRoi(_sapBuffer);
            }
            else
            {
                bool acq0SupportSGP = SapBuffer.IsBufferTypeSupported(_sapAcquisition[0].Location, SapBuffer.MemoryType.ScatterGatherPhysical);
                bool acq1SupportSGP = SapBuffer.IsBufferTypeSupported(_sapAcquisition[1].Location, SapBuffer.MemoryType.ScatterGatherPhysical);
                if (acq0SupportSGP && acq1SupportSGP)
                {
                    //_sapBuffer = new SapBufferWithTrash(iFrameCount, _sapAcquisition, SapBuffer.MemoryType.ScatterGatherPhysical);
                    _sapBuffer = new SapBufferWithTrash();
                    _buffers[0] = new SapBufferRoi(_sapBuffer);
                    _buffers[1] = new SapBufferRoi(_sapBuffer);
                }
                else
                {
                    DestroyObjects();
                    return false;
                }
            }

            // 创建SapAcqToBuf
            _sapXfer[0] = new SapAcqToBuf(_sapAcquisition[0], _buffers[0]);
            _sapXfer[1] = new SapAcqToBuf(_sapAcquisition[1], _buffers[1]);

            //数据回调事件
            _sapXfer[0].Pairs[0].EventType = SapXferPair.XferEventType.EndOfFrame;
            _sapXfer[0].XferNotify += new SapXferNotifyHandler(Data_XferNotify);
            _sapXfer[0].XferNotifyContext = _sapBuffer;

            _sapXfer[1].Pairs[0].EventType = SapXferPair.XferEventType.EndOfFrame;
            _sapXfer[1].XferNotify += new SapXferNotifyHandler(Data_XferNotify);
            _sapXfer[1].XferNotifyContext = _sapBuffer;

            //m_pBuf[nIndex]->SetState(m_pBuf[nIndex]->GetIndex(),SapBuffer::StateEmpty);

            //状态回调事件
            _sapAcquisition[0].SignalNotify += new SapSignalNotifyHandler(GetSignalStatus);
            _sapAcquisition[0].SignalNotifyContext = this;
            _sapAcquisition[1].SignalNotify += new SapSignalNotifyHandler(GetSignalStatus);
            _sapAcquisition[1].SignalNotifyContext = this;


            //创建对象
            if (!CreateObjects(iFrameCount))
            {
                DisposeObjects();
                return false;
            }

            return true;
        }




        /// <summary>
        /// 释放相机
        /// </summary>
        private void FreeCamera()
        {
            try
            {
                DestroyObjects();
            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, "FreeCamera Failed", ex);
            }
        }


        //相机复位功能
        public bool CAMERA_RESET(bool bResetServer, string sType)
        {
            bool bRet = false;
            try
            {
                Thread.Sleep(1000);
                StopGrab();
                Thread.Sleep(1000);
                FreeCamera();
                Thread.Sleep(1000);
                if (sType != "") UpdateParam(sType);
                if (bResetServer)
                {
                    //string sServerName = "Xcelera-HS_PX8_1";
                    //string sServerName = "Xtium2-CLHS_PX8_1";
                    string sServerName = _paramAOI.CameraServerName;
                    int nResourceIndex = 0;
                    SapLocation sapLocation = new SapLocation(sServerName, nResourceIndex);
                    SapManager.ResetServer(sapLocation, true);
                    Thread.Sleep(1000);
                }
                string sCcfFileName = Application.StartupPath + "\\" + _paramAOI.CcfFile;
                string sCcfFileName2 = Application.StartupPath + "\\" + _paramAOI.CcfFile2;

                bRet = InitCamera(sCcfFileName, sCcfFileName2, _paramAOI.UserSet, _paramAOI.ImgWidthOri, _paramAOI.FrameCount);
                Thread.Sleep(1000);
            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, "CAMERA_RESET Exception", ex);
            }
            return bRet;
        }


        /// <summary>
        /// 创建对象
        /// </summary>
        /// <returns></returns>
        private bool CreateObjects(int iFrameCount)
        {
            _sapBuffer.Count = iFrameCount;
            _sapBuffer.Width = 2 * _sapAcquisition[0].XferParams.Width;
            _sapBuffer.Height = _sapAcquisition[0].XferParams.Height;
            _sapBuffer.Format = _sapAcquisition[0].XferParams.Format;
            _sapBuffer.PixelDepth = _sapAcquisition[0].XferParams.PixelDepth;
            if (_sapBuffer != null && !_sapBuffer.Initialized)
            {
                if (!_sapBuffer.Create())
                {
                    DestroyObjects();
                    return false;
                }
                _sapBuffer.Clear();
            }
            _buffers[0].SetRoi(0, 0, _sapAcquisition[0].XferParams.Width, _sapAcquisition[0].XferParams.Height);
            if (_buffers[0] != null && !_buffers[0].Initialized)
            {
                if (_buffers[0].Create() == false)
                {
                    DestroyObjects();
                    return false;
                }
            }
            _buffers[1].SetRoi(_sapAcquisition[0].XferParams.Width, 0, _sapAcquisition[0].XferParams.Width, _sapAcquisition[0].XferParams.Height);
            if (_buffers[1] != null && !_buffers[1].Initialized)
            {
                if (_buffers[1].Create() == false)
                {
                    DestroyObjects();
                    return false;
                }
            }
            if (_sapXfer[0] != null && !_sapXfer[0].Initialized)
            {
                if (!_sapXfer[0].Create())
                {
                    DestroyObjects();
                    return false;
                }
            }
            if (_sapXfer[1] != null && !_sapXfer[1].Initialized)
            {
                if (!_sapXfer[1].Create())
                {
                    DestroyObjects();
                    return false;
                }
            }
            return true;
        }


        private object _objLockFree = new object();
        /// <summary>
        /// 销毁对象
        /// </summary>
        private void DestroyObjects()
        {
            try
            {
                lock (_objLockFree)
                {

                    if (_sapXfer[0] != null && _sapXfer[0].Grabbing)
                        _sapXfer[0].Abort();
                    if (_sapXfer[1] != null && _sapXfer[1].Grabbing)
                        _sapXfer[1].Abort();

                    if (_sapXfer[0] != null && _sapXfer[0].Initialized)
                    {
                        if (debug)
                            ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "sapXfer[0] Dispose");
                        _sapXfer[0].Destroy();
                        _sapXfer[0].Dispose();
                    }
                    _sapXfer[0] = null;
                    if (_sapXfer[1] != null && _sapXfer[1].Initialized)
                    {
                        if (debug) ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "sapXfer[1] Dispose");
                        _sapXfer[1].Destroy();
                        _sapXfer[1].Dispose();

                    }
                    _sapXfer[1] = null;
                    if (_buffers[0] != null && _buffers[0].Initialized)
                    {
                        if (debug) ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "buffers[0] Dispose");
                        _buffers[0].Destroy();
                        _buffers[0].Dispose();

                    }
                    _buffers[0] = null;
                    if (_buffers[1] != null && _buffers[1].Initialized)
                    {
                        if (debug) ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "buffers[1] Dispose");
                        _buffers[1].Destroy();
                        _buffers[1].Dispose();

                    }
                    _buffers[1] = null;
                    if (_sapBuffer != null && _sapBuffer.Initialized)
                    {
                        if (debug) ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, " _sapBuffer Dispose");
                        _sapBuffer.Destroy();
                        _sapBuffer.Dispose();

                    }
                    _sapBuffer = null;
                    if (_sapAcquisition[0] != null && _sapAcquisition[0].Initialized)
                    {
                        if (debug) ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "_sapAcquisition[0] Dispose");
                        _sapAcquisition[0].Destroy();
                        _sapAcquisition[0].Dispose();
                    }
                    _sapAcquisition[0] = null;
                    if (_sapAcquisition[1] != null && _sapAcquisition[1].Initialized)
                    {
                        if (debug) ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "_sapAcquisition[1] Dispose");
                        _sapAcquisition[1].Destroy();
                        _sapAcquisition[1].Dispose();
                    }
                    _sapAcquisition[1] = null;

                    if (_sapAcqDevice != null && _sapAcqDevice.Initialized)
                    {
                        if (debug) ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, "_sapAcqDevice Dispose");
                        _sapAcqDevice.Destroy();
                        _sapAcqDevice.Dispose();

                    }
                    _sapAcqDevice = null;
                }
            }
            catch (System.Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, "相机DestroyObjects 异常", ex);
            }
        }


        private void DisposeObjects()
        {
            try
            {
                if (_sapXfer[1] != null)
                {
                    _sapXfer[1].Dispose();
                    _sapXfer[1] = null;
                }
                if (_sapXfer[0] != null)
                {
                    _sapXfer[0].Dispose();
                    _sapXfer[0] = null;
                }
                if (_buffers[1] != null)
                {
                    _buffers[1].Dispose();
                    _buffers[1] = null;
                }
                if (_buffers[0] != null)
                {
                    _buffers[0].Dispose();
                    _buffers[0] = null;
                }
                if (_sapBuffer != null)
                {
                    _sapBuffer.Dispose();
                }
                if (_sapAcquisition[1] != null)
                {
                    _sapAcquisition[1].Dispose();
                    _sapAcquisition[1] = null;
                }
                if (_sapAcquisition[0] != null)
                {
                    _sapAcquisition[0].Dispose();
                    _sapAcquisition[0] = null;
                }
            }
            catch (Exception ex)
            {
                GC.Collect();
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, "DisposeObjects", ex);
            }
            finally
            {
                _sapXfer = null;
                _buffers = null;
                _sapBuffer = null;
                _sapAcquisition = null;
            }
        }


        /// 全幅扫描开始
        public void CAMERA_SCANBEGIN(int iRunID, int iChannel)
        {
            _evtLineReady.Reset();
            Thread.Sleep(0);
            _iRunID = iRunID;
            _iChannel = iChannel;
            _iRow = -1;

            _lsScanItem = null;
            if (_paramAOI.OptimizeScanPath && _paramAOI.DictExtraParam.ContainsKey("ScanPath"))
                _lsScanItem = (List<ScanRowItem>)_paramAOI.DictExtraParam["ScanPath"];

            if (_paramAOI is ParamDFAOI && (_paramAOI as ParamDFAOI).ScanWithBF
                || _paramAOI is ParamPLAOI && (_paramAOI as ParamPLAOI).ScanWithBF
                || _paramAOI is ParamPLXAOI && (_paramAOI as ParamPLXAOI).ScanWithBF)
            {
                _lsScanItem = (List<ScanRowItem>)GPICW.ParamBFAOI.DictExtraParam["ScanPath"];
            }



            ImageProcess.Instance.ScanBegin(iRunID, iChannel);
            _hashImageList.Clear();
            GPICW.ReScanLine = false;
            GPICW.ReScanLineCount = 0;
        }


        /// 全幅扫描结束
        /// <param name="hPack"></param>
        public void CAMERA_SCANEND(int iRunID, int iChannel)
        {
            ImageProcess.Instance.ScanEnd(iRunID, iChannel);
        }


        /// 单行扫描开始
        public bool CAMERA_LINEBEGIN(int iRunID, int iChannel, int iRow)
        {
            AcqCProImageBuffer acqBuf = AcqCProImageBuffer.Instance(iChannel);
            CameraTDI.GetAcqImageList(_paramAOI, _lsScanItem, iRow, ref _dictRowAcqIdxCol);
            _iRowScanFrameNum = _dictRowAcqIdxCol.Count;

            if (debug)
                Debug.WriteLine($"---------------------CAMERA_LINEBEGIN:{iRow}");


            //不是自动分配内存,解决内存不够的情况
            if (!acqBuf.AutoResize)
            {
                DateTime dtStart = DateTime.Now;
                while (acqBuf.BufferSize < _iRowScanFrameNum)
                {
                    Thread.Sleep(1000);
                    if (debug)
                        Debug.WriteLine($"$$$###%%%-Waiting For AcqCProImageBuffer : {acqBuf.BufferSize} / {acqBuf.BufferTotal}");
                    if (DateTime.Now.Subtract(dtStart).TotalSeconds > 40)
                    {
                        GPICW.ForceStop = true;
                        MessageBox.Show("请检查相机参数--预分配缓存参数存在设置不合理问题，建议打开自动调整", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            _iRow = iRow;
            _bScanDirection = _paramAOI.FirstScanDirection;
            if (_paramAOI.ScanMode == ScanMode.Bow_Scan)
            {
                if (iRow % 2 == 0)
                    _bScanDirection = _paramAOI.FirstScanDirection;
                else
                    _bScanDirection = !_paramAOI.FirstScanDirection;
            }
            else if (_paramAOI.ScanMode == ScanMode.Z_Scan)
            {
                _bScanDirection = _paramAOI.FirstScanDirection;
            }
            SetCameraScanDirection(_bScanDirection);

            _evtLineReady.Reset();
            _iCallbackCount = 0;
            _iColIdx = 0;
            _iBufferIndex = 0;
            StartGrab(_iRowScanFrameNum);
            return true;
        }

        /// 设置弓形扫描时的相机方向
        private void SetCameraScanDirection(bool bDirection = true)
        {
            try
            {
                if (bDirection)
                    _sapAcqDevice.SetFeatureValue("sensorScanDirection", "Forward");//正向扫描
                else
                    _sapAcqDevice.SetFeatureValue("sensorScanDirection", "Reverse");//正向扫描
            }
            catch (Exception ex)
            {
                Debug.WriteLine("SetCameraScanDirection Error." + ex.Message);
            }
        }

        public void GetCameraFeature(string featureName, out string featureValue)
        {
            featureValue = "";
            try
            {
                //_comCamera.Write("scd 1\r\n");//正向扫描
                _sapAcqDevice.GetFeatureValue(featureName, out featureValue);//正向扫描

            }
            catch (Exception ex)
            {
                Debug.WriteLine("GetCameraFeature Error." + ex.Message);
            }
        }
        public void SetCameraFeature(string featureName, string featureValue)
        {
            // featureValue = "";
            try
            {
                //_comCamera.Write("scd 1\r\n");//
                _sapAcqDevice.SetFeatureValue(featureName, featureValue);//

            }
            catch (Exception ex)
            {
                Debug.WriteLine("SetCameraFeature Error." + ex.Message);
            }
        }
        public void SetCameraFeature(string featureName, bool featureValue)
        {
            // featureValue = "";
            try
            {
                //_comCamera.Write("scd 1\r\n");//
                _sapAcqDevice.SetFeatureValue(featureName, featureValue);//

            }
            catch (Exception ex)
            {
                Debug.WriteLine("SetCameraFeature Error." + ex.Message);
            }
        }
        public void SetCameraFeature(string featureName, float featureValue)
        {
            // featureValue = "";
            try
            {
                //_comCamera.Write("scd 1\r\n");//
                _sapAcqDevice.SetFeatureValue(featureName, featureValue);//

            }
            catch (Exception ex)
            {
                Debug.WriteLine("SetCameraFeature Error." + ex.Message);
            }
        }
        /// 单行扫描结束
        public void CAMERA_LINEEND(int iRunID, int iChannel, int iRow)
        {
            if (debug)
                Debug.WriteLine($"---------------------CAMERA_LINEEND:{iRow}");
            bool bTimeout = false;
            if (!_evtLineReady.WaitOne(_paramAOI.LineScanTimeout))
            {
                _sapXfer[0].Abort();
                _sapXfer[1].Abort();
                bTimeout = true;
                GPICW.ReScanLine = true;
            }
            if (GPICW.ReScanLine)
            {
                string sText = "中间丢帧";
                if (bTimeout)
                    sText = "行尾丢帧,超时";
                sText = $"$$$$$$$$######## {sText},{_iRunID},block:{iChannel:00}{iRow:000}{_iColIdx:000}";
                ZlxgLog.Instance.WriteLog(sText);
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Warn, sText);
                //GPICW.waferlog = sText;
            }
        }

        private bool StartGrab(int iFrameNum)
        {
            if (this._paramAOI.OptimizeScanPath)
                _sapBuffer.Clear();
            _buffers[0].ResetIndex();
            _buffers[1].ResetIndex();
            _sapBuffer.ResetIndex();
            Thread.Sleep(10);
            bool bResult0 = _sapXfer[0].Snap(iFrameNum);
            bool bResult1 = _sapXfer[1].Snap(iFrameNum);
            return bResult0 && bResult1;
        }

        private void StopGrab()
        {
            //_sapXfer[0].Abort();
            //_sapXfer[1].Abort();
            _sapBuffer.Clear();
            //_sapBuffer.ResetIndex();
        }

        private bool CheckLostFrame(int iBufferIndex, ref int iRow, ref int iCol)
        {
            //模拟丢帧检测   
            if (_iRow == GPICW.TryLostFrameRow && iBufferIndex == GPICW.TryLostFrameCol && GPICW.TryLostFrameNum > 0)
            {
                GPICW.TryLostFrameNum--;
                return false;
            }
            if (iBufferIndex != _iColIdx)
            {
                _evtLineReady.Set();
                GPICW.ReScanLine = true;
            }
            if (GPICW.ReScanLine)
                return false;
            if (_dictRowAcqIdxCol.ContainsKey(iCol))
            {
                _dictRowAcqIdxCol.Remove(iCol);
                Interlocked.Increment(ref iCol);
                return false;
            }
            return true;
        }

        void Data_XferNotify(object sender, SapXferNotifyEventArgs argsNotify)
        {
            _iCallbackCount++;
            if (debug)
                Debug.WriteLine($"-------------------------->$$$%%%### - Data_XferNotify - 0 : {_iCallbackCount}");
            if (_iCallbackCount % 2 == 1)
                return;
            if (_iRow > _paramAOI.ScanNum - 1)
                return;
            if (_iColIdx > _iRowScanFrameNum - 1)
                return;
            //获取图像和顺序号
            SapBuffer buf = argsNotify.Context as SapBuffer;
            int iBufferIndex = _iBufferIndex;
            int iCol = -1;
            lock (_dictRowAcqIdxCol)
            {
                if (_dictRowAcqIdxCol.ContainsKey(_iColIdx))
                    iCol = _dictRowAcqIdxCol[_iColIdx];
            }

            //复制图像
            IntPtr hBuf = IntPtr.Zero;
            buf.GetAddress(iBufferIndex % _paramAOI.FrameCount, out hBuf);
            int iBufWidth = buf.Width;
            int iBufHeight = buf.Height;
            int iBufPitch = buf.Pitch;
            //CProImage img = AcqCProImageBuffer.Instance(_iChannel).GetImageBuffer();
            //img.Clear();
            //IntPtr hImg = img.GetData();
            //int iImgWidth = img.Width;
            //int iImgHeight = img.Height;
            AcqCProImageBuffer acqBuf = AcqCProImageBuffer.Instance(_iChannel);
            CProImage img = acqBuf.GetImageBuffer();
            IntPtr hImg = img.GetData();
            if (img.Width != _paramAOI.ImgHeightOri || img.Height != _paramAOI.ImgWidthOri)
            {
                ZlxgLog.Instance.WriteLog($"Data_XferNotify->GetImageBuffer.宽度:{img.Width},高度:{img.Height},格式:{img.Format},{_iChannel}");
                img.Dispose();
                img = new CProImage(acqBuf.ImageWidth, acqBuf.ImageHeight, acqBuf.ImageFormat, IntPtr.Zero, true);
                ZlxgLog.Instance.WriteLog($"Data_XferNotify->GetImageBuffer - New.宽度:{img.Width},高度:{img.Height},格式:{img.Format},{_iChannel}");
            }

            int iBytes = 1;
            if (_paramAOI.ColorDepth != EnumColorDepth.Bit8)
                iBytes = 2;
            unsafe
            {
                if (_paramAOI.ImgHeightOri == iBufWidth)  //没有裁切,没有软Binning,直接拷贝到队列Buf（采集和处理图像一样大小）
                {
                    memcpy(hImg, hBuf, iBufWidth * iBufHeight * iBytes);
                }
                else if (_paramAOI.ImgHeightOri < iBufWidth)  //需要裁切,没有软Binning,直接裁切到队列Buf（采集和处理图像一样大小）
                {
                    int iDataOffset = _paramAOI.CCDCropPos;
                    int iDataLength = _paramAOI.ImgHeightOri;
                    if (iDataOffset + iDataLength > iBufWidth)
                        iDataOffset = (iBufWidth - iDataLength) / 2;
                    for (int i = 0; i < _paramAOI.ImgWidthOri; i++)
                    {
                        IntPtr hLineSrc = IntPtr.Add(hBuf, (iDataOffset + iBufWidth * i) * iBytes);
                        IntPtr hLineDst = IntPtr.Add(hImg, iDataLength * i * iBytes);
                        memcpy(hLineDst, hLineSrc, iDataLength * iBytes);
                    }
                }
            }
            //放入队列
            ImageInfo info = new ImageInfo();
            info.RunID = _iRunID;
            info.Img = img;
            info.Channel = _iChannel;
            info.Row = _iRow;
            info.Col = -1;
            lock (_dictRowAcqIdxCol)
            {
                if (_dictRowAcqIdxCol.ContainsKey(_iColIdx))
                {
                    info.Col = _dictRowAcqIdxCol[_iColIdx];
                    _dictRowAcqIdxCol.Remove(_iColIdx);
                }
            }
            ImageProcess.Instance.PushImage(info);

            // ZlxgLog.Instance.WriteLog($"Data XferNotify--CH:{info.Channel}Row:{info.Row}col:{info.Col}");
            //Debug.WriteLine($"-------------------------->$$$%%%### - Data_XferNotify - 2: {info.Row},{info.Col}");
            if (_iColIdx == _iRowScanFrameNum - 1)
            {
                // ZlxgLog.Instance.WriteLog($"Data XferNotify-LastCol_lineReadySet-CH:{info.Channel}Row:{info.Row}col:{info.Col},ColIdx:{_iColIdx},");
                _evtLineReady.Set();
                _dictRowAcqIdxCol.Clear();
                GPICW.ReScanLineCount = 0;
            }
            else
            {
                Interlocked.Increment(ref _iColIdx);
            }
            Interlocked.Increment(ref _iBufferIndex);
        }

        /// 信号回调
        static void GetSignalStatus(object sender, SapSignalNotifyEventArgs argsSignal)
        {
        }

    }
}
