﻿//using AK.Define.PSS;
using AK.ICW.Proc;
using AK.Tools;
using DALSA.SaperaProcessing.CPro;
using Matrox.MatroxImagingLibrary;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;
using AK.FX.Define;
using ApuDefine;
using System.Diagnostics;
using DALSA.SaperaLT.SapClassBasic;
using OpenCvSharp;

namespace AK.HW.Camera
{
    //鑫图
    public class CameraDhyanaMatrox : ICameraTDI
    {
        private static Dictionary<int, CameraDhyanaMatrox> _dicInstance = new Dictionary<int, CameraDhyanaMatrox>();
        public static CameraDhyanaMatrox Instance(int Index)
        {
            CameraDhyanaMatrox camera = null;
            lock (_dicInstance)
            {
                if (!_dicInstance.ContainsKey(Index))
                {
                    camera = new CameraDhyanaMatrox();
                    camera.Index = Index;
                    _dicInstance.Add(Index, camera);
                }
                else
                {
                    camera = _dicInstance[Index];
                }
            }
            return camera;
        }

        private int Index { get; set; } = 0;
       
        private static MIL_ID _milApp = MIL.M_NULL;
        private MIL_ID _milSystem = MIL.M_NULL;
        private MIL_ID _milCamera = MIL.M_NULL;
        private MIL_ID _milImage = MIL.M_NULL;

        private int BUFFERING_SIZE_MAX = 50;  //50
        private MIL_ID[] _lsMilBuffer = null;// new MIL_ID[BUFFERING_SIZE_MAX];
        //private int _iMilBufferSize = 0;

        private GCHandle _hUserData;
        private MIL_DIG_HOOK_FUNCTION_PTR ProcessingFunctionPtr;
        private HookDataStructDhyana UserHookData = new HookDataStructDhyana();

        private string _iRunID = "";
        private int _iChannel = 0;
        private  int _iRow = 0;
        private  int _iColIdx = 0;

        private bool _bInitialized = false;

        PreCamParam preCamParam = null;
        public int GetCallBackTimes()
        {
            return _iColIdx;
        }
        public CameraDhyanaMatrox()
        {
            preCamParam  = new PreCamParam();
        }
        ~CameraDhyanaMatrox()
        {
            Uninitialize();
        }
        private ParamAOI _paramAOI = null;

        public void UpdateParam(int EnableCh)
        {

            _paramAOI = FXGP.Instance.GetChannelAOIParam(EnableCh);
        }
        public double MonitorCameraTemperature()
        {
            double temp = 0;
            if (_milCamera != MIL.M_NULL)
            {
                MIL.MdigInquireFeature (_milCamera, MIL.M_FEATURE_VALUE, "DeviceTemperature", MIL.M_TYPE_DOUBLE, ref temp);
            }
            return temp;
        }
        public double MonitorSensorTemperature()
        {
            double temp = 0;
            if (_milCamera != MIL.M_NULL)
            {
                MIL.MdigInquireFeature(_milCamera, MIL.M_FEATURE_VALUE, "SensorTemperature", MIL.M_TYPE_DOUBLE, ref temp);
            }
            return temp;
        }
        private bool InitCamera(string sCcfFile, string sCameraPort, int iFrameLines, int iFrameCount)
        {

            
            try
            {
                
                if (_milApp == MIL.M_NULL)
                    MIL.MappAlloc("M_DEFAULT", MIL.M_DEFAULT, ref _milApp);
                int CardIndex = 0;
                int.TryParse(sCameraPort, out CardIndex);
                //int dev = CardIndex == 0 ? MIL.M_DEV0 : MIL.M_DEV1;
                MIL.MsysAlloc(MIL.M_DEFAULT, MIL.M_SYSTEM_DEFAULT, CardIndex, MIL.M_DEFAULT, ref _milSystem);
                FXGP.PushRunEvent("PushLog", ref FXGP.obj, $"DCF file：{sCcfFile}");
                if (MIL.MdigAlloc(_milSystem, MIL.M_DEV0, sCcfFile, MIL.M_DEFAULT, ref _milCamera) == MIL.M_NULL)
                    throw new Exception("The Aquisition Card Init Failed!");

                ////仅适用单卡 机器
                //MIL.MsysAlloc(MIL.M_DEFAULT, MIL.M_SYSTEM_DEFAULT, 0, MIL.M_DEFAULT, ref _milSystem);
                //MIL.MdigAlloc(_milSystem, 0, MIL.M_SYSTEM_DEFAULT, MIL.M_DEFAULT, ref _milCamera);


                ////模拟增益
                //MIL.MdigControlFeature(_milCamera, MIL.M_FEATURE_VALUE, "AnalogGain", MIL.M_TYPE_STRING, sAnalogGain);
                ////数字增益
                //MIL.MdigControlFeature(_milCamera, MIL.M_FEATURE_VALUE, "DigitalGain", MIL.M_TYPE_STRING, sDigitalGain);
                ////BackLevel
                //long lBackLevel = iBackLevel;
                //MIL.MdigControlFeature(_milCamera, MIL.M_FEATURE_VALUE, "BlackLevel", MIL.M_TYPE_INT64, ref lBackLevel);

                MIL.MdigControlFeature(_milCamera, MIL.M_FEATURE_VALUE, "OperationMode", MIL.M_TYPE_STRING, "TDI");

                //申请Buffer
                MIL.MappControl(MIL.M_DEFAULT, MIL.M_ERROR, MIL.M_PRINT_DISABLE);

                BUFFERING_SIZE_MAX = FXGP.Instance.APUSystem.nRamRadio;
                _lsMilBuffer =  new MIL_ID[BUFFERING_SIZE_MAX];
               
                for (int _iMilBufferSize = 0; _iMilBufferSize < BUFFERING_SIZE_MAX; _iMilBufferSize++)
                {
                    MIL_INT x = MIL.MdigInquire(_milCamera, MIL.M_SOURCE_SIZE_X, MIL.M_NULL);
                    MIL_INT y = MIL.MdigInquire(_milCamera, MIL.M_SOURCE_SIZE_Y, MIL.M_NULL);
                    //MIL_INT x2 = MIL.MdigInquire(_milCamera, MIL.M_SIZE_X, MIL.M_NULL);
                    //MIL_INT y2 = MIL.MdigInquire(_milCamera, MIL.M_SIZE_Y, MIL.M_NULL);


                    if (_paramAOI.ColorDepth == FX.Define.EnumColorDepth.Bit8)
                    {
                        MIL.MbufAlloc2d(_milSystem, x, y, 8 + MIL.M_UNSIGNED, MIL.M_IMAGE + MIL.M_GRAB + MIL.M_PROC, ref _lsMilBuffer[_iMilBufferSize]);
                        if (_lsMilBuffer[_iMilBufferSize] == MIL.M_NULL)
                            break;
                        MIL.MbufClear(_lsMilBuffer[_iMilBufferSize], 0xFF);
                    }
                    else if (_paramAOI.ColorDepth == FX.Define.EnumColorDepth.Bit12)
                    {
                        MIL.MbufAlloc2d(_milSystem, x, y, 16 + MIL.M_UNSIGNED, MIL.M_IMAGE + MIL.M_GRAB + MIL.M_PROC, ref _lsMilBuffer[_iMilBufferSize]);
                        if (_lsMilBuffer[_iMilBufferSize] == MIL.M_NULL)
                            break;
                        MIL.MbufClear(_lsMilBuffer[_iMilBufferSize], 0xFF);
                    }
                }
                //MIL.MappControl(MIL.M_DEFAULT, MIL.M_ERROR, MIL.M_PRINT_ENABLE);

                //加载触发方法
                ProcessingFunctionPtr = new MIL_DIG_HOOK_FUNCTION_PTR(ProcessingFunction);
            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, ex.ToString());
                return false;
            }
            return true;
        }

        /// <summary>
        /// 释放相机
        /// </summary>
        private void FreeCamera()
        {
            if (!_bInitialized)
                return;
            try
            {
                MIL.MbufFree(_milImage);
                for (int i = 0; i < BUFFERING_SIZE_MAX; i++)
                    MIL.MbufFree(_lsMilBuffer[i]);
                MIL.MdigFree(_milCamera);
                MIL.MsysFree(_milSystem);
                if (_milApp != MIL.M_NULL)
                {
                    MIL.MappFree(_milApp);
                    _milApp = MIL.M_NULL;
                }

                _milApp = MIL.M_NULL;
                _milSystem = MIL.M_NULL;
                _milCamera = MIL.M_NULL;
                _milImage = MIL.M_NULL;
            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, "FreeCamera Exception", ex);
            }
            _bInitialized = false;
        }

        public bool Initialize(int EnableCh)
        {
            UpdateParam(EnableCh);
            if (_bInitialized)
            {
                //if (preCamParam.ccfFile != _paramAOI.CcfFile
                //  || preCamParam.userSet != _paramAOI.UserSet
                //  || preCamParam.PreFrameCount != _paramAOI.FrameCount
                //  || preCamParam.PreImageWidth != _paramAOI.ImgWidth
                //  || preCamParam.PreImageHeight != _paramAOI.ImgHeight
                //  || preCamParam.PreImageDepth != _paramAOI.ColorDepth)
                //{
                Uninitialize();
                //}
                //else
                //    return true;

                Thread.Sleep(2500);
            }


            string sConfigFile = AppDomain.CurrentDomain.BaseDirectory + "\\config\\" + _paramAOI.CcfFile;
            _bInitialized = InitCamera(sConfigFile, FXGP.Instance.APUSystem.CameraSerialNumber, _paramAOI.ImgHeightOri, _paramAOI.FrameCount
                /*,_paramAOI.AnalogGain, _paramAOI.DigitalGain, paramAOI.BlackLevel*/);
            ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"Camera Init Failed:{_bInitialized},CH:{EnableCh},CCF:{_paramAOI.CcfFile},H:{_paramAOI.ImgHeightOri},Frame:{_paramAOI.FrameCount}");
            //if(_bInitialized)
            //{
            //    preCamParam.ccfFile = _paramAOI.CcfFile;
            //    preCamParam.userSet = _paramAOI.UserSet;
            //    preCamParam.PreFrameCount = _paramAOI.FrameCount;
            //    preCamParam.PreImageWidth = _paramAOI.ImgWidth;
            //    preCamParam.PreImageHeight = _paramAOI.ImgHeight;
            //    preCamParam.PreImageDepth = _paramAOI.ColorDepth;
            //}
            return _bInitialized;
        }
        public void Uninitialize()
        {
            StopGrab();
            FreeCamera();
        }
        public bool CAMERA_RESET(bool bResetServer, int sType)
        {
            bool bRet = false;
            try
            {
                Uninitialize();
                Thread.Sleep(1000);
                Initialize(sType);
                Thread.Sleep(1000);
            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, $"CameraDalsa Error:{ex.Message},{ex.StackTrace}");
            }
            return bRet;
        }

        public bool CAMERA_SCANBEGIN(string iRunID, int iChannel)
        {

            UpdateParam(iChannel);
            _iRunID = iRunID;
            _iChannel = iChannel;
            _iRow = 0;

            return CAMERA_LINEBEGIN(iRunID, iChannel, _iRow);
        }
        public void CAMERA_SCANEND(string iRunID, int iChannel)
        {
            CAMERA_LINEEND(iRunID, iChannel, _iRow);
        }


        public bool CAMERA_LINEBEGIN(string iRunID, int iChannel, int iRow)
        {
            _iRow = iRow;

            _iColIdx = 0;
  
            if (!StartGrab()) return false;
            return true;
        }
        public void CAMERA_LINEEND(string iRunID, int iChannel, int iRow)
        {
            StopGrab();
        }
        private bool StartGrab()
        {
            StopGrab();


            UserHookData.MilDigitizer = _milCamera;
            UserHookData.MilImageDisp = _milImage;
            UserHookData.ProcessedImageCount = 0;
            _hUserData = GCHandle.Alloc(UserHookData);

           
            MIL.MdigProcess(_milCamera, _lsMilBuffer, BUFFERING_SIZE_MAX, MIL.M_START, MIL.M_DEFAULT, ProcessingFunctionPtr, GCHandle.ToIntPtr(_hUserData));

            return true;

        }

        private bool StopGrab()
        {
            
            try
            {
                MIL.MdigProcess(_milCamera, _lsMilBuffer, BUFFERING_SIZE_MAX, MIL.M_STOP, MIL.M_DEFAULT, ProcessingFunctionPtr, GCHandle.ToIntPtr(_hUserData));

                if (_hUserData.IsAllocated)
                    _hUserData.Free();

                double dDeviceTemp = MonitorCameraTemperature();

                double dSensorTemp = MonitorSensorTemperature();
                using (System.IO.StreamWriter file = new System.IO.StreamWriter($"{AppDomain.CurrentDomain.BaseDirectory}Log\\CameraTemp_{_iChannel}.log", true))
                {
                    file.WriteLine(DateTime.Now.ToString() + $",{_iRunID},{dDeviceTemp},{dSensorTemp}");
                }
            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, "StopGrab Exception", ex);
            }
         
            return true;
        }

        [System.Runtime.InteropServices.DllImport("kernel32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        public static extern void OutputDebugString(string message);
        Stopwatch swData_XferNotify = Stopwatch.StartNew();
        Stopwatch sw = Stopwatch.StartNew();
        private MIL_INT ProcessingFunction(MIL_INT HookType, MIL_ID HookId, IntPtr HookDataPtr)
        {
            if (IntPtr.Zero.Equals(HookDataPtr))
                return 0;

            try
            {
                sw.Restart();

                //获取图像和顺序号
                GCHandle hUserData = GCHandle.FromIntPtr(HookDataPtr);
                HookDataStructDhyana UserData = hUserData.Target as HookDataStructDhyana;
                MIL_ID ModifiedBufferId = MIL.M_NULL;
                MIL.MdigGetHookInfo(HookId, MIL.M_MODIFIED_BUFFER + MIL.M_BUFFER_ID, ref ModifiedBufferId);
                int iBufferIndex = UserData.ProcessedImageCount++;
                //if (!CheckLostFrame(iBufferIndex, ref _iRow, ref _iColIdx))
                //    return 0;

                //MIL.MbufSave($"D:\\Image{_iRow:00}{_iCol:00}.tiff",ModifiedBufferId);
                //复制图像
                int iBufWidth = (int)MIL.MbufInquire(ModifiedBufferId, MIL.M_SIZE_X, MIL.M_NULL);
                //int iBufHeight = (int)MIL.MbufInquire(_milCamera, MIL.M_SIZE_Y, MIL.M_NULL);  //2023.11.23.更新新版本类库有改动。
                int iBufHeight = (int)MIL.MbufInquire(ModifiedBufferId, MIL.M_SIZE_Y, MIL.M_NULL);  //lao 
                                                                                                     // int band = (int)MIL.MbufInquire(ModifiedBufferId, MIL.M_SIZE_BAND, MIL.M_NULL);
                int iImagePitch = (int)MIL.MbufInquire(ModifiedBufferId, MIL.M_PITCH_BYTE, MIL.M_NULL);
                IntPtr hBuf = (IntPtr)MIL.MbufInquire(ModifiedBufferId, MIL.M_HOST_ADDRESS, MIL.M_NULL);
                double GetAddresstime = sw.ElapsedMilliseconds;

                sw.Restart();

                //CProImage img=null;
                //AcqCProImageBuffer acqBuf = AcqCProImageBuffer.Instance(_iChannel);
                //img = acqBuf.GetImageBuffer();

                //ApuDefine.ImageInfo info = new ApuDefine.ImageInfo();
                GrabImageInfo info = new GrabImageInfo();
                info.RunID = _iRunID;

                info.Channel = _iChannel;
                info.Row = _iRow;
                info.Col = _iColIdx;

                int iBytes = 1;
                if (_paramAOI.ColorDepth != FX.Define.EnumColorDepth.Bit8)
                    iBytes = 2;
                info.CameraImageData = hBuf;
                info.CameraImageWidth = iBufWidth;
                info.CameraImageHeight = iBufHeight;
                info.CameraImageBytes = iBytes;

                info.subAreaHeight = _paramAOI.SubBlockWidth;
                info.subAreaWidth = _paramAOI.SubBlockWidth;
                info.ValidSubArea = new List<int>() {
                            1, 2, 3, 4,5,6,7,8,9,10,11,12,13,14,15,16 ,
                            17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,
                            33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,
                            49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64
                        };
                ImageCopy.Instance.PushImage(info);


                double memcpytime = sw.ElapsedMilliseconds;

                Interlocked.Increment(ref _iColIdx);
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"RunID={_iRunID} Image {_iColIdx} Call back Time intervals：：{swData_XferNotify.ElapsedMilliseconds}ms ");
                //OutputDebugString($"{DateTime.Now}: 第{_iColIdx}张回调间隔：{swData_XferNotify.ElapsedMilliseconds}ms,RunID={_iRunID}");

                swData_XferNotify.Restart();
            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, ex.ToString());
            }
            return 0;
        }

        /// <summary>
        /// 设置弓形扫描时的相机方向
        /// </summary>
        /// <param name="Direction">Reverse Forward</param>
        private void SetCameraScanDirection(bool bDirection = true)
        {
            try
            {
                string sDirection = "Forward";
                if (!bDirection)
                    sDirection = "Reverse";
                MIL.MdigControlFeature(_milCamera, MIL.M_FEATURE_VALUE_AS_STRING, "ScanDirection", MIL.M_TYPE_ENUMERATION, sDirection);
            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, "SetCameraScanDirection Error." + ex.Message);
            }
        }

       
    }


    public class HookDataStructDhyana
    {
        public MIL_ID MilDigitizer;
        public MIL_ID MilImageDisp;
        public int ProcessedImageCount;
    }
}
