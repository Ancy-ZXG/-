﻿using AK.FX.Define;
using AK.ICW.Proc;
using AK.Tools;
using ApuDefine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Channels;

namespace AK.HW.Camera
{
    public class PreCamParam
    {
        public string ccfFile { get; set; } = "";
        public string userSet { get; set; } = "";
        public int PreFrameCount { get; set; } = 0;
        public int PreImageWidth { get; set; } = 0;
        public int PreImageHeight { get; set;} = 0;
        public EnumColorDepth PreImageDepth { get; set; } = EnumColorDepth.Bit8;
    }
    public class CameraTDI /*: ICameraTDI*/
    {
        
        public static CameraTDI Instance { get; } = new CameraTDI();
        

        private Dictionary<int, ICameraTDI> _dicCamera = new Dictionary<int, ICameraTDI>();
        public static bool _bInitialized = false;

         
        public CameraTDI()
        {
             
        }
        ~CameraTDI()
        {
            Uninitialize();
            //FreeBuffer();
        }

        public int GetCallBackTimes(int iChannel) 
        {
            if (!_dicCamera.ContainsKey(iChannel))
                return 0;
            ICameraTDI cameraTDI = _dicCamera[iChannel];
            return cameraTDI.GetCallBackTimes();
        }
        public void InitializeBuffer(List<int> chs)
        {
            
            for (int i = 0; i < chs.Count;i++)
            {
                int ch = chs[i];
                if( FXGP.Instance.RP.Channels.ContainsKey(ch))
                {
                    ParamAOI paramAOI = FXGP.Instance.RP.Channels[ch].AOI;
                    InitializeBufferByCh(paramAOI, ch);
                }
            }
          
        }


        private  void InitializeBufferByCh(ParamAOI param, int instanceID)
        {
            int iColorDepth = 8;
            if (param.ColorDepth != FX.Define.EnumColorDepth.Bit8)
                iColorDepth = 14;
            AcqMatBuffer.Instance.InitImageBuffer(param.InitBufferSize, param.ImgWidthOri, param.ImgHeightOri, iColorDepth);
        }

        public void FreeBuffer()
        {
            foreach (int i in FXGP.Instance.RP.Channels.Keys)
            {
                AcqMatBuffer instance = AcqMatBuffer.Instance;
                if( instance != null )
                {
                    instance.FreeImageBuffer();
                }
            }
        }

        public void CheckBuffer(int iChannel)
        {

            if (FXGP.Instance.RP.Channels.ContainsKey(iChannel))
            {
                ParamAOI paramAOI = FXGP.Instance.RP.Channels[iChannel].AOI;
                CheckBufferByCh(paramAOI, iChannel);
            }

        }

        private static void CheckBufferByCh(ParamAOI param, int ChID)
        {
            int iColorDepth = 8;
            if (param.ColorDepth != FX.Define.EnumColorDepth.Bit8)
                iColorDepth = 14;
            AcqMatBuffer acqBuf = AcqMatBuffer.Instance;
            if (acqBuf.BufferSize <= 0)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"CheckBufferByCh acqBuf.BufferSize ABNORMAL：{acqBuf.BufferSize}");
                acqBuf.InitImageBuffer(param.InitBufferSize,param.ImgWidthOri, param.ImgHeightOri,  iColorDepth);//处理的图像的尺寸
            }
        }

     
        private ICameraTDI GetCamera(APUCameraType sCameraType)
        {
            switch (sCameraType)
            {
                case APUCameraType.Dalsa:
                    return CameraDalsaAPI.Instance(0);
                //case "DalsaGPU":
                //    return CameraDalsaGPU.Instance(0);
                case APUCameraType.NUVU:
                    return CameraNUVU.Instance(0);
                case APUCameraType.DhyanaMatrox:
                    return CameraDhyanaMatrox.Instance(0);
                case APUCameraType.DalsaHama:
                    return CameraDalsaHama.Instance(0);
                case APUCameraType.SiliconHama:
                    return CameraSiliconHama.Instance(0);
                case APUCameraType.TucsenCamera:
                    return TucsenCamera.Instance(0);
                default:
                    FXGP.PushRunEvent("PushLog", ref FXGP.obj, $"Not Support Type:{sCameraType}\r\nSupport Types：Dalsa/NUVU/DhyanaMatrox/DalsaHama/SiliconHama/TucsenCamera");
                    return null;
            }
        }

        public bool Initialize()
        {
         
            ICameraTDI cameraTDI = GetCamera(FXGP.Instance.APUSystem.AOICameraType);
            
            string[] sEnableChs = FXGP.Instance.APUSystem.ChEnable.Split(new char[] { ',', '，', ';' });//通道名称组合

            Dictionary<string, int> ExistChDic = new Dictionary<string, int>();
            FXGP.Instance.RP.Channels.Select(p => new Tuple<int, string>(p.Key, p.Value.AOI.ChannelName)).ToList().ForEach(item =>
            {
                ExistChDic.Add(item.Item2, item.Item1);
            });

            List<int> lsChEnable = new List<int>();

            for (int i = 0; i < sEnableChs.Length; i++)
            {
                string CHname = sEnableChs[i];
                if (ExistChDic.ContainsKey(CHname))
                    lsChEnable.Add(ExistChDic[CHname]);
                

            }
            if (lsChEnable.Count > 0)
            {
                //if (FXGP.Instance.APUSystem.AOICameraType == "Dalsa")
                //    InitializeBuffer(lsChEnable);

                if (!cameraTDI.Initialize(lsChEnable[0]))//其实只初始化第一个通通道，因为多个 通道使用的是一个相机。临时先这么搞，毕竟目前只有一个 APU对应一个通道
                    return false;

                foreach (int nCh in lsChEnable)
                {

                    if (!_dicCamera.ContainsKey(nCh))
                        _dicCamera.Add(nCh, cameraTDI);
                    else
                        _dicCamera[nCh] = cameraTDI;
                }
                
            }
            else
                return false;
            
            return true;
        }

        public void Uninitialize()
        {
            foreach (var vItem in _dicCamera)
            {
                ICameraTDI cameraTDI = vItem.Value;
                if (cameraTDI == null)
                    continue;

                cameraTDI.Uninitialize();
            }
        }
        
      
        public bool CAMERA_RESET(bool bResetServer, int sType)
        {
            List<bool> resets = new List<bool>();
            foreach (var item in _dicCamera)
            {
                bool reset = item.Value.CAMERA_RESET(bResetServer, sType);
                resets.Add(reset);
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"Reset Channel Cam：{item.Key}");
                // ZlxgLog.Instance.WriteLog($"重置相机通道：{item.Key}");
            }
            return !resets.Contains(false);
        }
        public bool CAMERA_SCANBEGIN(string iRunID, int iChannel)
        {
            if (!_dicCamera.ContainsKey(iChannel))
                return false;
            ICameraTDI cameraTDI = _dicCamera[iChannel];

            //if (FXGP.Instance.APUSystem.AOICameraType == "Dalsa")
                //CheckBuffer(iChannel);
            return cameraTDI.CAMERA_SCANBEGIN(iRunID, iChannel);
        }
        public void CAMERA_SCANEND(string iRunID)
        {
            if(_dicCamera.Count == 0) return;  
            foreach (var item in _dicCamera)
            {
                ICameraTDI cameraTDI = _dicCamera[item.Key];
                cameraTDI.CAMERA_SCANEND(iRunID, item.Key);
            }
            
        }
        public bool CAMERA_LINEBEGIN(string iRunID, int iChannel, int iRow)
        {
            if (!_dicCamera.ContainsKey(iChannel))
                return false;
            ICameraTDI cameraTDI = _dicCamera[iChannel];
            return cameraTDI.CAMERA_LINEBEGIN(iRunID, iChannel, iRow);
        }
        public void CAMERA_LINEEND(string iRunID, int iChannel, int iRow)
        {
            if (!_dicCamera.ContainsKey(iChannel))
                return;
            ICameraTDI cameraTDI = _dicCamera[iChannel];
            cameraTDI.CAMERA_LINEEND(iRunID, iChannel, iRow);
        }
        
    }
}