﻿using AK.FX.Define;
using ApuDefine;
using DALSA.SaperaLT.SapClassBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Hamamatsu.DCAM4;
using AK.Tools;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using AK.ICW.Proc;
using System.Diagnostics;
using static Hamamatsu.DCAM4.DCAMPROP;

namespace AK.HW.Camera
{
    public class CameraSiliconHama : ICameraTDI
    {
        private static Dictionary<int, CameraSiliconHama> _dicInstance = new Dictionary<int, CameraSiliconHama>();
        public static CameraSiliconHama Instance(int Index)
        {
            CameraSiliconHama camera = null;
            lock (_dicInstance)
            {
                if (!_dicInstance.ContainsKey(Index))
                {
                    camera = new CameraSiliconHama();
                    camera.Index = Index;
                    _dicInstance.Add(Index, camera);
                }
                else
                {
                    camera = _dicInstance[Index];
                }
            }
            return camera;
        }

        private MyDcam mydcam=null;
        private MyDcamWait mydcamwait=null;
        //private MyImage m_image;

        private int Index { get; set; } = 0;
        private string _iRunID = "";
        private int _iChannel = 0;
        private int _iRow = 0;
        private int _iColIdx = 0;

        private bool _bInitialized = false;

        private Thread m_threadCapture;

        public int GetCallBackTimes()
        {
            return _iColIdx;
        }
        private ParamAOI _paramAOI = null;

        public void UpdateParam(int EnableCh)
        {
            _paramAOI = FXGP.Instance.GetChannelAOIParam(EnableCh);
        }
        public CameraSiliconHama()
        {
          
        }
        ~CameraSiliconHama()
        {
            Uninitialize();
        }

        Stopwatch swData_XferNotify = Stopwatch.StartNew();
        private void OnThreadCapture()
        {
            bool bContinue = true;

            using (mydcamwait = new MyDcamWait(ref mydcam))
            {   int iFrameCount = 0;
                while (bContinue)
                {
                    DCAMWAIT eventmask = DCAMWAIT.CAPEVENT.FRAMEREADY | DCAMWAIT.CAPEVENT.STOPPED;
                    DCAMWAIT eventhappened = DCAMWAIT.NONE;
                    if (mydcamwait.start(eventmask, ref eventhappened))
                    {
                        ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, $"RunID={_iRunID},eventhappened={iFrameCount}");
                        if (eventhappened & DCAMWAIT.CAPEVENT.FRAMEREADY)
                        {
                            int iNewestFrame = 0;
                            
                            string ErrMes = "";
                            if (mydcam.cap_transferinfo(ref iNewestFrame, ref iFrameCount, ref ErrMes))
                            {
                                //MyUpdateImage(iNewestFrame);
                                DCAMBUF_FRAME bufframe = new DCAMBUF_FRAME(iNewestFrame);
                                mydcam.buf_lockframe(ref bufframe);

                                //
                                GrabImageInfo info = new GrabImageInfo();
                                info.RunID = _iRunID;

                                info.Channel = _iChannel;
                                info.Row = _iRow;
                                info.Col = _iColIdx;

                                //ImageProcess.Instance.PushImage(info);

                                int iBytes = 1;
                                if (_paramAOI.ColorDepth != FX.Define.EnumColorDepth.Bit8)
                                    iBytes = 2;
                                info.CameraImageData = bufframe.buf;
                                info.CameraImageWidth = bufframe.width;
                                info.CameraImageHeight = bufframe.height;
                                info.CameraImageBytes = iBytes;
                                info.CameraImageIndex = bufframe.iFrame;

                                info.subAreaHeight = _paramAOI.SubBlockWidth;
                                info.subAreaWidth = _paramAOI.SubBlockWidth;
                                info.ValidSubArea = new List<int>() {
                                    1, 2, 3, 4,5,6,7,8,9,10,11,12,13,14,15,16 ,
                                    17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,
                                    33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,
                                    49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64
                                };
                                ImageCopy.Instance.PushImage(info);


                                Interlocked.Increment(ref _iColIdx);

                                ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"RunID={_iRunID},ImageWitdh:{bufframe.width},ImageHeight:{bufframe.height} {_iColIdx} Call back Time intervals：{swData_XferNotify.ElapsedMilliseconds}ms");

                                swData_XferNotify.Restart();
                            }
                            else
                                ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, $"RunID={_iRunID},Trash or Lost:"+ErrMes);
                        }

                        if (eventhappened & DCAMWAIT.CAPEVENT.STOPPED)
                        {
                            bContinue = false;
                            ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, " Grab STOPPED ");
                        }
                    }
                    else
                    {
                        if (mydcamwait.m_lasterr == DCAMERR.TIMEOUT)
                        {
                            //ZlxgLog.Instance.WriteLog(Log4NetLevel.Warn, " Grab TIMEOUT ");
                        }
                        else if (mydcamwait.m_lasterr == DCAMERR.ABORT)
                        {
                            bContinue = false;
                            ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, " Grab ABORT ");
                        }
                        
                    }
                }
            }
        }


        public bool Initialize(int EnableCh)
        {
            UpdateParam(EnableCh);
            if (_bInitialized)
            {
                
                Uninitialize();
               
                Thread.Sleep(2500);
            }


            string ErrMsg ="";// AppDomain.CurrentDomain.BaseDirectory + "\\config\\" + _paramAOI.CcfFile;
            _bInitialized = InitCamera(FXGP.Instance.APUSystem.CameraSerialNumber, _paramAOI.ImgHeightOri,_paramAOI.ColorDepth,ref ErrMsg);
            ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"Camera Init Result:{_bInitialized},CH:{EnableCh},CCF:{_paramAOI.CcfFile},H:{_paramAOI.ImgHeightOri},Frame:{_paramAOI.FrameCount}");
             
            return _bInitialized;
        }
        private string CamStatusNG(string text, DCAMERR err)
        {
             return $"{text} : {err.text()}";
        }
        private bool InitCamera(string sCameraSN, int iFrameLines, EnumColorDepth colorDepth, ref string ErrMsg)
        {
            if (!MyDcamApi.init())
            {
                ErrMsg = CamStatusNG("MyDcamApi.init()", MyDcamApi.m_lasterr);
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, ErrMsg);
                return false;                         // Fail: dcamapi_uninit()
            }
            int CamIndex = Convert.ToInt32(sCameraSN);
            if (MyDcamApi.m_devcount <= CamIndex)
            {
                ErrMsg = "CameraIndex is not right";
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, ErrMsg);
                return false;
            }
            MyDcam aMyDcam = new MyDcam();
            if (!aMyDcam.dev_open(CamIndex))
            {
                ErrMsg =CamStatusNG("dcamdev_open()", aMyDcam.m_lasterr);
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, ErrMsg);
                mydcam = null;
                return false;                         // Fail: dcamdev_open()
            }
            mydcam = aMyDcam;

            DCAMERR m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.SUBARRAYMODE, MODE.OFF);//640;1
            ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, CamStatusNG($"DCAMIDPROP.SUBARRAYMODE：0", m_lasterr));

            //设置一些参数
            m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.SENSORMODE_LINEBUNDLEHEIGHT, iFrameLines);//prop.getvalue(ref specData);
            ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, CamStatusNG($"SENSORMODE_LINEBUNDLEHEIGHT：{iFrameLines}", m_lasterr));

            m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.READOUT_DIRECTION, READOUT_DIRECTION.BACKWARD);//prop.getvalue(ref specData);
            ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, CamStatusNG($"READOUT_DIRECTION:{(double)READOUT_DIRECTION.BACKWARD}", m_lasterr));

            m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.SENSORMODE, SENSORMODE.TDI);//prop.getvalue(ref specData);
            ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, CamStatusNG($"SENSORMODE:{(double)SENSORMODE.TDI}", m_lasterr));

            m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.TRIGGERSOURCE, TRIGGERSOURCE.EXTERNAL);//prop.getvalue(ref specData);
            ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, CamStatusNG($"TRIGGERSOURCE:{(double)TRIGGERSOURCE.EXTERNAL}", m_lasterr));
            if (colorDepth == EnumColorDepth.Bit8)
            {
                string rtstring = "";
                m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.IMAGE_PIXELTYPE, (int)DCAM_PIXELTYPE.MONO8); rtstring = CamStatusNG($"IMAGE_PIXELTYPE:{DCAM_PIXELTYPE.MONO8}", m_lasterr);
                
                m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.BITSPERCHANNEL, BITSPERCHANNEL._8); rtstring += CamStatusNG($"IMAGE_PIXELTYPE:{_paramAOI.ColorDepth}", m_lasterr);
                
                m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.INTENSITYLUT_PAGE, 1);rtstring += CamStatusNG($"INTENSITYLUT_PAGE:1", m_lasterr);
                
                m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.INTENSITYLUT_MODE, INTENSITYLUT_MODE.PAGE); rtstring += CamStatusNG($"INTENSITYLUT_PAGE:{INTENSITYLUT_MODE.PAGE}", m_lasterr);

                ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, rtstring);
            }
            else
            {
                string rtstring = "";
                m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.IMAGE_PIXELTYPE, (int)DCAM_PIXELTYPE.MONO12); rtstring = CamStatusNG($"IMAGE_PIXELTYPE:{DCAM_PIXELTYPE.MONO12}", m_lasterr);

                m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.BITSPERCHANNEL, BITSPERCHANNEL._12); rtstring += CamStatusNG($"IMAGE_PIXELTYPE:{_paramAOI.ColorDepth}", m_lasterr);

                m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.INTENSITYLUT_PAGE, 0); rtstring += CamStatusNG($"INTENSITYLUT_PAGE:0", m_lasterr);

                m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.INTENSITYLUT_MODE, INTENSITYLUT_MODE.THROUGH); rtstring += CamStatusNG($"INTENSITYLUT_PAGE:{INTENSITYLUT_MODE.THROUGH}", m_lasterr);
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, rtstring);
            }

            //下面的尺寸设置按照binning后的尺寸设置
            int bin = 4096 / (_paramAOI.CCDCropPos * 2 + _paramAOI.ImgWidthOri);
            //设置AOI起始位置
            m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.SUBARRAYHPOS, _paramAOI.CCDCropPos*bin);//192*4;
            ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, CamStatusNG($"DCAMIDPROP.SUBARRAYHPOS：{_paramAOI.CCDCropPos * bin}", m_lasterr));
            //设置相机原始有效宽度

            m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.SUBARRAYHSIZE, _paramAOI.ImgWidthOri*bin);//640*4;
            ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, CamStatusNG($"DCAMIDPROP.SUBARRAYHSIZE：{_paramAOI.ImgWidthOri * bin}", m_lasterr));

            m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.SUBARRAYMODE, MODE.ON); 
            ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, CamStatusNG($"DCAMIDPROP.SUBARRAYMODE：1", m_lasterr));

            switch (bin)
            {
                case 1:
                    m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.BINNING, BINNING._1);//prop.getvalue(ref specData);
                    break;
                case 2:
                    m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.BINNING, BINNING._2);
                    break;
                case 4:
                    m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.BINNING, BINNING._4);
                    break;
                case 8:
                    m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.BINNING, BINNING._8);
                    break;
                case 16:
                    m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.BINNING, BINNING._16);
                    break;
            }
            
            ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, CamStatusNG($"BINNING:{bin}", m_lasterr));
            

            m_lasterr = dcamprop.setvalue(mydcam.m_hdcam, DCAMIDPROP.CONTRASTGAIN, _paramAOI.AnalogGain);//prop.getvalue(ref specData);
            ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, CamStatusNG($"CONTRASTGAIN:{_paramAOI.AnalogGain}", m_lasterr));


            #region 另一种设置参数 的方式
            ////设置图像高度，
            //MyDcamProp prop = new MyDcamProp(mydcam, DCAMIDPROP.SENSORMODE_LINEBUNDLEHEIGHT);
            //prop.setvalue(iFrameLines);
            //double v1 = 0;
            //prop.getvalue(ref v1);
            //ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"DCAMIDPROP.SENSORMODE_LINEBUNDLEHEIGHT:{v1}");
            ////设置扫描方向
            //prop = new MyDcamProp(mydcam, DCAMIDPROP.READOUT_DIRECTION);
            //prop.setvalue(READOUT_DIRECTION.BACKWARD);
            //double v2 = 0;
            //prop.getvalue(ref v2);
            //ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"DCAMIDPROP.READOUT_DIRECTION:{v2}");
            ////设置芯片模式
            //prop = new MyDcamProp(mydcam, DCAMIDPROP.SENSORMODE);
            //prop.setvalue(SENSORMODE.TDI);
            //double v3 = 0;
            //prop.getvalue(ref v3);
            //ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"DCAMIDPROP.SENSORMODE:{v3}");
            ////设置触发源
            //prop = new MyDcamProp(mydcam, DCAMIDPROP.TRIGGERSOURCE);
            //prop.setvalue(TRIGGERSOURCE.EXTERNAL);
            //double v4 = 0;
            //prop.getvalue(ref v4);
            //ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"DCAMIDPROP.TRIGGERSOURCE:{v4}");
            ////设置bin倍率
            //int bin = 4096 / _paramAOI.ImgWidthOri;
            //prop = new MyDcamProp(mydcam, DCAMIDPROP.BINNING); 
            //switch(bin)
            //{
            //    case 1:
            //        prop.setvalue(BINNING._1);
            //        break;
            //    case 2:
            //        prop.setvalue(BINNING._2);
            //        break;
            //    case 4:
            //        prop.setvalue(BINNING._4);
            //        break;
            //    case 8:
            //        prop.setvalue(BINNING._8);
            //        break;
            //    case 16:
            //        prop.setvalue(BINNING._16);
            //        break;
            //}
            //double v5 = 0;
            //prop.getvalue(ref v5);
            //ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"DCAMIDPROP.BINNING:{v5}");

            ////设置图像深度
            //prop = new MyDcamProp(mydcam, DCAMIDPROP.BITSPERCHANNEL);
            //prop.setvalue(colorDepth == EnumColorDepth.Bit8? BITSPERCHANNEL._8: BITSPERCHANNEL._12);
            #endregion

            // allocate frame buffer
            if (!mydcam.buf_alloc(FXGP.Instance.APUSystem.nRamRadio))
            {
                string text = $"dcambuf_alloc({FXGP.Instance.APUSystem.nRamRadio})";
                ErrMsg = CamStatusNG(text, mydcam.m_lasterr);
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, ErrMsg);
                return false;                     // Fail: dcambuf_alloc()
            }

            return true;
        }

        public void Uninitialize()
        {
            StopGrab();
            FreeCamera();
            _bInitialized = false;
        }
        private void FreeCamera()
        {
            //释放buffer
            if (mydcam != null)
            {
                mydcam.buf_release();
                if (!mydcam.dev_close())
                {
                    string msg = CamStatusNG("dcamdev_close()", mydcam.m_lasterr);
                    ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, msg);
                    return;                         // Fail: dcamdev_close()
                }

                mydcam = null;
            }
            MyDcamApi.uninit();
        }
         
        private bool StartGrab()
        {
           
            mydcam.m_capmode = DCAMCAP_START.SEQUENCE;

            if (!mydcam.cap_start())
            {
                // acquisition was failed. In this sample, frame buffer is also released.
                string msg = CamStatusNG("dcamcap_start()", mydcam.m_lasterr);
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, msg);
                return false;                   
            }
            MyThreadCapture_Start();            // start monitoring thread
            return true;
           
        }
        private void StopGrab()
        {
            
            if (!mydcam.cap_stop())
            {
                string msg = CamStatusNG("dcamcap_stop()", mydcam.m_lasterr);
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Error, msg);
                
            }
            MyThreadCapture_Abort();
        
        }
        private void MyThreadCapture_Start()
        {
            m_threadCapture = new Thread(new ThreadStart(OnThreadCapture));

            m_threadCapture.IsBackground = true;
            m_threadCapture.Start();
        }
        void MyThreadCapture_Abort()
        {
            if (m_threadCapture != null)
            {
                if (mydcamwait != null)
                    mydcamwait.abort(); 

                m_threadCapture.Abort();
            }
        }


        public bool CAMERA_SCANBEGIN(string iRunID, int iChannel)
        {

            UpdateParam(iChannel);
            _iRunID = iRunID;
            _iChannel = iChannel;

            return CAMERA_LINEBEGIN(iRunID, iChannel, 0);
        }


        /// 全幅扫描结束
        /// <param name="hPack"></param>
        public void CAMERA_SCANEND(string iRunID, int iChannel)
        {
            CAMERA_LINEEND(iRunID, iChannel, _iRow);
        }


        /// 单行扫描开始
        public bool CAMERA_LINEBEGIN(string iRunID, int iChannel, int iRow)
        {
            
            _iRow = iRow;

            _iColIdx = 0;
            if (!StartGrab()) return false;
            return true;
        }



        public void CAMERA_LINEEND(string iRunID, int iChannel, int iRow)
        {
            StopGrab();
        }

        public bool CAMERA_RESET(bool bResetServer, int sType)
        {
            throw new NotImplementedException();
        }
    }
}
