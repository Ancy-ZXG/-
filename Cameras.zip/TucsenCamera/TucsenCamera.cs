﻿using AK.Algo.PDI;
using AK.FX.Define;
using AK.HW.Camera;
using AK.ICW.Proc;
using AK.Tools;
using ApuDefine;
using DALSA.SaperaLT.SapClassBasic;
using HalconDotNet;
using Newtonsoft.Json.Linq;
using OpenCvSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AK.HW.Camera
{
    internal class TucsenCamera : ICameraTDI
    {
        private static Dictionary<int, TucsenCamera> _dicInstance = new Dictionary<int, TucsenCamera>();
        public static TucsenCamera Instance(int Index)
        {
            TucsenCamera camera = null;
            lock (_dicInstance)
            {
                if (!_dicInstance.ContainsKey(Index))
                {
                    camera = new TucsenCamera();
                    camera.Index = Index;
                    _dicInstance.Add(Index, camera);
                }
                else
                {
                    camera = _dicInstance[Index];
                }
            }
            return camera;
        }
        private int Index { get; set; } = 0;
        private string _iRunID = "";
        private int _iChannel = 0;
        private int _iRow = 0;
      


        //private int _iCallbackCount = 0;
        private bool _bInitialized = false;
        private ParamAOI _paramAOI = null;

        private int _iColIdx_0 = 0;
        private int _iColIdx_1 = 0;
        static TucsenObject[] m_tucsenObject = new TucsenObject[2];
        public TucsenCamera()
        {
            m_tucsenObject[0] = new TucsenObject();
            m_tucsenObject[1] = new TucsenObject();

            try
            {
                TucsenObject.InitTuscenSystem();
            }
            catch(Exception ex) 
            {

                FXGP.PushRunEvent("PushLog", ref FXGP.obj, $"TucsenObject.InitTuscenSystem:{ex.Message}");
            }
        }
        ~TucsenCamera()
        {
            TucsenObject.UnInitTuscenSystem();
        }
        public void UpdateParam(int EnableCh)
        {

            _paramAOI = FXGP.Instance.GetChannelAOIParam(EnableCh);
        }


        public bool CAMERA_LINEBEGIN(string iRunID, int iChannel, int iRow)
        {
            _iRow = iRow;
            _iColIdx_0 = 0;
            _iColIdx_1 = 0;
            if (!StartGrab()) return false;
            return true;
        }

        public void CAMERA_LINEEND(string iRunID, int iChannel, int iRow)
        {
            StopGrab();
        }

        public bool CAMERA_SCANBEGIN(string iRunID, int iChannel)
        {

            UpdateParam(iChannel);
            _iRunID = iRunID;
            _iChannel = iChannel;
      

            return CAMERA_LINEBEGIN(iRunID, iChannel, 0);
        }


        /// 全幅扫描结束
        /// <param name="hPack"></param>
        public void CAMERA_SCANEND(string iRunID, int iChannel)
        {
            CAMERA_LINEEND(iRunID, iChannel, _iRow);
        }

        


        public int GetCallBackTimes()
        {
            return Math.Min(_iColIdx_0,_iColIdx_1);
        }
       

        Stopwatch sw = Stopwatch.StartNew();
        
        void Data_XferNotify(IntPtr pContext, IntPtr img, int offsetx, int offsety, int w, int h, int frameid, int CardIndex)
        {

            try
            {
                int iBufWidth = w;
                int iBufHeight = h;

                TucsenGrabImageInfo info = new TucsenGrabImageInfo();
                info.RunID = _iRunID;
                info.Channel = _iChannel;
                info.Row = _iRow;
                info.Col = frameid - 1;

                int iBytes = 1;
                if (_paramAOI.ColorDepth != FX.Define.EnumColorDepth.Bit8)
                    iBytes = 2;

                info.CameraImageData = img;
                info.CameraImageWidth = iBufWidth;
                info.CameraImageHeight = iBufHeight;
                info.CameraImageBytes = iBytes;
                info.CameraImageIndex = frameid;

                info.CameraImageOffsetX = offsetx;
                info.CameraImageOffsetY = offsety;


                ImageTucsenCopy.Instance.PushImage(info);


                if (CardIndex == 0)
                    _iColIdx_0 = frameid;
                else
                    _iColIdx_1 = frameid;



            }
            catch (Exception e)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, e.Message);
            }

            ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"RunID={_iRunID},CardIndex={CardIndex},Image {frameid} Call back Time intervals：{sw.ElapsedMilliseconds}ms");
            //Debug.WriteLine($"RunID={_iRunID},CardIndex={CardIndex},Image {frameid} Call back Time intervals：{sw.ElapsedMilliseconds}ms");
            sw.Restart();

            return;
        }


        string mainSN = "NONE";
        int mainCardIndex = -1;
        string slaveSN = "NONE";
        int slaveIndex = -1;
        ProcessOverHandler processOverHandler = null;
        public bool Initialize(int EnableCh)
        {
            UpdateParam(EnableCh);
            if (_bInitialized)
            {
                Uninitialize();
                Thread.Sleep(1500);
            }

            string[] SNs = FXGP.Instance.APUSystem.CameraSerialNumber.Split(new char[] { ';', ',', '，' });

            mainSN = "NONE";
            mainCardIndex = -1;
            slaveSN = "NONE";
            slaveIndex = -1;

            int cardNum = TucsenObject.GetTucsenCardNum();
            if (cardNum < SNs.Length)
            {
                return false;
            }
            if (SNs.Length > 0)
            {
                mainSN = SNs[0];
                if (SNs.Length > 1)
                    slaveSN = SNs[1];
            }


            for (int index = 0; index < cardNum; index++)
            {
                string ifID = TucsenObject.GetTucenCardIfID(index);
                if (ifID.Contains(mainSN))
                {
                    mainCardIndex = index;
                }
                else if (ifID.Contains(slaveSN))
                {
                    slaveIndex = index;
                }
            }

            string configRoot = Application.StartupPath + "\\config\\";

            string[] jsonfileAry = _paramAOI.CcfFile.Split(new char[] { ';', '；' });
            string[] jsons1 = jsonfileAry[0].Split(new char[] { ';', ',', '，' });
            string[] jsons2 = jsonfileAry[1].Split(new char[] { ';', ',', '，' });
            processOverHandler = new ProcessOverHandler(Data_XferNotify);
            if (mainCardIndex != -1)
            {
                
                _bInitialized = InitCamera(EnableCh, mainCardIndex, FXGP.Instance.APUSystem.nRamRadio, "", configRoot + jsons1[0], configRoot + jsons1[1], processOverHandler, m_tucsenObject[0]);
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"Camera1 Init Result:{_bInitialized},CH:{EnableCh},CCF:{jsons1[0]}, {jsons1[1]}");
            }
            else//没有主相机就直接返回
            {
                FXGP.PushRunEvent("PushLog", ref FXGP.obj, "没有主相机");
                return false;
            }
            if (slaveIndex != -1)
            {
    
                _bInitialized &= InitCamera(EnableCh, slaveIndex, FXGP.Instance.APUSystem.nRamRadio, "", configRoot + jsons2[0], configRoot + jsons2[1], processOverHandler, m_tucsenObject[1]);
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Info, $"Camera2 Init Result:{_bInitialized},CH:{EnableCh},CCF:{jsons2[0]}, {jsons2[1]}");

            }
            else//没有辅助相机就直接返回
            {
                FXGP.PushRunEvent("PushLog", ref FXGP.obj, "没有副相机");
                return false;
            }
            return _bInitialized;
        }
        

        bool InitCamera(int iCH,int CardIndex,int buffercount,string interfacejson,string devicejson, string camerajson,ProcessOverHandler callback,TucsenObject tucsenObject)
        {
            int nRet = 0;
            try
            {
                Dictionary<string, object> algParam = FXGP.Instance.GetChannelAlgParam(iCH);

                if (!algParam.ContainsKey("Segmentation"))
                    return false;

                ParamAlgSeg paramAlgSeg = ((AK.Algo.PDI.ParamAlgSeg)algParam["Segmentation"]);
                nRet = tucsenObject.InitGrabCard(CardIndex, interfacejson, devicejson, camerajson, callback, buffercount);
                if (nRet != 0)
                {
                    //1- scap_create_card failed
                    //3- set_scap_device failed
                    //4- set_scap_camera failed
                    //5- Buffer Malloc failed
                    //6- Buffer Regist failed
                }
                else
                    return true;

            }
            catch (Exception e)
            {
                ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, e);
            }
            ZlxgLog.Instance.WriteLog(Log4NetLevel.Exception, $"InitGrabCard{CardIndex}:返回:{nRet}");
            return false;
        }

        public void Uninitialize()
        {
            StopGrab();
            FreeCamera();
            //TucsenObject.UnInitTuscenSystem();
            _bInitialized = false;
        }
        private void FreeCamera()
        {
            //使用胡勇的接口
            if(mainCardIndex !=-1)  m_tucsenObject[0].UnInitGrabCard();

            if (slaveIndex != -1) m_tucsenObject[1].UnInitGrabCard();
        }

        private bool StartGrab()
        {
            bool bRet = false;
            ImageTucsenCopy.Instance.ClearCameraImageDicList();
            //开流 先从后主
            if (slaveIndex != -1)
                bRet = m_tucsenObject[1].StartGrab();
            if (mainCardIndex != -1)
                bRet &= m_tucsenObject[0].StartGrab();
            //使用胡勇的接口
            return bRet;

        }

        private void StopGrab()
        {
            //停流先主后从
            if (mainCardIndex != -1)
                m_tucsenObject[0].StopGrab();
            if (slaveIndex != -1)
                m_tucsenObject[1].StopGrab();

        }

        public bool CAMERA_RESET(bool bResetServer, int sType)
        {
            throw new NotImplementedException();
        }
    }
}
