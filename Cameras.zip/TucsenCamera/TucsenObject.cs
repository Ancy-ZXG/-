﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
namespace AK.HW.Camera
{
    public delegate void ProcessOverHandler(IntPtr pContext, IntPtr img, int offsetx, int offsety, int w, int h, int frameid, int CardIndex);


    public class TucsenObject
    {
        #region 导出 函数

        [DllImport("TucsenCamera_2Card.dll")]
        private static extern bool Tucsen_Init();//初始化

        [DllImport("TucsenCamera_2Card.dll")]
        private static extern void Tucsen_Release();

        [DllImport("TucsenCamera_2Card.dll")]
        private static extern int GetCardNum();

        [DllImport("TucsenCamera_2Card.dll")]
        private static extern void GetCardIfID(int cardindex, ref byte str, ref int len);

        [DllImport("TucsenCamera_2Card.dll")]
        private static extern int Tucsen_Card_Init(int CardIndex, string interfaceFile, string deviceFile, string camraFile, ref IntPtr pGrabObjecct, ProcessOverHandler callback, int BufferNum = 100);

        [DllImport("TucsenCamera_2Card.dll")]
        private static extern void Tucsen_Card_Release(IntPtr pGrabObjecct);

        [DllImport("TucsenCamera_2Card.dll")]
        private static extern bool Tucsen_Card_StartGrab(IntPtr pGrabObjecct);
        [DllImport("TucsenCamera_2Card.dll")]
        private static extern void Tucsen_Card_StopGrab(IntPtr pGrabObjecct);



        #endregion

        //外包层
        private IntPtr m_pNativeObject = IntPtr.Zero; // 保存创建的C++对象的指针


        public static bool InitTuscenSystem()
        {
            return Tucsen_Init();

        }

        public static void UnInitTuscenSystem()
        {
            try
            {
                Tucsen_Release();
            }
            catch (Exception ex)
            {

            }

        }

        public static int GetTucsenCardNum()
        {
            return GetCardNum();
        }

        public static string GetTucenCardIfID(int CardIndex)
        {
            string ifid = "";

            byte[] error = new byte[128];
            int len = 0;
            GetCardIfID(CardIndex, ref error[0], ref len);
            ifid = System.Text.Encoding.Default.GetString(error, 0, len);

            return ifid;
        }


        public int InitGrabCard(int CardIndex, string interfaceFile, string deviceFile, string camraFile, ProcessOverHandler callback, int BufferNum = 100)
        {
            return Tucsen_Card_Init(CardIndex, interfaceFile, deviceFile, camraFile, ref m_pNativeObject, callback, BufferNum);
        }

        public void UnInitGrabCard()
        {
            if (m_pNativeObject == IntPtr.Zero)
                return;
            Tucsen_Card_Release(m_pNativeObject);
        }
        public bool StartGrab()
        {
            if (m_pNativeObject == IntPtr.Zero)
                return false;
            return Tucsen_Card_StartGrab(m_pNativeObject);

        }

        public void StopGrab()
        {
            if (m_pNativeObject == IntPtr.Zero)
                return;
            Tucsen_Card_StopGrab(m_pNativeObject);
        }


    }
}
