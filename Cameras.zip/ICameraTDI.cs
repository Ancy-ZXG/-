﻿using System;

namespace AK.HW.Camera
{
    public interface ICameraTDI
    {
        bool Initialize(int EnableCh);
        void Uninitialize();
        bool CAMERA_SCANBEGIN(string iRunID, int iChannel);
        void CAMERA_SCANEND(string iRunID, int iChannel);
        bool CAMERA_LINEBEGIN(string iRunID, int iChannel, int iRow);
        void CAMERA_LINEEND(string iRunID, int iChannel, int iRow);
        bool CAMERA_RESET(bool bResetServer,int sType);

        void UpdateParam(int EnableCh);

        int GetCallBackTimes();
    }
}