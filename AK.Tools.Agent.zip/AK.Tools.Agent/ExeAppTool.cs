﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Runtime.InteropServices;
using ZlxgLib;

namespace AK.Tools.Agent
{
    public class ExeAppTool
    {
        //private static readonly int KILL_YOU_MESSAGE = 0X400 + 2;
        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

        [return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool PostThreadMessage(int threadId, uint msg, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll", EntryPoint = "GetWindowThreadProcessId")]
        private static extern int GetWindowThreadProcessId(IntPtr hwnd, out int pid);

        public static void StartProcess(string sAppFile, string sArguments = "")
        {
            string sProName = Path.GetFileNameWithoutExtension(sAppFile);
            string sPath = Path.GetDirectoryName(sAppFile);
            System.IO.Directory.SetCurrentDirectory(sPath);
            Process[] aProcess = Process.GetProcessesByName(sAppFile);
            foreach (Process proOld in aProcess)
                if (proOld.ProcessName.Equals(sProName))
                    return;
            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = sAppFile;
            info.Arguments = sArguments;
            info.WindowStyle = ProcessWindowStyle.Normal;
            info.WorkingDirectory = sPath;
            Process proNew = Process.Start(info);
        }

        public static void CloseProcess(string sProName)
        {
            Process[] aProcess = Process.GetProcessesByName(sProName);
            foreach (Process pro in aProcess)
            {
                if (!pro.ProcessName.Equals(sProName))
                    continue;
                //SendMessage(pro.MainWindowHandle, KILL_YOU_MESSAGE, new IntPtr(0x01), IntPtr.Zero);  //对于非隐藏窗口是OK的
                //pro.CloseMainWindow();
                try
                {
                    if (pro.Threads.Count > 0)
                        PostThreadMessage(pro.Threads[0].Id, 0x80F0, IntPtr.Zero, IntPtr.Zero);  //先礼后兵
                    if (!pro.WaitForExit(3000)) //还不退出不客气了
                        pro.Kill();
                }
                catch (System.Exception )
                {
                }
            }
        }

        public static Process FindProcess(string sProName)
        {
            Process[] aProcess = Process.GetProcessesByName(sProName);
            foreach (Process pro in aProcess)
                if (pro.ProcessName.Equals(sProName))
                    return pro;
            return null;
        }

    }
}
