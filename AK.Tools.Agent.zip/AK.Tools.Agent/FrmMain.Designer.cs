﻿namespace AK.Tools.Agent
{
    partial class FrmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem("");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.btnCloseAll = new System.Windows.Forms.Button();
            this.btnStartAll = new System.Windows.Forms.Button();
            this.btnDelItem = new System.Windows.Forms.Button();
            this.btnAddItem = new System.Windows.Forms.Button();
            this.listViewApp = new System.Windows.Forms.ListView();
            this.colHeadEnable = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colHeadServiceType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colHeadServiceName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colHeadDelay = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colHeadPath = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabMain = new System.Windows.Forms.TabControl();
            this.pgeReload = new System.Windows.Forms.TabPage();
            this.btnStopSelected = new System.Windows.Forms.Button();
            this.btnRestartSelected = new System.Windows.Forms.Button();
            this.btnEditItem = new System.Windows.Forms.Button();
            this.pgeUpdate = new System.Windows.Forms.TabPage();
            this.btnLockGPU = new System.Windows.Forms.Button();
            this.btnDeleteAllDisk = new System.Windows.Forms.Button();
            this.btnTest = new System.Windows.Forms.Button();
            this.pgeSetup = new System.Windows.Forms.TabPage();
            this.propAgent = new System.Windows.Forms.PropertyGrid();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.显示ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timerCheckApp = new System.Windows.Forms.Timer(this.components);
            this.tabMain.SuspendLayout();
            this.pgeReload.SuspendLayout();
            this.pgeUpdate.SuspendLayout();
            this.pgeSetup.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtMessage
            // 
            this.txtMessage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtMessage.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtMessage.Location = new System.Drawing.Point(3, 352);
            this.txtMessage.Multiline = true;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMessage.Size = new System.Drawing.Size(752, 198);
            this.txtMessage.TabIndex = 8;
            // 
            // btnCloseAll
            // 
            this.btnCloseAll.Location = new System.Drawing.Point(609, 20);
            this.btnCloseAll.Name = "btnCloseAll";
            this.btnCloseAll.Size = new System.Drawing.Size(77, 45);
            this.btnCloseAll.TabIndex = 4;
            this.btnCloseAll.Text = "全部关闭";
            this.btnCloseAll.UseVisualStyleBackColor = true;
            this.btnCloseAll.Click += new System.EventHandler(this.btnCloseAll_Click);
            // 
            // btnStartAll
            // 
            this.btnStartAll.Location = new System.Drawing.Point(526, 20);
            this.btnStartAll.Name = "btnStartAll";
            this.btnStartAll.Size = new System.Drawing.Size(77, 45);
            this.btnStartAll.TabIndex = 5;
            this.btnStartAll.Text = "全部重启";
            this.btnStartAll.UseVisualStyleBackColor = true;
            this.btnStartAll.Click += new System.EventHandler(this.btnStartAll_Click);
            // 
            // btnDelItem
            // 
            this.btnDelItem.Location = new System.Drawing.Point(102, 20);
            this.btnDelItem.Name = "btnDelItem";
            this.btnDelItem.Size = new System.Drawing.Size(77, 45);
            this.btnDelItem.TabIndex = 6;
            this.btnDelItem.Text = "删除启动项";
            this.btnDelItem.UseVisualStyleBackColor = true;
            this.btnDelItem.Click += new System.EventHandler(this.btnDelItem_Click);
            // 
            // btnAddItem
            // 
            this.btnAddItem.Location = new System.Drawing.Point(19, 20);
            this.btnAddItem.Name = "btnAddItem";
            this.btnAddItem.Size = new System.Drawing.Size(77, 45);
            this.btnAddItem.TabIndex = 7;
            this.btnAddItem.Text = "添加启动项";
            this.btnAddItem.UseVisualStyleBackColor = true;
            this.btnAddItem.Click += new System.EventHandler(this.btnAddItem_Click);
            // 
            // listViewApp
            // 
            this.listViewApp.BackColor = System.Drawing.SystemColors.Control;
            this.listViewApp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listViewApp.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colHeadEnable,
            this.colHeadServiceType,
            this.colHeadServiceName,
            this.colHeadDelay,
            this.colHeadPath});
            this.listViewApp.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.listViewApp.Font = new System.Drawing.Font("新宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.listViewApp.FullRowSelect = true;
            this.listViewApp.GridLines = true;
            this.listViewApp.HideSelection = false;
            listViewItem1.StateImageIndex = 0;
            listViewItem2.StateImageIndex = 0;
            listViewItem3.StateImageIndex = 0;
            listViewItem4.StateImageIndex = 0;
            this.listViewApp.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4});
            this.listViewApp.Location = new System.Drawing.Point(3, 85);
            this.listViewApp.Name = "listViewApp";
            this.listViewApp.Size = new System.Drawing.Size(752, 267);
            this.listViewApp.TabIndex = 31;
            this.listViewApp.UseCompatibleStateImageBehavior = false;
            this.listViewApp.View = System.Windows.Forms.View.Details;
            this.listViewApp.DoubleClick += new System.EventHandler(this.listViewApp_DoubleClick);
            // 
            // colHeadEnable
            // 
            this.colHeadEnable.Text = "序号";
            this.colHeadEnable.Width = 50;
            // 
            // colHeadServiceType
            // 
            this.colHeadServiceType.Text = "类别";
            this.colHeadServiceType.Width = 80;
            // 
            // colHeadServiceName
            // 
            this.colHeadServiceName.Text = "名称";
            this.colHeadServiceName.Width = 80;
            // 
            // colHeadDelay
            // 
            this.colHeadDelay.Text = "延时";
            this.colHeadDelay.Width = 80;
            // 
            // colHeadPath
            // 
            this.colHeadPath.Text = "路径";
            this.colHeadPath.Width = 600;
            // 
            // tabMain
            // 
            this.tabMain.Alignment = System.Windows.Forms.TabAlignment.Right;
            this.tabMain.Controls.Add(this.pgeReload);
            this.tabMain.Controls.Add(this.pgeUpdate);
            this.tabMain.Controls.Add(this.pgeSetup);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.Location = new System.Drawing.Point(0, 0);
            this.tabMain.Multiline = true;
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(784, 561);
            this.tabMain.TabIndex = 32;
            // 
            // pgeReload
            // 
            this.pgeReload.Controls.Add(this.btnStopSelected);
            this.pgeReload.Controls.Add(this.btnRestartSelected);
            this.pgeReload.Controls.Add(this.btnEditItem);
            this.pgeReload.Controls.Add(this.listViewApp);
            this.pgeReload.Controls.Add(this.txtMessage);
            this.pgeReload.Controls.Add(this.btnAddItem);
            this.pgeReload.Controls.Add(this.btnDelItem);
            this.pgeReload.Controls.Add(this.btnStartAll);
            this.pgeReload.Controls.Add(this.btnCloseAll);
            this.pgeReload.Location = new System.Drawing.Point(4, 4);
            this.pgeReload.Name = "pgeReload";
            this.pgeReload.Padding = new System.Windows.Forms.Padding(3);
            this.pgeReload.Size = new System.Drawing.Size(758, 553);
            this.pgeReload.TabIndex = 0;
            this.pgeReload.Text = "重启";
            this.pgeReload.UseVisualStyleBackColor = true;
            // 
            // btnStopSelected
            // 
            this.btnStopSelected.Location = new System.Drawing.Point(443, 20);
            this.btnStopSelected.Name = "btnStopSelected";
            this.btnStopSelected.Size = new System.Drawing.Size(77, 45);
            this.btnStopSelected.TabIndex = 34;
            this.btnStopSelected.Text = "停止选中";
            this.btnStopSelected.UseVisualStyleBackColor = true;
            this.btnStopSelected.Click += new System.EventHandler(this.btnStopSelected_Click);
            // 
            // btnRestartSelected
            // 
            this.btnRestartSelected.Location = new System.Drawing.Point(360, 20);
            this.btnRestartSelected.Name = "btnRestartSelected";
            this.btnRestartSelected.Size = new System.Drawing.Size(77, 45);
            this.btnRestartSelected.TabIndex = 33;
            this.btnRestartSelected.Text = "重启选中";
            this.btnRestartSelected.UseVisualStyleBackColor = true;
            this.btnRestartSelected.Click += new System.EventHandler(this.btnRestartSelected_Click);
            // 
            // btnEditItem
            // 
            this.btnEditItem.Location = new System.Drawing.Point(185, 20);
            this.btnEditItem.Name = "btnEditItem";
            this.btnEditItem.Size = new System.Drawing.Size(77, 45);
            this.btnEditItem.TabIndex = 32;
            this.btnEditItem.Text = "编辑启动项";
            this.btnEditItem.UseVisualStyleBackColor = true;
            this.btnEditItem.Click += new System.EventHandler(this.btnEditItem_Click);
            // 
            // pgeUpdate
            // 
            this.pgeUpdate.Controls.Add(this.btnLockGPU);
            this.pgeUpdate.Controls.Add(this.btnDeleteAllDisk);
            this.pgeUpdate.Controls.Add(this.btnTest);
            this.pgeUpdate.Location = new System.Drawing.Point(4, 4);
            this.pgeUpdate.Name = "pgeUpdate";
            this.pgeUpdate.Padding = new System.Windows.Forms.Padding(3);
            this.pgeUpdate.Size = new System.Drawing.Size(758, 553);
            this.pgeUpdate.TabIndex = 1;
            this.pgeUpdate.Text = "更新";
            this.pgeUpdate.UseVisualStyleBackColor = true;
            // 
            // btnLockGPU
            // 
            this.btnLockGPU.Location = new System.Drawing.Point(520, 189);
            this.btnLockGPU.Name = "btnLockGPU";
            this.btnLockGPU.Size = new System.Drawing.Size(147, 45);
            this.btnLockGPU.TabIndex = 2;
            this.btnLockGPU.Text = "3080显卡锁频";
            this.btnLockGPU.UseVisualStyleBackColor = true;
            this.btnLockGPU.Click += new System.EventHandler(this.btnLockGPU_Click);
            // 
            // btnDeleteAllDisk
            // 
            this.btnDeleteAllDisk.Location = new System.Drawing.Point(520, 111);
            this.btnDeleteAllDisk.Name = "btnDeleteAllDisk";
            this.btnDeleteAllDisk.Size = new System.Drawing.Size(147, 45);
            this.btnDeleteAllDisk.TabIndex = 1;
            this.btnDeleteAllDisk.Text = "删除所有共享盘";
            this.btnDeleteAllDisk.UseVisualStyleBackColor = true;
            this.btnDeleteAllDisk.Click += new System.EventHandler(this.btnDeleteAllDisk_Click);
            // 
            // btnTest
            // 
            this.btnTest.Location = new System.Drawing.Point(518, 41);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(147, 45);
            this.btnTest.TabIndex = 0;
            this.btnTest.Text = "创建共享盘测试";
            this.btnTest.UseVisualStyleBackColor = true;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // pgeSetup
            // 
            this.pgeSetup.Controls.Add(this.propAgent);
            this.pgeSetup.Location = new System.Drawing.Point(4, 4);
            this.pgeSetup.Name = "pgeSetup";
            this.pgeSetup.Padding = new System.Windows.Forms.Padding(3);
            this.pgeSetup.Size = new System.Drawing.Size(758, 553);
            this.pgeSetup.TabIndex = 0;
            this.pgeSetup.Text = "设置";
            this.pgeSetup.UseVisualStyleBackColor = true;
            // 
            // propAgent
            // 
            this.propAgent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.propAgent.Location = new System.Drawing.Point(3, 3);
            this.propAgent.Name = "propAgent";
            this.propAgent.Size = new System.Drawing.Size(752, 547);
            this.propAgent.TabIndex = 261;
            this.propAgent.PropertyValueChanged += new System.Windows.Forms.PropertyValueChangedEventHandler(this.propAgent_PropertyValueChanged);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.ContextMenuStrip = this.contextMenuStrip1;
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "代理";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseDoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.显示ToolStripMenuItem,
            this.退出ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(101, 48);
            // 
            // 显示ToolStripMenuItem
            // 
            this.显示ToolStripMenuItem.Name = "显示ToolStripMenuItem";
            this.显示ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.显示ToolStripMenuItem.Text = "显示";
            this.显示ToolStripMenuItem.Click += new System.EventHandler(this.显示ToolStripMenuItem_Click);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.退出ToolStripMenuItem.Text = "退出";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click);
            // 
            // timerCheckApp
            // 
            this.timerCheckApp.Interval = 3000;
            this.timerCheckApp.Tick += new System.EventHandler(this.timerCheckApp_Tick);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.tabMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "代理";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.tabMain.ResumeLayout(false);
            this.pgeReload.ResumeLayout(false);
            this.pgeReload.PerformLayout();
            this.pgeUpdate.ResumeLayout(false);
            this.pgeSetup.ResumeLayout(false);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Button btnCloseAll;
        private System.Windows.Forms.Button btnStartAll;
        private System.Windows.Forms.Button btnDelItem;
        private System.Windows.Forms.Button btnAddItem;
        public System.Windows.Forms.ListView listViewApp;
        private System.Windows.Forms.ColumnHeader colHeadEnable;
        private System.Windows.Forms.ColumnHeader colHeadDelay;
        private System.Windows.Forms.ColumnHeader colHeadPath;
        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage pgeReload;
        private System.Windows.Forms.TabPage pgeUpdate;
        private System.Windows.Forms.TabPage pgeSetup;
        private System.Windows.Forms.PropertyGrid propAgent;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ColumnHeader colHeadServiceType;
        private System.Windows.Forms.ColumnHeader colHeadServiceName;
        private System.Windows.Forms.Button btnEditItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 显示ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.Button btnStopSelected;
        private System.Windows.Forms.Button btnRestartSelected;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.Timer timerCheckApp;
        private System.Windows.Forms.Button btnDeleteAllDisk;
        private System.Windows.Forms.Button btnLockGPU;
    }
}

