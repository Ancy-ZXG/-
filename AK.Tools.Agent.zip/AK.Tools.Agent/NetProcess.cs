﻿using System;
using System.Windows.Forms;
using NetUtil;
using Newtonsoft.Json.Linq;
using System.IO;
using AK.Tools;
using ZlxgLib;

namespace AK.Tools.Agent
{
    public delegate bool OnClientEventDelegate(string sFromPoint, string sEventType, params object[] aEventParam);
    public class NetProcess
    {
        private static NetProcess _instance = null;
        public static NetProcess Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new NetProcess();
                return _instance;
            }
        }
        public event OnClientEventDelegate OnClientEvent = null;
        private CxNetServer _netServer = new CxNetServer();
        private object _objSendLock = new object();
        public ParamAgent ParamAgent { get; set; } = new ParamAgent();


        /// <summary>
        /// 开始服务端
        /// </summary>
        public void StartServer(int iServicePort = 8000)
        {
            _netServer.RecvBufferSize = 128 * 1024 * 1024;
            _netServer.SendBufferSize = 128 * 1024 * 1024;
            _netServer.BufferSize = 128 * 1024 * 1024;
            _netServer.StartServer("AgentNetServer", iServicePort, ServerNetEvent);

        }

        /// <summary>
        /// 停止服务端
        /// </summary>
        public void StopServer()
        {
            _netServer.StopServer();
        }


        public bool ServerNetEvent(string sFromPoint, string sEventType, params object[] aEventParam)
        {
            if (sEventType == "NET_STARTSERVER")
            {
                OnClientEvent?.Invoke(sFromPoint, "MESSAGE_APPEND", $"{sEventType}\t{sFromPoint}");
            }
            else if (sEventType == "NET_STOPSERVER")
            {
                OnClientEvent?.Invoke(sFromPoint, "MESSAGE_APPEND", $"{sEventType}\t{sFromPoint}");
            }
            else if (sEventType == "NET_CONNECTED")
            {
                OnClientEvent?.Invoke(sFromPoint, "MESSAGE_APPEND", $"{sEventType}\t{sFromPoint}");

                if (ParamAgent.ConnectLinkShareDisk)
                {
                    //DriveInfo di = new DriveInfo("v:");
                    //if (!di.IsReady)
                    //    ConnectSharedFolder.ExecBatFile(Application.StartupPath + "\\v.bat");

                    if (ParamAgent.NetShareDisk != null)
                    {
                       // ConnectSharedFolder.DeleteAllDisk();
                        for (int i = 0; i < ParamAgent.NetShareDisk.Length; i++)
                        {
                            System.IO.DriveInfo di = new DriveInfo($"{ParamAgent.NetShareDisk[i].DiskName}:");
                            if (!di.IsReady)
                            {
                                if (ParamAgent.NetShareDisk[i].Enable)
                                {
                                    ConnectSharedFolder.RebuildShareNetDisk(Application.StartupPath + $"\\v.bat", ParamAgent.NetShareDisk[i].IP, ParamAgent.NetShareDisk[i].DiskName.ToLower());
                                }
                            }
                        }
                    }
                }
            }
            else if (sEventType == "NET_DISCONNECTED")
            {
                OnClientEvent?.Invoke(sFromPoint, "MESSAGE_APPEND", $"{sEventType}\t{sFromPoint}");
            }
            else if (sEventType == "NET_RECONNECTING")
            {
                OnClientEvent?.Invoke(sFromPoint, "MESSAGE_APPEND", $"{sEventType}\t{sFromPoint}");
            }
            else if (sEventType == "NET_RECEIVED")
            {
                string sKey = (string)aEventParam[0];
                byte[] aPack = (byte[])aEventParam[1];
                PROCESS_NET_RECEIVED(sFromPoint, sEventType, sKey, aPack);
            }
            return true;
        }


        //直接回复:快速任务
        //稍等回复+完成回复:耗时任务
        public string PROCESS_NET_RECEIVED(string sFromPoint, string sEventType, params object[] aEventParam)
        {
            string sText = "";
            try
            {
                string sCmdType = (string)aEventParam[0];
                byte[] aBuffer = (byte[])aEventParam[1];
                CxPack pack = new CxPack();
                pack.SetPackBuffer(aBuffer);
                string sJson = pack.PopString();
                JObject oJson = JObject.Parse(sJson);
                int iPackID = -1;
                var vTemp = oJson["PackID"];
                if (vTemp != null)
                    iPackID = (int)vTemp;
                ECHO_MESSAGE(sFromPoint, sEventType, iPackID);
                if (sCmdType == "AGENT_IPU_RESTART" || sCmdType == "AGENT_IPU_STOP" || sCmdType == "AGENT_SHUTDOWN" || sCmdType == "AGENT_IPU_UPDATE")
                {
                    PROCESS_AGENT_IPU(sFromPoint, sEventType, sCmdType, iPackID, oJson);
                }
                else if (sCmdType == "AGENT_VER_GETINFO" || sCmdType == "AGENT_VER_UPDATE")
                {
                    PROCESS_AGENT_VER(sFromPoint, sEventType, sCmdType, iPackID, oJson, pack);
                }
                sText = sCmdType + "\r\n" + sJson;
                pack.Clear();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message + "\r\n" + ex.StackTrace, "错误");
            }
            OnClientEvent?.Invoke(sFromPoint, "MESSAGE_APPEND", $"{sText}\r\n");
            return sText;
        }

        public void ECHO_MESSAGE(string sFromPoint, string sEventType, int iPackID)
        {
            JObject oJson = new JObject();
            oJson["PackID"] = iPackID;
            oJson["Type"] = "Received";
            SendJson(sFromPoint, sEventType, oJson);
        }

        //public T GetJsonValue<T>(JObject oJson,string sName) where T : new()
        //{
        //    T oValue = new T();
        //    var vTemp = oJson[sName];
        //    if (vTemp == null)
        //        return oValue;
        //    oValue = vTemp;
        //}

        public void PROCESS_AGENT_IPU(string sFromPoint, string sEventType, string sCmdType, int iPackID, JObject oJson)
        {
            string sType = "";
            var vTemp = oJson["Type"];
            if (vTemp != null)
                sType = (string)vTemp;
            string sName = "";
            vTemp = oJson["Name"];
            if (vTemp != null)
                sName = (string)vTemp;
            if (sCmdType == "AGENT_IPU_RESTART")
            {
                bool bRestart = false;
                vTemp = oJson["Restart"];
                if (vTemp != null)
                    bRestart = (bool)vTemp;
                OnClientEvent?.Invoke(sFromPoint, "AGENT_IPU_RESTART", sType, sName, bRestart);
            }
            else if (sCmdType == "AGENT_IPU_STOP")
            {
                OnClientEvent?.Invoke(sFromPoint, "AGENT_IPU_STOP", sType, sName);
            }
            else if (sCmdType == "AGENT_SHUTDOWN")
            {
                int iCountDownTime = 0;
                vTemp = oJson["CountDownTime"];
                if (vTemp != null)
                    iCountDownTime = (int)vTemp;
                OnClientEvent?.Invoke(sFromPoint, "AGENT_SHUTDOWN", iCountDownTime);
            }
            else if (sCmdType == "AGENT_IPU_UPDATE")
            {
                string sPath = (string)oJson["Path"];
                OnClientEvent?.Invoke(sFromPoint, "AGENT_IPU_UPDATE", sPath, sType);
            }

        }

        public void PROCESS_AGENT_VER(string sFromPoint, string sEventType, string sCmdType, int iPackID, JObject oJson, CxPack pack)
        {
            int iFileNum = (int)oJson["FileNum"];
            string sRecipeName = (string)oJson["RecipeName"];
            string sRecipePath = Application.StartupPath + "\\IpuRecipe\\" + sRecipeName + "\\";
            if (!System.IO.Directory.Exists(sRecipePath))
                System.IO.Directory.CreateDirectory(sRecipePath);
            byte[] aBuf = pack.PopBuffer();
            CxPack packFile = new CxPack();
            packFile.SetPackBuffer(aBuf);
            for (int i = 0; i < iFileNum; i++)
            {
                string sFile = (string)oJson[i.ToString()];
                string sFile2 = sRecipePath + sFile;
                packFile.PopFile(sFile2);
            }
            packFile.Clear();
        }


        public int SendBuffer(string sPointName, string sCmd, byte[] aBuffer)
        {
            int iResult = 0;
            try
            {
                iResult = _netServer.SendBuffer(sPointName, sCmd, aBuffer);
            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(ex.ToString());
                return iResult;
            }
            return iResult;
        }
        public int SendJson(string sPointName, string sCmd, JObject oJson)
        {
            int iResult = 0;
            try
            {
                string sText = oJson.ToString();
                lock (_objSendLock)
                {
                    iResult = _netServer.SendString(sPointName, sCmd, sText);
                }
            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog(ex.ToString());
                return iResult;
            }
            return iResult;
        }
    }

}
