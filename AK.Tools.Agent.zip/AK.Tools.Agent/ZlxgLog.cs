﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ZlxgLib
{
    public class ZlxgLog
    {
        private string sRootPath = "";
        private string sLogPath = "";
        public string sLogFile = "";
        private int nYear = -1;
        private int nMonth = -1;
        private int nDay = -1;
        private static ZlxgLog mInstance = null;
        private object oEvent = new object();
        public static ZlxgLog Instance
        {
            get
            {
                if (mInstance == null)
                    mInstance = new ZlxgLog();
                return mInstance;
            }
        }

        public ZlxgLog()
        {
            SetPath(Application.StartupPath + "\\log\\");
        }

        public ZlxgLog(string sPath)
        {
            SetPath(sPath);
        }

        ~ZlxgLog()
        {
        }

        //设置日志路径
        public void SetPath(string sPath)
        {
            sRootPath = sPath;
            if (!Directory.Exists(sRootPath))
                sRootPath = Application.StartupPath + "\\log\\";
            if (!sRootPath.EndsWith("\\")) sRootPath += "\\";
            Directory.CreateDirectory(sRootPath);
            nYear = -1;
            nMonth = -1;
            nDay = -1;
        }

        // 写日志
        public void WriteLog(string sLog)
        {
            var task1 = Task.Factory.StartNew(() =>
            {
                try
                {
                    lock (oEvent)
                    {
                        StreamWriter swLog = null;
                        DateTime tNow = DateTime.Now;
                        if (tNow.Year != nYear || tNow.Month != nMonth || tNow.Day != nDay)
                        {
                            sLogPath = sRootPath + tNow.Year.ToString("0000") + "\\" + tNow.Month.ToString("00") + "\\";
                            Directory.CreateDirectory(sLogPath);
                            sLogFile = sLogPath + tNow.ToString("yyyyMMdd") + ".txt";
                            if (!File.Exists(sLogFile))
                            {
                                ZlxgIniFile ini = new ZlxgIniFile();                   //新的一天开始，上一天测的总数清零
                                string sIniFile = AppDomain.CurrentDomain.BaseDirectory + "config\\setup.ini";
                                ini.CreateFile(sIniFile);
                                ini.WriteInt("ZlxgReview", "AllDayTestNum", 0);
                            }
                            nYear = tNow.Year;
                            nMonth = tNow.Month;
                            nDay = tNow.Day;
                        }
                        if (File.Exists(sLogFile))
                            swLog = File.AppendText(sLogFile);
                        else
                            swLog = File.CreateText(sLogFile);
                        swLog.WriteLine("{0}\t{1}", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"), sLog);
                        //swLog.Flush();
                        swLog.Close();
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine($"%%%$$$---WriteLog:{ex.Message}\r\n{ex.StackTrace}");
                }
            });
        }
    }
}
