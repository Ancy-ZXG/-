﻿using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Reflection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Drawing;
using AK.Define;
using ZlxgLib;

namespace AK.Tools
{
    public class ParamHelper
    {
        public static bool SaveToPack(IntPtr pack, ref object obj)
        {
            if (obj == null)
                return false;
            PropertyInfo[] props = obj.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);

            foreach (PropertyInfo item in props)
            {
                string name = item.Name;
                object value = item.GetValue(obj, null);
                Type tp = item.PropertyType;

                //if (!tp.IsValueType)
                //    continue;
                if (tp.Name.StartsWith("Int32[]"))
                {
                    List<int> lsValue = new List<int>();
                    if (value != null)
                    {
                        int[] aValue = (int[])value;
                        for (int i = 0; i < aValue.Length; i++)
                            lsValue.Add(aValue[i]);
                    }
                    ZlxgPack.SetList<int>(pack, name, lsValue);
                }
                else if (tp.Name.StartsWith("Int32"))
                    ZlxgPack.SetInt(pack, name, (int)value);
                else if (tp.Name.StartsWith("Single"))
                    ZlxgPack.SetFloat(pack, name, (float)value);
                else if (tp.Name.StartsWith("Double"))
                    ZlxgPack.SetDouble(pack, name, (double)value);
                else if (tp.Name.StartsWith("Boolean[]"))
                {
                    List<bool> lsValue = new List<bool>();
                    if (value != null)
                    {
                        bool[] aValue = (bool[])value;
                        for (int i = 0; i < aValue.Length; i++)
                            lsValue.Add(aValue[i]);
                    }
                    ZlxgPack.SetList<bool>(pack, name, lsValue);
                }
                else if (tp.Name.StartsWith("Boolean"))
                    ZlxgPack.SetBool(pack, name, (bool)value);
                else if (tp.Name.StartsWith("String[]"))
                {
                    List<string> lsValue = new List<string>();
                    if (value != null)
                    {
                        string[] aValue = (string[])value;
                        for (int i = 0; i < aValue.Length; i++)
                            lsValue.Add(aValue[i]);
                    }
                    ZlxgPack.SetList<string>(pack, name, lsValue);
                }
                else if (tp.Name.StartsWith("String"))
                {
                    if (!string.IsNullOrEmpty((string)value))
                        ZlxgPack.SetString(pack, name, (string)value);
                    else
                        ZlxgPack.SetString(pack, name, "");
                }
                else if (tp.Name.StartsWith("Color[]"))
                {
                    List<int> lsValue = new List<int>();
                    if (value != null)
                    {
                        Color[] aValue = (Color[])value;
                        for (int i = 0; i < aValue.Length; i++)
                        {
                            int iColorValue = aValue[i].ToArgb();
                            lsValue.Add(iColorValue);
                        }
                    }
                    ZlxgPack.SetList<int>(pack, name, lsValue);
                }
                else if (tp.Name.StartsWith("Color"))
                {
                    Color clrColor = (Color)value;
                    ZlxgPack.SetInt(pack, name, clrColor.ToArgb());
                }
                else if (tp.IsEnum)
                {
                    ZlxgPack.SetInt(pack, name, (int)value);
                }
                else if (typeof(IPackSerialize).IsAssignableFrom(tp))
                {
                    IPackSerialize node = (IPackSerialize)value;
                    node.ToPack(pack, name);
                }
                else if (tp.IsArray && typeof(IPackSerialize[]).IsAssignableFrom(tp))
                {
                    if (value != null)
                    {
                        IPackSerialize[] arrNode = (IPackSerialize[])value;
                        IntPtr hNode = ZlxgPack.AddChild(pack, name);
                        ZlxgPack.SetInt(hNode, "ItemNum", arrNode.Length);
                        for (int k = 0; k < arrNode.Length; k++)
                            arrNode[k].ToPack(hNode, $"{k + 1}");
                    }
                }
                else 
                {
                    if (tp.IsArray)
                    {
                        if (value != null)
                        {
                            IPackSerialize[] arrNode = (IPackSerialize[])value;
                            arrNode[0].ToPack(pack, name);
                        }
                    }
                }
            }
            return true;
        }

        public static object LoadFromPack(IntPtr pack, ref object obj) 
        {
            PropertyInfo[] props = obj.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);
            foreach (PropertyInfo item in props)
            {
                string name = item.Name;
                object value = item.GetValue(obj, null);
                Type tp = item.PropertyType;

                object oDefault = GetDefaultValueAttribute(item);
                if (tp.Name.StartsWith("Int32[]"))
                {
                    string sTag = "";
                    List<int> lsValue = ZlxgPack.GetList<int>(pack, name, out sTag);
                    int[] aValue = null;
                    if (lsValue != null)
                    {
                        if (lsValue.Count > 0)
                            aValue = lsValue.ToArray();
                    }
                    item.SetValue(obj, aValue);
                }
                else if(tp.Name.StartsWith("Double[]"))
                {
                    string sTag = "";
                    List<double> lsValue = ZlxgPack.GetList<double>(pack,name,out sTag);
                    double[] aValue = null;
                    if(lsValue != null)
                    {
                        if(lsValue.Count > 0)
                            aValue = lsValue.ToArray();
                    }
                    item.SetValue(obj,aValue);
                }
                else if (tp.Name.StartsWith("Int32"))
                {
                    if (oDefault == null)
                        oDefault = (int)0;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Int32"))
                        oDefault = (int)0;
                    int iValue = ZlxgPack.GetIntDef(pack, name, (int)oDefault);
                    item.SetValue(obj, iValue);
                }
                else if (tp.Name.StartsWith("Single"))
                {
                    if (oDefault == null)
                        oDefault = (float)0;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Single"))
                        oDefault = (float)0;
                    float fValue = ZlxgPack.GetFloatDef(pack, name, (float)oDefault);
                    item.SetValue(obj, fValue);
                }
                else if (tp.Name.StartsWith("Double"))
                {
                    if (oDefault == null)
                        oDefault = (double)0;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Double"))
                        oDefault = (double)0;
                    double fValue = ZlxgPack.GetDoubleDef(pack, name, (double)oDefault);
                    item.SetValue(obj, fValue);
                }
                else if (tp.Name.StartsWith("Boolean[]"))
                {
                    string sTag = "";
                    List<bool> lsValue = ZlxgPack.GetList<bool>(pack, name, out sTag);
                    bool[] aValue = null;
                    if (lsValue != null)
                    {
                        if (lsValue.Count > 0)
                            aValue = lsValue.ToArray();
                    }
                    item.SetValue(obj, aValue);
                }
                else if (tp.Name.StartsWith("Boolean"))
                {
                    if (oDefault == null)
                        oDefault = false;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Boolean"))
                        oDefault = false;
                    bool bValue = ZlxgPack.GetBool(pack, name);
                    item.SetValue(obj, bValue);
                }
                else if (tp.Name.StartsWith("String[]"))
                {
                    string sTag = "";
                    List<string> lsValue = ZlxgPack.GetList<string>(pack, name, out sTag);
                    string[] aValue = null;
                    if (lsValue != null)
                    {
                        if (lsValue.Count > 0)
                        {
                            aValue = new string[lsValue.Count];
                            for (int i = 0; i < lsValue.Count; i++)
                                aValue[i] = lsValue[i];
                        }
                    }
                    item.SetValue(obj, aValue);
                }
                else if (tp.Name.StartsWith("String"))
                {
                    if (oDefault == null)
                        oDefault = "";
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("String"))
                        oDefault = "";
                    string sValue = ZlxgPack.GetStringEx(pack, name);
                    if (sValue == null)
                        sValue = (string)oDefault;
                    item.SetValue(obj, sValue);
                }
                else if (tp.Name.StartsWith("Color[]"))
                {
                    if (oDefault == null)
                        oDefault = Color.White;
                    string sTag = "";
                    List<int> lsValue = ZlxgPack.GetList<int>(pack, name, out sTag);
                    Color[] aValue = null;
                    if (lsValue != null)
                    {
                        if (lsValue.Count > 0)
                        {
                            aValue = new Color[lsValue.Count];
                            for (int i = 0; i < lsValue.Count; i++)
                            {
                                int iValue = lsValue[i];
                                aValue[i] = Color.White;
                                if (iValue == -1)
                                    aValue[i] = (Color)oDefault;
                                else
                                    aValue[i] = Color.FromArgb(iValue);
                            }
                        }
                    }
                    item.SetValue(obj, aValue);
                }
                else if (tp.Name.StartsWith("Color"))
                {
                    if (oDefault == null)
                        oDefault = Color.White;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Color"))
                        oDefault = Color.White;
                    Color clrValue = Color.White;
                    int iValue = ZlxgPack.GetIntDef(pack, name, -1);
                    if (iValue == -1)
                        clrValue = (Color)oDefault;
                    else
                        clrValue = Color.FromArgb(iValue);
                    item.SetValue(obj, clrValue);
                }
                else if (tp.IsEnum)
                {
                    if (oDefault == null)
                        oDefault = (int)0;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Int32") && !tpDef.IsEnum)
                        oDefault = (int)0;
                    int iValue = ZlxgPack.GetIntDef(pack, name, (int)oDefault);
                    item.SetValue(obj, iValue);
                }
                else if (typeof(IPackSerialize).IsAssignableFrom(tp))
                {
                    IPackSerialize node = (IPackSerialize)value;
                    node.FromPack(pack, name);
                }
                else if (tp.IsArray && typeof(IPackSerialize[]).IsAssignableFrom(tp))
                {
                    IntPtr hNode = ZlxgPack.AddChild(pack, name);
                    Type tpItem = tp.GetElementType();
                    int iItemNum = ZlxgPack.GetIntDef(hNode, "ItemNum", 0);
                    var tpItemArray = System.Activator.CreateInstance(tp, iItemNum);
                    IPackSerialize[] arrItem = tpItemArray as IPackSerialize[];
                    for (int k = 0; k < iItemNum; k++)
                    {
                        arrItem[k] = (IPackSerialize)System.Activator.CreateInstance(tpItem);
                        arrItem[k].FromPack(hNode, $"{k + 1}");
                    }
                    item.SetValue(obj, tpItemArray);
                }
            }
            return obj;
        }

        public static bool SaveToPack<T>(T obj, IntPtr pack)
        {
            if (obj == null)
                return false;
            PropertyInfo[] props = obj.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);

            foreach (PropertyInfo item in props)
            {
                string name = item.Name;
                object value = item.GetValue(obj, null);
                Type tp = item.PropertyType;

                //if (!tp.IsValueType)
                //    continue;
                if (tp.Name.StartsWith("Int32[]"))
                {
                    List<int> lsValue = new List<int>();
                    if (value != null)
                    {
                        int[] aValue = (int[])value;
                        for (int i = 0; i < aValue.Length; i++)
                            lsValue.Add(aValue[i]);
                    }
                    ZlxgPack.SetList<int>(pack, name, lsValue);
                }
                else if(tp.Name.StartsWith("Double[]"))
                {
                    List<Double> lsValue = new List<Double>();
                    if(value != null)
                    {
                        Double[] aValue = (Double[])value;
                        for(int i = 0; i < aValue.Length; i++)
                            lsValue.Add(aValue[i]);
                    }
                    ZlxgPack.SetList<Double>(pack,name,lsValue);
                }
                else if (tp.Name.StartsWith("Int32"))
                    ZlxgPack.SetInt(pack, name, (int)value);
                else if (tp.Name.StartsWith("Single"))
                    ZlxgPack.SetFloat(pack, name, (float)value);
                else if (tp.Name.StartsWith("Double"))
                    ZlxgPack.SetDouble(pack, name, (double)value);
                else if (tp.Name.StartsWith("Boolean[]"))
                {
                    List<bool> lsValue = new List<bool>();
                    if (value != null)
                    {
                        bool[] aValue = (bool[])value;
                        for (int i = 0; i < aValue.Length; i++)
                            lsValue.Add(aValue[i]);
                    }
                    ZlxgPack.SetList<bool>(pack, name, lsValue);
                }
                else if (tp.Name.StartsWith("Boolean"))
                    ZlxgPack.SetBool(pack, name, (bool)value);
                else if (tp.Name.StartsWith("String[]"))
                {
                    List<string> lsValue = new List<string>();
                    if (value != null)
                    {
                        string[] aValue = (string[])value;
                        for (int i = 0; i < aValue.Length; i++)
                            lsValue.Add(aValue[i]);
                    }
                    ZlxgPack.SetList<string>(pack, name, lsValue);
                }
                else if (tp.Name.StartsWith("String"))
                {
                    if (!string.IsNullOrEmpty((string)value))
                        ZlxgPack.SetString(pack, name, (string)value);
                    else
                        ZlxgPack.SetString(pack, name, "");
                }
                else if (tp.Name.StartsWith("Color[]"))
                {
                    List<int> lsValue = new List<int>();
                    if (value != null)
                    {
                        Color[] aValue = (Color[])value;
                        for (int i = 0; i < aValue.Length; i++)
                        {
                            int iColorValue = aValue[i].ToArgb();
                            lsValue.Add(iColorValue);
                        }
                    }
                    ZlxgPack.SetList<int>(pack, name, lsValue);
                }
                else if (tp.Name.StartsWith("Color"))
                {
                    Color clrColor = (Color)value;
                    ZlxgPack.SetInt(pack, name, clrColor.ToArgb());
                }
                else if (tp.IsEnum)
                {
                    ZlxgPack.SetInt(pack, name, (int)value);
                }
                else if (typeof(IPackSerialize).IsAssignableFrom(tp))
                {
                    IPackSerialize node = (IPackSerialize)value;
                    node.ToPack(pack, name);
                }
                else if (tp.IsArray && typeof(IPackSerialize[]).IsAssignableFrom(tp))
                {
                    IPackSerialize[] arrNode = (IPackSerialize[])value;
                    IntPtr hNode = ZlxgPack.AddChild(pack, name);
                    ZlxgPack.SetInt(hNode, "ItemNum", arrNode.Length);
                    for (int k = 0;k < arrNode.Length;k++)
                        arrNode[k].ToPack(hNode, $"{k + 1}");
                }
            }
            return true;
        }

        public static T LoadFromPack<T>(IntPtr pack) where T : new()
        {
            T obj = new T();
            PropertyInfo[] props = obj.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);

            foreach (PropertyInfo item in props)
            {
                string name = item.Name;
                object value = item.GetValue(obj, null);
                Type tp = item.PropertyType;

                if (name ==  "mappers")
                {
                    name = "mappers";
                }
                object oDefault = GetDefaultValueAttribute(item);
                if (tp.Name.StartsWith("Int32[]"))
                {
                    string sTag = "";
                    List<int> lsValue = ZlxgPack.GetList<int>(pack, name, out sTag);
                    int[] aValue = null;
                    if (lsValue != null)
                    {
                        if (lsValue.Count > 0)
                            aValue = lsValue.ToArray();
                    }
                    item.SetValue(obj, aValue);
                }
                else if(tp.Name.StartsWith("Double[]"))
                {
                    string sTag = "";
                    List<double> lsValue = ZlxgPack.GetList<double>(pack,name,out sTag);
                    double[] aValue = null;
                    if(lsValue != null)
                    {
                        if(lsValue.Count > 0)
                            aValue = lsValue.ToArray();
                    }
                    item.SetValue(obj,aValue);
                }
                else if (tp.Name.StartsWith("Int32"))
                {
                    if (oDefault == null)
                        oDefault = (int)0;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Int32"))
                        oDefault = (int)0;
                    int iValue = ZlxgPack.GetIntDef(pack, name,(int)oDefault);
                    item.SetValue(obj, iValue);
                }
                else if (tp.Name.StartsWith("Single"))
                {
                    if (oDefault == null)
                        oDefault = (float)0;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Single"))
                        oDefault = (float)0;
                    float fValue = ZlxgPack.GetFloatDef(pack, name,(float)oDefault);
                    item.SetValue(obj, fValue);
                }
                else if (tp.Name.StartsWith("Double"))
                {
                    if (oDefault == null)
                        oDefault = (double)0;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Double"))
                        oDefault = (double)0;
                    double fValue = ZlxgPack.GetDoubleDef(pack, name, (double)oDefault);
                    item.SetValue(obj, fValue);
                }
                else if (tp.Name.StartsWith("Boolean[]"))
                {
                    string sTag = "";
                    List<bool> lsValue = ZlxgPack.GetList<bool>(pack, name, out sTag);
                    bool[] aValue = null;
                    if (lsValue != null)
                    {
                        if (lsValue.Count > 0)
                            aValue = lsValue.ToArray();
                    }
                    item.SetValue(obj, aValue);
                }
                else if (tp.Name.StartsWith("Boolean"))
                {
                    if (oDefault == null)
                        oDefault = false;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Boolean"))
                        oDefault = false;
                    bool bValue = ZlxgPack.GetBool(pack, name);
                    item.SetValue(obj, bValue);
                }
                else if (tp.Name.StartsWith("String[]"))
                {
                    string sTag = "";
                    List<string> lsValue = ZlxgPack.GetList<string>(pack, name, out sTag);
                    string[] aValue = null;
                    if (lsValue != null)
                    {
                        if (lsValue.Count > 0)
                        {
                            aValue = new string[lsValue.Count];
                            for (int i = 0; i < lsValue.Count; i++)
                                aValue[i] = lsValue[i];
                        }
                    }
                    item.SetValue(obj, aValue);
                }
                else if (tp.Name.StartsWith("String"))
                {
                    if (oDefault == null)
                        oDefault = "";
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("String"))
                        oDefault = "";
                    string sValue = ZlxgPack.GetStringEx(pack, name);
                    if (sValue == null)
                        sValue = (string)oDefault;
                    item.SetValue(obj, sValue);
                }
                else if (tp.Name.StartsWith("Color[]"))
                {
                    if (oDefault == null)
                        oDefault = Color.White;
                    string sTag = "";
                    List<int> lsValue = ZlxgPack.GetList<int>(pack, name, out sTag);
                    Color[] aValue = null;
                    if (lsValue != null)
                    {
                        if (lsValue.Count > 0)
                        {
                            aValue = new Color[lsValue.Count];
                            for (int i = 0; i < lsValue.Count; i++)
                            {
                                int iValue = lsValue[i];
                                aValue[i] = Color.White;
                                if (iValue == -1)
                                    aValue[i] = (Color)oDefault;
                                else
                                    aValue[i] = Color.FromArgb(iValue);
                            }
                        }
                    }
                    item.SetValue(obj, aValue);
                }
                else if (tp.Name.StartsWith("Color"))
                {
                    if (oDefault == null)
                        oDefault = Color.White;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Color"))
                        oDefault = Color.White;
                    Color clrValue = Color.White;
                    int iValue = ZlxgPack.GetIntDef(pack, name, -1);
                    if (iValue == -1)
                        clrValue = (Color)oDefault;
                    else
                        clrValue = Color.FromArgb(iValue);
                    item.SetValue(obj, clrValue);
                }
                else if (tp.IsEnum)
                {
                    if (oDefault == null)
                        oDefault = (int)0;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Int32") && !tpDef.IsEnum)
                        oDefault = (int)0;
                    int iValue = ZlxgPack.GetIntDef(pack, name, (int)oDefault);
                    item.SetValue(obj, iValue);
                }
                else if (typeof(IPackSerialize).IsAssignableFrom(tp))
                {
                    IPackSerialize node = (IPackSerialize)value;
                    node.FromPack(pack, name);
                }
                else if (tp.IsArray && typeof(IPackSerialize[]).IsAssignableFrom(tp))
                {
                    IntPtr hNode = ZlxgPack.AddChild(pack, name);
                    Type tpItem = tp.GetElementType();
                    int iItemNum = ZlxgPack.GetIntDef(hNode, "ItemNum", 0);
                    var tpItemArray = System.Activator.CreateInstance(tp, iItemNum);
                    IPackSerialize[] arrItem = tpItemArray as IPackSerialize[];
                    for(int k = 0; k < iItemNum; k++)
                    {
                        arrItem[k] = (IPackSerialize)System.Activator.CreateInstance(tpItem);
                        arrItem[k].FromPack(hNode, $"{k + 1}");
                    }
                    item.SetValue(obj, tpItemArray);
                }
            }
            return obj;
        }

        public static bool SaveToIni<T>(T obj, ZlxgIniFile ini,string section)
        {
            if (obj == null)
                return false;
            PropertyInfo[] props = obj.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);

            foreach (PropertyInfo item in props)
            {
                string name = item.Name;
                object value = item.GetValue(obj, null);
                Type tp = item.PropertyType;

                //if (!tp.IsValueType)
                //    continue;

                if (tp.Name.StartsWith("Int32"))
                    ini.WriteInt(section, name, (int)value);
                else if (tp.Name.StartsWith("Single"))
                    ini.WriteDouble(section, name, (float)value);
                else if(tp.Name.StartsWith("Double[]"))
                {
                    if (value != null)
                    {
                        double[] aValue = (double[])value;
                        if (aValue.Length > 0)
                        {
                            ini.WriteInt(section, $"{name}_Num", aValue.Length);
                            for(int i = 0; i < aValue.Length; i++)
                                ini.WriteDouble(section, $"{name}_Item{i}", aValue[i]);
                        }
                    }
                }
                else if (tp.Name.StartsWith("Double"))
                    ini.WriteDouble(section, name, (double)value);
                else if (tp.Name.StartsWith("Boolean"))
                    ini.WriteBool(section, name, (bool)value);
                else if (tp.Name.StartsWith("String"))
                    ini.WriteString(section, name, (string)value);
                else if (tp.IsEnum)
                    ini.WriteInt(section, name, (int)value);
                else if (typeof(IIniSerialize).IsAssignableFrom(tp))
                {
                    IIniSerialize node = (IIniSerialize)value;
                    node.ToIni(ini, section, name);
                }
                else if(tp.IsArray && typeof(IIniSerialize[]).IsAssignableFrom(tp))
                {
                    IIniSerialize[] arrNode = (IIniSerialize[])value;
                    ini.WriteInt(section, $"{name}_ItemNum", arrNode.Length);
                    for(int k = 0; k < arrNode.Length; k++)
                        arrNode[k].ToIni(ini, section, $"{name}_Item{k + 1}");
                }
            }
            return true;
        }

        public static T LoadFromIni<T>(ZlxgIniFile ini, string section) where T : new()
        {
            T obj = new T();
            PropertyInfo[] props = obj.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);

            foreach (PropertyInfo item in props)
            {
                string name = item.Name;
                object value = item.GetValue(obj, null);
                Type tp = item.PropertyType;

                //if (!tp.IsValueType)
                //    continue;

                object oDefault = GetDefaultValueAttribute(item);
                if (tp.Name.StartsWith("Int32"))
                {
                    if (oDefault == null)
                        oDefault = (int)0;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Int32"))
                        oDefault = (int)0;
                    int iValue = ini.GetInt(section, name, (int)oDefault);
                    item.SetValue(obj, iValue);
                }
                else if (tp.Name.StartsWith("Single"))
                {
                    if (oDefault == null)
                        oDefault = (float)0;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Single"))
                        oDefault = (float)0;
                    float fValue = (float)ini.GetDouble(section, name, (float)oDefault);
                    item.SetValue(obj, fValue);
                }
                else if(tp.Name.StartsWith("Double[]"))
                {
                    int iNum = ini.GetInt(section, $"{name}_Num", 0);
                    if (iNum > 0)
                    {
                        double[] aValue = new double[iNum];
                        for (int i = 0;i < iNum;i++)
                            aValue[i] = ini.GetDouble(section, $"{name}_Item{i}", 0); 
                        item.SetValue(obj, aValue);
                    }
                }
                else if (tp.Name.StartsWith("Double"))
                {
                    if (oDefault == null)
                        oDefault = (double)0;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Double"))
                        oDefault = (double)0;
                    double fValue = ini.GetDouble(section, name, (double)oDefault);
                    item.SetValue(obj, fValue);
                }
                else if (tp.Name.StartsWith("Boolean"))
                {
                    if (oDefault == null)
                        oDefault = false;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Boolean"))
                        oDefault = false;
                    bool bValue = ini.GetBool(section, name, (bool)oDefault);
                    item.SetValue(obj, bValue);
                }
                else if (tp.Name.StartsWith("String"))
                {
                    if (oDefault == null)
                        oDefault = "";
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("String"))
                        oDefault = "";
                    string sValue = ini.GetString(section, name, (string)oDefault);
                    item.SetValue(obj, sValue);
                }
                else if (tp.IsEnum)
                {
                    if (oDefault == null)
                        oDefault = (int)0;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Int32") && !tpDef.IsEnum)
                        oDefault = (int)0;
                    int iValue = ini.GetInt(section, name, (int)oDefault);
                    item.SetValue(obj, iValue);
                }
                else if (typeof(IIniSerialize).IsAssignableFrom(tp))
                {
                    IIniSerialize node = (IIniSerialize)value;
                    node.FromIni(ini, section, name);
                }
                else if(tp.IsArray && typeof(IIniSerialize[]).IsAssignableFrom(tp))
                {
                    Type tpItem = tp.GetElementType();
                    int iItemNum = ini.GetInt(section, $"{name}_ItemNum", 0);
                    var tpItemArray = System.Activator.CreateInstance(tp, iItemNum);
                    IIniSerialize[] arrItem = tpItemArray as IIniSerialize[];
                    for(int k = 0; k < iItemNum; k++)
                    {
                        arrItem[k] = (IIniSerialize)System.Activator.CreateInstance(tpItem);
                        arrItem[k].FromIni(ini, section, $"{name}_Item{k + 1}");
                    }
                    item.SetValue(obj, tpItemArray);
                }
            }
            return obj;
        }

        #region 更新功能

        public static bool UpdateToPack<T>(T obj, IntPtr pack)
        {
            if (obj == null)
                return false;
            PropertyInfo[] props = obj.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);

            foreach (PropertyInfo item in props)
            {
                string name = item.Name;
                if (ZlxgPack.Find(pack, name) == IntPtr.Zero)
                    continue;
                object value = item.GetValue(obj, null);
                Type tp = item.PropertyType;

                //if (!tp.IsValueType)
                //    continue;

                if (tp.Name.StartsWith("Int32"))
                    ZlxgPack.SetInt(pack, name, (int)value);
                else if (tp.Name.StartsWith("Single"))
                    ZlxgPack.SetFloat(pack, name, (float)value);
                else if (tp.Name.StartsWith("Double"))
                    ZlxgPack.SetDouble(pack, name, (double)value);
                else if (tp.Name.StartsWith("Boolean"))
                    ZlxgPack.SetBool(pack, name, (bool)value);
                else if (tp.Name.StartsWith("String"))
                {
                    if (!string.IsNullOrEmpty((string)value))
                        ZlxgPack.SetString(pack, name, (string)value);
                    else
                        ZlxgPack.SetString(pack, name, "");
                }
                else if (tp.Name.StartsWith("Color"))
                {
                    Color clrColor = (Color)value;
                    ZlxgPack.SetInt(pack, name, clrColor.ToArgb());
                }
                else if (tp.IsEnum)
                {
                    ZlxgPack.SetInt(pack, name, (int)value);
                }
                else if (typeof(IPackSerialize).IsAssignableFrom(tp))
                {
                    IPackSerialize node = (IPackSerialize)value;
                    node.ToPack(pack, name);
                }
            }
            return true;
        }

        public static T UpdateFromPack<T>(T oBase, IntPtr pack) where T : new()
        {
            PropertyInfo[] props = oBase.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);
            foreach (PropertyInfo item in props)
            {
                string name = item.Name;
                IntPtr hItem = ZlxgPack.Find(pack, name);
                if (hItem == IntPtr.Zero)
                    continue;
                object vBase = item.GetValue(oBase);
                Type tp = item.PropertyType;
                if (tp.Name.StartsWith("Int32"))
                {
                    int iValue = ZlxgPack.GetIntDef(pack, name, (int)vBase);
                    item.SetValue(oBase, iValue);
                }
                else if (tp.Name.StartsWith("Single"))
                {
                    float fValue = ZlxgPack.GetFloatDef(pack, name, (float)vBase);
                    item.SetValue(oBase, fValue);
                }
                else if (tp.Name.StartsWith("Double"))
                {
                    double fValue = ZlxgPack.GetDoubleDef(pack, name, (double)vBase);
                    item.SetValue(oBase, fValue);
                }
                else if (tp.Name.StartsWith("Boolean"))
                {
                    bool bValue = ZlxgPack.GetBool(pack, name);
                    item.SetValue(oBase, bValue);
                }
                else if (tp.Name.StartsWith("String"))
                {
                    string sValue = ZlxgPack.GetStringEx(pack, name);
                    if (sValue != null)
                        item.SetValue(oBase, sValue);
                }
                else if (tp.Name.StartsWith("Color"))
                {
                    Color clrValue = Color.White;
                    int iValue = ZlxgPack.GetIntDef(pack, name, -1);
                    if (iValue == -1)
                        clrValue = (Color)vBase;
                    else
                        clrValue = Color.FromArgb(iValue);
                    item.SetValue(oBase, clrValue);
                }
                else if (tp.IsEnum)
                {
                    int iValue = ZlxgPack.GetIntDef(pack, name, (int)vBase);
                    item.SetValue(oBase, iValue);
                }
                else if (typeof(IPackSerialize).IsAssignableFrom(tp))
                {
                    IPackSerialize node = (IPackSerialize)vBase;
                    node.FromPack(pack, name);
                }
            }
            return oBase;
        }

        public static bool UpdateToIni<T>(T obj, ZlxgIniFile ini, string section)
        {
            if (obj == null)
                return false;
            PropertyInfo[] props = obj.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);
            foreach (PropertyInfo item in props)
            {
                string name = item.Name;
                Type tp = item.PropertyType;
                object value = item.GetValue(obj, null);
                if (typeof(IIniSerialize).IsAssignableFrom(tp))
                {
                    IIniSerialize node = (IIniSerialize)value;
                    node.ToIni(ini, section, name);
                    continue;
                }
                if (!ini.ExistKey(section, name))
                    continue;
                if (tp.Name.StartsWith("Int32"))
                    ini.WriteInt(section, name, (int)value);
                else if (tp.Name.StartsWith("Single"))
                    ini.WriteDouble(section, name, (float)value);
                else if (tp.Name.StartsWith("Double"))
                    ini.WriteDouble(section, name, (double)value);
                else if (tp.Name.StartsWith("Boolean"))
                    ini.WriteBool(section, name, (bool)value);
                else if (tp.Name.StartsWith("String"))
                    ini.WriteString(section, name, (string)value);
                else if (tp.IsEnum)
                    ini.WriteInt(section, name, (int)value);
            }
            return true;
        }

        public static T UpdateFromIni<T>(T oBase, ZlxgIniFile ini, string section) where T : new()
        {
            PropertyInfo[] props = oBase.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);
            foreach (PropertyInfo item in props)
            {
                string name = item.Name;
                Type tp = item.PropertyType;
                object vBase = item.GetValue(oBase);
                if (typeof(IIniSerialize).IsAssignableFrom(tp))
                {
                    IIniSerialize node = (IIniSerialize)vBase;
                    node.FromIni(ini, section, name);
                    continue;
                }
                if (!ini.ExistKey(section, name))
                    continue;
                if (tp.Name.StartsWith("Int32"))
                {
                    int iValue = ini.GetInt(section, name, (int)vBase);
                    item.SetValue(oBase, iValue);
                }
                else if (tp.Name.StartsWith("Single"))
                {
                    float fValue = (float)ini.GetDouble(section, name, (float)vBase);
                    item.SetValue(oBase, fValue);
                }
                else if (tp.Name.StartsWith("Double"))
                {
                    double fValue = ini.GetDouble(section, name, (double)vBase);
                    item.SetValue(oBase, fValue);
                }
                else if (tp.Name.StartsWith("Boolean"))
                {
                    bool bValue = ini.GetBool(section, name, (bool)vBase);
                    item.SetValue(oBase, bValue);
                }
                else if (tp.Name.StartsWith("String"))
                {
                    string sValue = ini.GetString(section, name, (string)vBase);
                    item.SetValue(oBase, sValue);
                }
                else if (tp.IsEnum)
                {
                    int iValue = ini.GetInt(section, name, (int)vBase);
                    item.SetValue(oBase, iValue);
                }
            }
            return oBase;
        }

        #endregion

        public static JObject SaveToJson<T>(T obj)
        {
            JObject json = new JObject();
            if (obj == null)
                return json;
            PropertyInfo[] props = obj.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);

            foreach (PropertyInfo item in props)
            {
                string name = item.Name;
                object value = item.GetValue(obj, null);
                Type tp = item.PropertyType;

                //if (!tp.IsValueType)
                //    continue;

                if (tp.Name.StartsWith("Int32"))
                    json[name] = (int)value;
                else if (tp.Name.StartsWith("Single"))
                    json[name] = (float)value;
                else if (tp.Name.StartsWith("Double"))
                    json[name] = (double)value;
                else if (tp.Name.StartsWith("Boolean"))
                    json[name] = (bool)value;
                else if (tp.Name.StartsWith("String"))
                    json[name] = (string)value;
                else if (tp.IsEnum)
                    json[name] = (int)value;
            }
            return json;
        }

        public static T LoadFromJson<T>(JObject json) where T : new()
        {
            T obj = new T();
            if (json == null)
                return obj;

            PropertyInfo[] props = obj.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public);
            foreach (PropertyInfo item in props)
            {
                string name = item.Name;
                object value = item.GetValue(obj, null);
                Type tp = item.PropertyType;

                //if (!tp.IsValueType)
                //    continue;

                object oDefault = GetDefaultValueAttribute(item);
                var oToken = json[name];
                if (tp.Name.StartsWith("Int32"))
                {
                    if (oDefault == null)
                        oDefault = (int)0;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Int32"))
                        oDefault = (int)0;
                    if (oToken.Type == JTokenType.Integer)
                        item.SetValue(obj, (int)oToken);
                    else
                        item.SetValue(obj, (int)oDefault);
                }
                else if (tp.Name.StartsWith("Single"))
                {
                    if (oDefault == null)
                        oDefault = (float)0;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Single"))
                        oDefault = (float)0;
                    if (oToken.Type == JTokenType.Float || oToken.Type == JTokenType.Integer)
                        item.SetValue(obj, (float)oToken);
                    else
                        item.SetValue(obj, (float)oDefault);
                }
                else if (tp.Name.StartsWith("Double"))
                {
                    if (oDefault == null)
                        oDefault = (double)0;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Double"))
                        oDefault = (double)0;
                    if (oToken.Type == JTokenType.Float || oToken.Type == JTokenType.Integer)
                        item.SetValue(obj, (double)oToken);
                    else
                        item.SetValue(obj, (double)oDefault);
                }
                else if (tp.Name.StartsWith("Boolean"))
                {
                    if (oDefault == null)
                        oDefault = false;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Boolean"))
                        oDefault = false;
                    if (oToken.Type == JTokenType.Boolean)
                        item.SetValue(obj, (bool)oToken);
                    else
                        item.SetValue(obj, (bool)oDefault);
                }
                else if (tp.Name.StartsWith("String"))
                {
                    if (oDefault == null)
                        oDefault = "";
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("String"))
                        oDefault = "";
                    if (oToken.Type == JTokenType.String)
                        item.SetValue(obj, (string)oToken);
                    else
                        item.SetValue(obj, (string)oDefault);
                }
                else if (tp.IsEnum)
                {
                    if (oDefault == null)
                        oDefault = (int)0;
                    Type tpDef = oDefault.GetType();
                    if (!tpDef.Name.StartsWith("Int32") && !tpDef.IsEnum)
                        oDefault = (int)0;
                    if (oToken.Type == JTokenType.Integer)
                        item.SetValue(obj, (int)oToken);
                    else
                        item.SetValue(obj, (int)oDefault);
                }
            }
            return obj;
        }

        public static string SaveToJsonText<T>(T obj)
        {          
            JObject json = SaveToJson<T>(obj);
            return json.ToString();
        }

        public static T LoadFromJsonText<T>(string sJsonText) where T : new()
        {
            JObject json = null;
            if (!string.IsNullOrEmpty(sJsonText))
                json = (JObject)JsonConvert.DeserializeObject(sJsonText);
            return LoadFromJson<T>(json);
        }

        private static object GetDefaultValueAttribute(PropertyInfo info)
        {
            foreach (Attribute attr in info.GetCustomAttributes(true))
            {
                if (attr is DefaultValueAttribute)
                {
                    DefaultValueAttribute dv = (DefaultValueAttribute)attr;
                    return dv.Value;
                }
            }
            return null;
        }

        public static void SetPropertyVisibility(object obj, string propertyName, bool visible)
        {
            Type type = typeof(BrowsableAttribute);
            PropertyDescriptorCollection props = TypeDescriptor.GetProperties(obj);
            PropertyDescriptor pd = props[propertyName];
            if (pd == null)
                return;
            AttributeCollection attrs = props[propertyName].Attributes;
            FieldInfo fld = type.GetField("browsable", BindingFlags.Instance | BindingFlags.NonPublic);
            fld.SetValue(attrs[type], visible);
        }

        public static void SetPropertyReadOnly(object obj, string propertyName, bool readOnly)
        {
            Type type = typeof(System.ComponentModel.ReadOnlyAttribute);
            PropertyDescriptorCollection props = TypeDescriptor.GetProperties(obj);
            PropertyDescriptor pd = props[propertyName];
            if (pd == null)
                return;
            AttributeCollection attrs = props[propertyName].Attributes;
            FieldInfo fld = type.GetField("isReadOnly", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.CreateInstance);
            fld.SetValue(attrs[type], readOnly);
        }

        public static List<string> LoopProp(object obj, Attribute attr, string value)
        {
            List<string> lsProperty = new List<string>();
            var props = TypeDescriptor.GetProperties(obj, true);
            foreach (PropertyDescriptor prop in props)
            {
                foreach (Attribute a in prop.Attributes)
                {
                    if (a.GetType() == typeof(CategoryAttribute))
                    {
                        lsProperty.Add(prop.Name);
                    }
                    else if (a.GetType() == typeof(DisplayNameAttribute))
                    {
                    }
                    else if (a.GetType() == typeof(DescriptionAttribute))
                    {
                    }
                    else if (a.GetType() == typeof(DefaultValueAttribute))
                    {
                    }
                }
            }
            return lsProperty;
        }
    }

    public class ID_Name_Color
    {
        public int ID;
        public string Name;
        public Color Color;
    }
}
