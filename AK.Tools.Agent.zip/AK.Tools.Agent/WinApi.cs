﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace ZlxgLib
{
    public struct POINT
    {
        public int x;
        public int y;
    }
    public class WinApi
    {
        public const int SW_HIDE = 0x000;
        public const int SW_SHOWNOACTIVATE = 0x004;
        public const int SW_SHOW = 0x005;

        [DllImport("user32.dll")]
        public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll", EntryPoint = "ShowCursor")]
        public static extern bool ShowCursor(bool bShow);

        [DllImport("msvcrt.dll", EntryPoint = "memcpy", CallingConvention = CallingConvention.Cdecl, SetLastError = false)]
        public static extern IntPtr MemCopyArray(byte[] dest, byte[] src, int count);

        [DllImport("msvcrt.dll", EntryPoint = "memcpy", CallingConvention = CallingConvention.Cdecl, SetLastError = false)]
        public static extern IntPtr MemCopyPoint(IntPtr dest, IntPtr src, int count);

        [DllImport("user32.dll")]
        public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint control, Keys vk);

        [DllImport("user32.dll")]
        public static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        //GetPrivateProfileIntA
        //GetPrivateProfileIntW
        //GetPrivateProfileSectionA
        //GetPrivateProfileSectionNamesA
        //GetPrivateProfileSectionNamesW
        //GetPrivateProfileSectionW
        //GetPrivateProfileStringA
        //GetPrivateProfileStringW
        //GetPrivateProfileStructA
        //GetPrivateProfileStructW 

        //int nSize = GetPrivateProfileSectionNames(strBuff, 100, strFilePath);  // nsize 表示读取到所有section中的字符长度
        //wchar_t section[256];
        //memset(section, 0, sizeof(section));
        //int flag = 0;
        //int n = 0;
        //for (int i = 0; i<nSize; i++) {   // 循环将所有的section取出来，每一个section都是以'\0'结束，所以根据‘\0’去截取
        //if (strBuff[i] == '\0') {
        //    StrCpyNW(section, strBuff+ flag, i+1);
        //flag = i + 1;
	       // n++;
	       // if (n > 2){
		      //  m_ComBox_FileName.InsertString(0, section);
		      //  }
        //}			
        //}


        [DllImport("kernel32")]
        public static extern int GetPrivateProfileInt(
           string lpAppName,    // 指向包含 Section 名称的字符串地址
           string lpKeyName,    // 指向包含 Key 名称的字符串地址
           int nDefault,        // 如果 Key 值没有找到，则返回缺省的值是多少
           string lpFileName
           );
        [DllImport("kernel32")]
        public static extern int GetPrivateProfileString(
           string lpAppName,    // 指向包含 Section 名称的字符串地址
           string lpKeyName,    // 指向包含 Key 名称的字符串地址
           string lpDefault,    // 如果 Key 值没有找到，则返回缺省的字符串的地址
           System.Text.StringBuilder lpReturnedString,// 返回字符串的缓冲区地址
           int nSize,           // 缓冲区的长度
           string lpFileName
           );

        [DllImport("kernel32", EntryPoint = "GetPrivateProfileString")]
        public static extern uint GetPrivateProfileStringA(
            string section, 
            string key,
            string def, 
            Byte[] retVal, 
            int size, 
            string filePath
            );
        [DllImport("kernel32")]
        public static extern bool WritePrivateProfileString(
           string lpAppName,    // 指向包含 Section 名称的字符串地址
           string lpKeyName,    // 指向包含 Key 名称的字符串地址
           string lpString,     // 要写的字符串地址
           string lpFileName
           );

        [DllImport("kernel32.dll", EntryPoint = "GetPrivateProfileSectionNames")]
        public static extern uint GetPrivateProfileSectionNames(sbyte[] lpszReturnBuffer, uint nSize, string lpFileName);

        [DllImport("kernel32.dll", EntryPoint = "GetPrivateProfileSection")]
        public static extern uint GetPrivateProfileSection(string lpAppName, sbyte[] lpReturnedString, uint nSize, string lpFileName);

        [DllImport("gdi32.dll")]
        private static extern IntPtr CreatePolygonRgn(ref POINT lpPoint, int nCount, int nPolyFillMode);


        /*
CombineRgn(
  p1: HRGN;     {合成后的区域}
  p2, p3: HRGN; {两个原始区域}
  p4: Integer   {合并选项; 见下表}
): Integer;     {有四种可能的返回值}

//合并选项:
RGN_AND  = 1;
RGN_OR   = 2;
RGN_XOR  = 3;
RGN_DIFF = 4;
RGN_COPY = 5; {复制第一个区域}

//返回值:
ERROR         = 0; {错误}
NULLREGION    = 1; {空区域}
SIMPLEREGION  = 2; {单矩形区域}
COMPLEXREGION = 3; {多矩形区域}
         * */
        [DllImport("gdi32.dll")]
        public static extern int CombineRgn(IntPtr hrgnDest, IntPtr hrgnSrc1, IntPtr hrgnSrc2, int fnCombineMode);
    }
}
