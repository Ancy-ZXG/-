﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;

namespace ZlxgLib
{
    public class ZlxgDebug
    {
        public static string DebugInfo()
        {
            StackTrace st = new StackTrace(true);
            int iLevel = Math.Min(st.FrameCount, 1 + 4);
            string sResult = "";
            for (int i = 1; i < iLevel; i++)
            {
                StackFrame sf = st.GetFrame(i);
                string sMethod = sf.GetMethod().DeclaringType.Name;
                string sFile = sf.GetFileName();
                int iLineNum = sf.GetFileLineNumber();
                sResult += string.Format("在 {0} 位置 {1} 行号 {2}\r\n", sMethod, sFile, iLineNum);
            }
            return sResult;
        }

        public static void ShowStackTraceInfo(string sHead = "", int iFrameCount = 0)
        {
            StackTrace st = new StackTrace(true);
            string sPreBlank = "";
            if (iFrameCount <= 0 || iFrameCount > st.FrameCount)
                iFrameCount = st.FrameCount;
            for (int i = 1; i < iFrameCount; i++)
            {
                System.Reflection.MethodBase mb = st.GetFrame(i).GetMethod();
                System.Diagnostics.Debug.WriteLine(sHead + DateTime.Now.ToString() + sPreBlank + mb.DeclaringType.Name + "  -  " + mb.Name);
                sPreBlank += "   ";
            }
        }


        public static string GetDebugInfo(int iIndex = 1)
        {
            StackTrace st = new StackTrace(true);
            if (iIndex >= st.FrameCount)
                iIndex = st.FrameCount - 1;
            StackFrame sf = st.GetFrame(iIndex);
            MethodBase method = sf.GetMethod();
            string sClass = method.DeclaringType.Name;
            string sMethod = method.Name;
            int iLineNum = sf.GetFileLineNumber();
            return string.Format("{0}->{1}->{2}", sClass, sMethod, iLineNum);
        }

        /// <summary>
        /// 把调试信息输出到文本,时间,类名->方法->行数,其他信息
        /// </summary>
        /// <param name="sFile">文本文件</param>
        /// <param name="sFormat">格式或者直接输出字符串</param>
        /// <param name="aParam">可变参数同string.Format</param>
        public static void PrintDebugString(string sFile, string sFormat, params object[] aParam)
        {
            StreamWriter swLog = null;
            if (File.Exists(sFile))
                swLog = File.AppendText(sFile);
            else
                swLog = File.CreateText(sFile);
            string sLog = string.Format(sFormat, aParam);
            string sDbg = GetDebugInfo(2);
            swLog.WriteLine("{0}\t{1}\t{2}", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"), sDbg, sLog);
            swLog.Close();
        }


        public static void OutputDebugInfo(string sInfo, Exception ex, string sHead = "%%%$$$---")
        {
            string sStackTrace = ex.StackTrace;
            if (string.IsNullOrEmpty(sStackTrace))
                sStackTrace = "";
            Debug.WriteLine($"{sHead}{sInfo}:{ex.Message}\r\n{ex.StackTrace}");
            ZlxgLog.Instance.WriteLog($"{sHead}{sInfo}:{ex.Message}\r\n{ex.StackTrace}");
        }
    }
}
