﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AK.Tools.Agent
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            //限制单例运行
            bool bCanCreateNew = false;
            System.Threading.Mutex mutex = new System.Threading.Mutex(true, "AK.Tools.Agent", out bCanCreateNew);
            if (!bCanCreateNew)
                return;

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmMain());
        }
    }
}
