﻿using System.ComponentModel;
using AK.Define;
using ZlxgLib;

namespace AK.Tools.Agent
{
    [TypeConverter(typeof(PropertySorter))]
    public class NetDiskItem : IIniSerialize
    {
        [DisplayName("Enable")]
        [Description("Enable")]
        [DefaultValue(typeof(bool), "false")]
        public bool Enable { get; set; } = true;

        [DisplayName("IP")]
        [Description("NetDisk IP")]
        [DefaultValue(typeof(string), "192.168.11.11")]
        public string IP { get; set; } = "192.168.11.11";

        [DisplayName("Disk Name")]
        [Description("NetDisk IP")]
        [DefaultValue(typeof(string), "T")]
        public string DiskName { get; set; } = "T";

        public override string ToString()
        {
            return $"({Enable},{IP}:{DiskName})";
        }

        public NetDiskItem() { }

        public void ToIni(object obj, string section, string name)
        {
            ZlxgIniFile ini = obj as ZlxgIniFile;
            ini.WriteBool(section, $"{name}_Enable", Enable);
            ini.WriteString(section, $"{name}_IP", IP);
            ini.WriteString(section, $"{name}_DiskName", DiskName);
        }
        public void FromIni(object obj, string section, string name)
        {
            ZlxgIniFile ini = obj as ZlxgIniFile;
            this.Enable = ini.GetBool(section, $"{name}_Enable", Enable);
            IP = ini.GetString(section, $"{name}_IP", "");
            DiskName = ini.GetString(section, $"{name}_DiskName", DiskName);
        }
    }


    [TypeConverter(typeof(PropertySorter))]
    public class ParamAgent : Param
    {
        #region 系统参数

        [DisplayName("服务端口")]
        [Category("系统参数")]
        [Description("服务端口,默认值:8000")]
        [PropertyOrder(1)]
        [DefaultValue(typeof(int), "8000")]
        public int ServerPort { get; set; } = 8000;

        [DisplayName("自动重启")]
        [Category("系统参数")]
        [Description("自动重启,默认值:false")]
        [PropertyOrder(2)]
        [DefaultValue(typeof(bool), "false")]
        public bool AutoRestart { get; set; } = false;


        [DisplayName("是否自动重启显卡")]
        [Category("系统参数")]
        [Description("是否自动重启显卡,默认值:false")]
        [PropertyOrder(2)]
        [DefaultValue(typeof(bool), "false")]
        public bool AutoRestartGPU { get; set; } = false;


        [DisplayName("连接时连接共享网盘")]
        [Category("系统参数")]
        [Description("连接时连接共享网盘,默认值:true")]
        [PropertyOrder(3)]
        [DefaultValue(typeof(bool), "true")]
        public bool ConnectLinkShareDisk { get; set; } = true;


        [DisplayName("共享网盘地址")]
        [Category("系统参数")]
        [Description("连接时连接共享网盘,默认值:true")]
        [PropertyOrder(3)]
        [DefaultValue(typeof(NetDiskItem[]), null)]
        public NetDiskItem[] NetShareDisk { get; set; } = null;



        [DisplayName("IPU路径")]
        [Category("系统参数")]
        [Description("IPU路径")]
        [PropertyOrder(4)]
        [DefaultValue(typeof(string), "D:\\Work\\BinIPU\\")]
        public string IpuPath { get; set; } = "D:\\Work\\BinIPU\\";

        [DisplayName("HPU路径")]
        [Category("系统参数")]
        [Description("HPU路径")]
        [PropertyOrder(5)]
        [DefaultValue(typeof(string), "D:\\Work\\BinHPU\\")]
        public string HpuPath { get; set; } = "D:\\Work\\BinHPU\\";

        #endregion

        //#region  代理参数
        //[DisplayName("1_启动执行命令")]
        //[Category("代理参数")]
        //[Description("启动执行命令")]
        //[PropertyOrder(1)]
        //[DefaultValue(typeof(string), "")]
        //public string StartupExecute { get; set; } = "";

        //[DisplayName("2_关闭执行命令")]
        //[Category("代理参数")]
        //[Description("关闭执行命令")]
        //[PropertyOrder(2)]
        //[DefaultValue(typeof(string), "")]
        //public string ClosingExecute { get; set; } = "";

        //[DisplayName("3_连接执行命令")]
        //[Category("代理参数")]
        //[Description("连接执行命令")]
        //[PropertyOrder(3)]
        //[DefaultValue(typeof(string), "")]
        //public string ConnectExecute { get; set; } = "";

        //[DisplayName("4_断开执行命令")]
        //[Category("代理参数")]
        //[Description("断开执行命令")]
        //[PropertyOrder(4)]
        //[DefaultValue(typeof(string), "")]
        //public string DisconnectExecute { get; set; } = "";

        //#endregion


    }
}
