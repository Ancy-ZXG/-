﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AK.Tools.Agent
{
    public partial class FrmItem : Form
    {
        public ExeAppItem ExeAppItem { get; set; } = new ExeAppItem();
        public bool EditMode { get; set; } = false;
        public FrmItem()
        {
            InitializeComponent();
        }

        private void FrmItem_Load(object sender, EventArgs e)
        {
            if (EditMode)
            {
                this.Text = "编辑";
                txtType.Text = ExeAppItem.Type;
                txtName.Text = ExeAppItem.Name;
                numDelay.Value = ExeAppItem.Delay;
                txtPath.Text = ExeAppItem.File;
            }
            else
            {
                this.Text = "添加";
            }
        }

        private void btnPath_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "Open Application...";
            dlg.Filter = "Application File (*.exe)|*.exe";
            dlg.InitialDirectory = Application.StartupPath;
            if (dlg.ShowDialog() != DialogResult.OK)
                return;
            txtPath.Text = dlg.FileName;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            if (!EditMode)
            {
                if (FrmMain.ExeAppList.Count(p => p.Name == txtName.Text) >= 1)
                {
                    MessageBox.Show("该名称已经存在!");
                    return;
                }
                if (FrmMain.ExeAppList.Count(p => p.File == txtPath.Text) >= 1)
                {
                    MessageBox.Show("该可执行文件已经存在!");
                    return;
                }
            }
            else
            {
                if (FrmMain.ExeAppList.Count(p => p.Index != ExeAppItem.Index && p.Name == txtName.Text) >= 1)
                {
                    MessageBox.Show("该名称已经存在!");
                    return;
                }
                if (FrmMain.ExeAppList.Count(p => p.Index != ExeAppItem.Index && p.File == txtPath.Text) >= 1)
                {
                    MessageBox.Show("该可执行文件已经存在!");
                    return;
                }
            }
            ExeAppItem.Type = txtType.Text;
            ExeAppItem.Name = txtName.Text;
            ExeAppItem.Delay = (int)numDelay.Value;
            ExeAppItem.File = txtPath.Text;
            DialogResult = DialogResult.OK;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
