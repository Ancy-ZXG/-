﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Threading;
using ZlxgLib;

namespace AK.Tools.Agent
{
    public partial class FrmMain : Form
    {
        private volatile bool _bFromClosing = false;

        public static List<ExeAppItem> ExeAppList = new List<ExeAppItem>();
        private string _sConfigPath = "";
        private ParamAgent _paramAgent = new ParamAgent();
        public FrmMain()
        {
            InitializeComponent();
            _sConfigPath = AppDomain.CurrentDomain.BaseDirectory + "config\\";
            if (!Directory.Exists(_sConfigPath))
                Directory.CreateDirectory(_sConfigPath);
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            //加载参数
            ZlxgIniFile ini = new ZlxgIniFile();
            ini.CreateFile(_sConfigPath + "agent.ini");
            _paramAgent = ParamHelper.LoadFromIni<ParamAgent>(ini, "Setup");
            propAgent.SelectedObject = _paramAgent;
            NetProcess.Instance.ParamAgent = _paramAgent;

            ExeAppList = LoadExeAppList(ini);
            ExeApp2ListView(ExeAppList, listViewApp);

            NetProcess.Instance.OnClientEvent += OnNetEvent;
            NetProcess.Instance.StartServer(_paramAgent.ServerPort);

            if (_paramAgent.ConnectLinkShareDisk)
            {
                if (_paramAgent.NetShareDisk != null)
                {
                    for (int i = 0; i < _paramAgent.NetShareDisk.Length; i++)
                    {
                        System.IO.DriveInfo di = new DriveInfo($"{_paramAgent.NetShareDisk[i].DiskName}:");
                        if (!di.IsReady)
                        {
                            if (_paramAgent.NetShareDisk[i].Enable)
                            {
                                ConnectSharedFolder.RebuildShareNetDisk(Application.StartupPath + $"\\v.bat", _paramAgent.NetShareDisk[i].IP, _paramAgent.NetShareDisk[i].DiskName.ToLower());
                            }
                        }
                    }
                }
            }

            //t = new Thread(ReConnectThread);
            //t.Start(this);

            BackgroundWorker bw = new BackgroundWorker();
            bw.DoWork += Bw_DoWork;
            bw.RunWorkerAsync();



            this.WindowState = FormWindowState.Minimized;
            notifyIcon1.Visible = true;
            this.ShowInTaskbar = false;
        }

        private void Bw_DoWork(object sender, DoWorkEventArgs e)
        {
            while (true)
            {
                try
                {
                    if (this._paramAgent.AutoRestart)
                    {
                        BeginInvoke(new Action(delegate ()
                        {
                            int exenum = listViewApp.Items.Count;
                            for (int i = 0; i < exenum; i++)
                            {
                                string exefile = listViewApp.Items[i].SubItems[4].Text;
                                if (!string.IsNullOrEmpty(exefile))
                                    StartProcess(exefile);
                            }
                        }));
                    }
                    Thread.Sleep(5 * 1000);
                }
                catch
                {  //not important.
                }
            }

        }

        private void StartProcess(string exefile)
        {
            bool bAlreadyExit = false;
            string exefilenamewithoutext = Path.GetFileNameWithoutExtension(exefile);
            Process[] allProgresse = System.Diagnostics.Process.GetProcessesByName(exefilenamewithoutext);
            foreach (Process closeProgress in allProgresse)
            {
                if (closeProgress.ProcessName.Equals(exefilenamewithoutext))
                {
                    // txtMessage.AppendText(DateTime.Now + ":存在" + exefile + "\r\n");
                    bAlreadyExit = true;
                    break;
                }
            }
            if (bAlreadyExit)
                return;
            if (!File.Exists(exefile))
            {
                txtMessage.AppendText(DateTime.Now + ":未找到文件：" + exefile + "\r\n");
                return;
            }

            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = exefile;
            info.Arguments = "";
            info.WindowStyle = ProcessWindowStyle.Normal;
            Process pro = Process.Start(info);
            if (txtMessage.Text.Length >= txtMessage.MaxLength - 1000)
                txtMessage.Clear();
            txtMessage.AppendText(DateTime.Now + ":启动" + exefile + "\r\n");
        }


        //private bool _bBgwRun = true;
        //private BackgroundWorker _bgwRestartCheck = null;

        //public void Init()
        //{
        //    if (_bgwRestartCheck != null)
        //        return;
        //    _bBgwRun = true;
        //    _bgwRestartCheck = new BackgroundWorker();
        //    _bgwRestartCheck.WorkerSupportsCancellation = true;
        //    _bgwRestartCheck.DoWork += BgwDoWork;
        //    _bgwRestartCheck.RunWorkerAsync();
        //}

        //public void Free()
        //{
        //    _bBgwRun = false;
        //    _bgwRestartCheck.CancelAsync();
        //    _bgwRestartCheck = null;
        //}

        //void BgwDoWork(object sender, DoWorkEventArgs e)
        //{
        //    while (_bBgwRun)
        //    {
        //        List<NetSendMsg> lsPackSended = new List<NetSendMsg>();
        //        lock (_dicPackSended)
        //        {
        //            lsPackSended = _dicPackSended.Values.ToList();
        //        }
        //        foreach (NetSendMsg msg in lsPackSended)
        //        {
        //            TimeSpan tm = DateTime.Now - msg.SendTime;
        //            if (tm.Seconds < 100)
        //                continue;
        //            Trace.WriteLine($"CheckPackTimeout Resend:{msg.PackID}");
        //            Remove(msg.PackID);
        //            ICWNetProcess.Instance.PushNetSendMsg(msg);
        //        }
        //        Thread.Sleep(3000);
        //    }
        //}

        #region 编辑条目
        private List<ExeAppItem> LoadExeAppList(ZlxgIniFile ini)
        {
            List<ExeAppItem> lsExeApp = new List<ExeAppItem>();
            int iItemNum = ini.GetInt("ExeApp", "ItemCount", 0);
            int iItemIndex = 0;
            for (int i = 1; i <= iItemNum; i++)
            {
                string sType = ini.GetString("ExeApp", $"Item{i}_Type", "");
                if (string.IsNullOrEmpty(sType))
                    continue;
                string sName = ini.GetString("ExeApp", $"Item{i}_Name", "");
                if (string.IsNullOrEmpty(sName))
                    continue;
                int iDelay = ini.GetInt("ExeApp", $"Item{i}_Delay", -1);
                if (iDelay < 0)
                    continue;
                string sFile = ini.GetString("ExeApp", $"Item{i}_File", "");
                if (string.IsNullOrEmpty(sFile))
                    continue;
                if (lsExeApp.Count(p => p.Name == sName || p.File == sFile) >= 1)
                    continue;
                iItemIndex++;
                lsExeApp.Add(new ExeAppItem() { Index = iItemIndex, Type = sType, Name = sName, Delay = iDelay, File = sFile });
            }
            return lsExeApp;
        }
        private void SaveExeAppList(ZlxgIniFile ini, List<ExeAppItem> lsExeApp)
        {
            ini.WriteInt("ExeApp", "ItemCount", lsExeApp.Count);
            for (int i = 0; i < lsExeApp.Count; i++)
            {
                ExeAppItem item = lsExeApp[i];
                ini.WriteString("ExeApp", $"Item{i + 1}_Type", item.Type);
                ini.WriteString("ExeApp", $"Item{i + 1}_Name", item.Name);
                ini.WriteInt("ExeApp", $"Item{i + 1}_Delay", item.Delay);
                ini.WriteString("ExeApp", $"Item{i + 1}_File", item.File);
            }
        }
        private void ExeApp2ListView(List<ExeAppItem> lsExeApp, ListView lvShow)
        {
            lvShow.Items.Clear();
            lvShow.BeginUpdate();
            for (int i = 0; i < lsExeApp.Count; i++)
            {
                ExeAppItem item = lsExeApp[i];
                ListViewItem lvi = new ListViewItem();
                lvi.Text = item.Index.ToString();
                lvi.SubItems.Add(item.Type);
                lvi.SubItems.Add(item.Name);
                lvi.SubItems.Add(item.Delay.ToString());
                lvi.SubItems.Add(item.File);
                lvShow.Items.Add(lvi);
            }
            lvShow.EndUpdate();
        }
        private void btnAddItem_Click(object sender, EventArgs e)
        {
            FrmItem dlg = new FrmItem();
            dlg.EditMode = false;
            if (dlg.ShowDialog() != DialogResult.OK)
                return;
            dlg.ExeAppItem.Index = ExeAppList.Count + 1;
            ExeAppList.Add(dlg.ExeAppItem);

            ExeApp2ListView(ExeAppList, listViewApp);
            ZlxgIniFile ini = new ZlxgIniFile();
            ini.CreateFile(_sConfigPath + "agent.ini");
            SaveExeAppList(ini, ExeAppList);
        }

        private void btnDelItem_Click(object sender, EventArgs e)
        {
            if (listViewApp.SelectedItems.Count <= 0)
                return;
            ListViewItem lvi = listViewApp.SelectedItems[0];
            ExeAppList.RemoveAt(lvi.Index);

            ExeApp2ListView(ExeAppList, listViewApp);
            ZlxgIniFile ini = new ZlxgIniFile();
            ini.CreateFile(_sConfigPath + "agent.ini");
            SaveExeAppList(ini, ExeAppList);
        }

        private void btnEditItem_Click(object sender, EventArgs e)
        {
            if (listViewApp.SelectedItems.Count <= 0)
                return;
            ListViewItem lvi = listViewApp.SelectedItems[0];
            FrmItem dlg = new FrmItem();
            dlg.EditMode = true;
            dlg.ExeAppItem = ExeAppList[lvi.Index];
            if (dlg.ShowDialog() != DialogResult.OK)
                return;

            ExeApp2ListView(ExeAppList, listViewApp);
            ZlxgIniFile ini = new ZlxgIniFile();
            ini.CreateFile(_sConfigPath + "agent.ini");
            SaveExeAppList(ini, ExeAppList);
        }

        private void listViewApp_DoubleClick(object sender, EventArgs e)
        {
            btnEditItem_Click(sender, e);
        }
        #endregion


        /// <summary>
        /// 复制文件夹及文件
        /// </summary>
        /// <param name="sourceFolder">原文件路径</param>
        /// <param name="destFolder">目标文件路径</param>
        /// <returns></returns>
        public int CopyFolder(string sourceFolder, string destFolder)
        {
            try
            {
                //如果目标路径不存在,则创建目标路径
                if (!System.IO.Directory.Exists(destFolder))
                {
                    System.IO.Directory.CreateDirectory(destFolder);
                }
                //得到原文件根目录下的所有文件
                string[] files = System.IO.Directory.GetFiles(sourceFolder);
                foreach (string file in files)
                {
                    string name = System.IO.Path.GetFileName(file);
                    string dest = System.IO.Path.Combine(destFolder, name);
                    System.IO.File.Copy(file, dest, true);//复制文件
                }
                //得到原文件根目录下的所有文件夹
                string[] folders = System.IO.Directory.GetDirectories(sourceFolder);
                foreach (string folder in folders)
                {
                    string name = System.IO.Path.GetFileName(folder);
                    string dest = System.IO.Path.Combine(destFolder, name);
                    CopyFolder(folder, dest);//构建目标路径,递归复制文件
                }
                return 1;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                return 0;
            }

        }

        public static bool CopyDirectInfo(string sourceDir, string toDir)
        {
            if (!toDir.EndsWith("\\"))
                toDir += "\\";
            if (!Directory.Exists(sourceDir))
                return false;
            if (!Directory.Exists(toDir))
                Directory.CreateDirectory(toDir);
            DirectoryInfo directInfo = new DirectoryInfo(sourceDir);
            //copy files
            FileInfo[] filesInfos = directInfo.GetFiles();
            foreach (FileInfo fi in filesInfos)
            {
                try
                {
                    if (fi.FullName.EndsWith("\\IPU.ini"))
                        continue;
                    File.Copy(fi.FullName, toDir + fi.Name, true);
                }
                catch (Exception) { }
            }
            //copy directory
            foreach (DirectoryInfo di in directInfo.GetDirectories())
            {
                if (di.FullName.EndsWith("\\log"))
                    continue;
                CopyDirectInfo(di.FullName, toDir + di.Name);
            }
            return true;
        }
        public static bool CopyDirectInfo(string sourceDir, string stype ,List<ExeAppItem> exeAppItems)
        {
            List<ExeAppItem> ipuList = exeAppItems.Where(p => p.Type == stype).ToList();
            if (ipuList.Count == 0)
                return false;
            if (!Directory.Exists(sourceDir))
                return false;
            
            DirectoryInfo directInfo = new DirectoryInfo(sourceDir);
            //copy files
            FileInfo[] filesInfos = directInfo.GetFiles();
            foreach(ExeAppItem item in ipuList)
            {
                string dstPath = Path.GetDirectoryName(item.File);
                CopyAll(sourceDir, dstPath);
            }
            
            return true;
        }
        static void CopyAll(string source, string target)
        {
            Directory.CreateDirectory(target);

            foreach (var file in Directory.GetFiles(source))
            {
                string fileName = Path.GetFileName(file);
                string destFile = Path.Combine(target, fileName);
                File.Copy(file, destFile, true);
            }

            foreach (var subDir in Directory.GetDirectories(source))
            {
                string dirName = Path.GetFileName(subDir);
                string destDir = Path.Combine(target, dirName);
                CopyAll(subDir, destDir);
            }
        }

        public bool OnNetEvent(string sFromPoint, string sEventType, params object[] aEventParam)
        {
            if (_bFromClosing)
                return false;
            if (sEventType == "MESSAGE_APPEND")
            {
                MESSAGE_APPEND_INVOKE((string)aEventParam[0]);
            }
            else if (sEventType == "UPDATE_SEND_LOG")
            {
                string sText = (string)aEventParam[0];
                UPDATE_LOG_INVOKE(txtMessage, sText);
            }
            else if (sEventType == "AGENT_IPU_RESTART")
            {
                if (aEventParam.Length != 3)
                    return false;
                string sType = (string)aEventParam[0];
                string sName = (string)aEventParam[1];
                bool bRestart = (bool)aEventParam[2];
                AGENT_IPU_RESTART_INVOKE(sType, sName, bRestart);
            }
            else if (sEventType == "AGENT_IPU_STOP")
            {
                if (aEventParam.Length != 2)
                    return false;
                string sType = (string)aEventParam[0];
                string sName = (string)aEventParam[1];
                AGENT_IPU_STOP_INVOKE(sType, sName);
            }
            else if (sEventType == "AGENT_SHUTDOWN")
            {
                if (aEventParam.Length != 1)
                    return false;
                int iCountDownTime = (int)aEventParam[0];
                Process.Start("C:/windows/system32/shutdown.exe", "-s -t " + iCountDownTime);//单位为：秒
            }
            else if (sEventType == "AGENT_IPU_UPDATE")
            {
                if (aEventParam.Length != 1)
                    return false;
                string sPath = (string)aEventParam[0];
                string sType = (string)aEventParam[1];
                AGENT_IPU_STOP_INVOKE("ALL", "");
                string sIpuPath = _paramAgent.IpuPath;
                if (!sIpuPath.EndsWith("\\"))
                    sIpuPath += "\\";

                //FileDiff.ShotInfo shotInfo1 = new FileDiff.ShotInfo();
                //FileDiff.ToolHelper.GetDirFileList(sPath, sPath, true, ref shotInfo1);
                //FileDiff.ShotInfo shotInfo2 = new FileDiff.ShotInfo();
                //FileDiff.ToolHelper.GetDirFileList(sIpuPath, sIpuPath, true, ref shotInfo2);
                //FileDiff.ShotInfo shotInfoResult = FileDiff.ToolHelper.CompareFileList(shotInfo1, shotInfo2);
                UPDATE_LOG_INVOKE(txtMessage, "开始更新文件...");
                CopyDirectInfo(sPath, sType, ExeAppList /*sIpuPath*/);
                UPDATE_LOG_INVOKE(txtMessage, "文件更新完毕.");

                AGENT_IPU_RESTART_INVOKE("ALL", "", false);
            }
            else
            {
                string sText = (string)aEventParam[0];
                UPDATE_LOG_INVOKE(txtMessage, sText);
            }
            return true;
        }

        public void MESSAGE_APPEND_INVOKE(string sMessage)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new MethodInvoker(() => { MESSAGE_APPEND_INVOKE(sMessage); }));
                return;
            }
            string sText = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + " " + sMessage + "\r\n";
            txtMessage.AppendText(sText);
            Application.DoEvents();
        }

        public void UPDATE_LOG_INVOKE(TextBox txtLog, string sMessage)
        {
            string sText = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + " " + sMessage + "\r\n";
            if (this.InvokeRequired)
            {
                this.Invoke(new MethodInvoker(delegate ()
                {
                    txtLog.AppendText(sText);
                }));
            }
            else
            {
                txtLog.AppendText(sText);
            }
        }

        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!_bTrueClose)
            {
                this.WindowState = FormWindowState.Minimized;
                notifyIcon1.Visible = true;
                this.ShowInTaskbar = false;
                e.Cancel = true;
                return;
            }
            _bFromClosing = true;
            notifyIcon1.Dispose();
        }

        private void AGENT_IPU_RESTART_INVOKE(string sType, string sName, bool bRestrat = true)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new MethodInvoker(() => { AGENT_IPU_RESTART_INVOKE(sType, sName, bRestrat); }));
                return;
            }

            if (this._paramAgent.AutoRestartGPU)
                RestartGPU($"{Application.StartupPath}\\gpu.bat");
            AGENT_IPU_RESTART(sType, sName, bRestrat);
        }

        private void RestartGPU(string sBatFile)
        {

            if (File.Exists(sBatFile))
            {
                Process proc = null;
                try
                {
                    string sBatOutFile = sBatFile;

                    string sFile = Path.GetFileName(sBatOutFile);
                    string sPath = Path.GetDirectoryName(sBatOutFile);//this is where mybatch.bat lies
                    proc = new Process();
                    proc.StartInfo.WorkingDirectory = sPath;
                    proc.StartInfo.FileName = sFile;
                    //proc.StartInfo.Arguments = string.Format("10");//this is argument
                    proc.StartInfo.UseShellExecute = false;
                    //proc.StartInfo.CreateNoWindow = true;
                    proc.Start();
                    proc.WaitForExit(1500);
                }
                catch (Exception ex)
                {
                    ZlxgLog.Instance.WriteLog("gpu重启失败" + ex.ToString());
                    // Console.WriteLine("Exception Occurred :{0},{1}",ex.Message,ex.StackTrace.ToString());
                }
            }
        }


        private void AGENT_IPU_RESTART(string sType, string sName, bool bRestrat = true)
        {
            for (int i = 0; i < listViewApp.Items.Count; i++)
            {
                ListViewItem lvi = listViewApp.Items[i];
                string sItemType = lvi.SubItems[1].Text.Trim();
                string sItemName = lvi.SubItems[2].Text.Trim();
                int iDelayTime = int.Parse(lvi.SubItems[3].Text);
                string sAppFile = lvi.SubItems[4].Text;
                string sProName = Path.GetFileNameWithoutExtension(sAppFile);

                if (sItemType == "HPU")
                {//强制重启HPU

                }
                else
                {
                    if (sType != "ALL")
                    {
                        if (sType != sItemType)
                            continue;
                        if (!string.IsNullOrEmpty(sName))
                            if (sName != sItemName)
                                continue;
                    }
                }
                if (bRestrat)
                    ExeAppTool.CloseProcess(sProName);
                if (!File.Exists(sAppFile))
                {
                    UPDATE_LOG_INVOKE(txtMessage, "程序不存在,无法启动" + sAppFile);
                    continue;
                }
                new Thread(delegate ()
                {
                    Thread.Sleep(iDelayTime);
                    UPDATE_LOG_INVOKE(txtMessage, "启动" + sAppFile);
                    ExeAppTool.StartProcess(sAppFile);
                }).Start();
            }
        }


        private void AGENT_IPU_STOP_INVOKE(string sType, string sName)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new MethodInvoker(() => { AGENT_IPU_STOP_INVOKE(sType, sName); }));
                return;
            }
            AGENT_IPU_STOP(sType, sName);
        }
        private void AGENT_IPU_STOP(string sType, string sName)
        {
            for (int i = 0; i < listViewApp.Items.Count; i++)
            {
                ListViewItem lvi = listViewApp.Items[i];
                string sItemType = lvi.SubItems[1].Text.Trim();
                string sItemName = lvi.SubItems[2].Text.Trim();
                int iDelayTime = int.Parse(lvi.SubItems[3].Text);
                string sAppFile = lvi.SubItems[4].Text;
                string sProName = Path.GetFileNameWithoutExtension(sAppFile);
                if (sType != "ALL")
                {
                    if (sType != sItemType)
                        continue;
                    if (!string.IsNullOrEmpty(sName))
                        if (sName != sItemName)
                            continue;
                }
                ExeAppTool.CloseProcess(sProName);
                UPDATE_LOG_INVOKE(txtMessage, "停止" + sAppFile);
            }
        }


        private void btnStartAll_Click(object sender, EventArgs e)
        {
            AGENT_IPU_RESTART("ALL", "", true);
        }

        private void btnCloseAll_Click(object sender, EventArgs e)
        {
            AGENT_IPU_STOP("ALL", "");
        }

        private void 显示ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.Show();
                this.WindowState = FormWindowState.Normal;
                notifyIcon1.Visible = false;
                this.ShowInTaskbar = true;
            }
        }

        private bool _bTrueClose = false;
        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("确认是否退出!", "提示", MessageBoxButtons.YesNo) == DialogResult.No)
                return;
            _bTrueClose = true;
            Close();
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            显示ToolStripMenuItem_Click(sender, e);
        }

        private void btnRestartSelected_Click(object sender, EventArgs e)
        {
            //System.IO.DriveInfo di = new DriveInfo("v:");
            //if (!di.IsReady)
            //{
            //    ConnectSharedFolder.ExecBatCommand(p =>
            //    {
            //        p(@"if not exist v:\ net use v: \\192.168.254.10\v  /persistent:yes");
            //        p("exit 0");
            //    });
            //}
            //return;

            if (listViewApp.SelectedItems.Count <= 0)
                return;
            ListViewItem lvi = listViewApp.SelectedItems[0];
            string sItemType = lvi.SubItems[1].Text.Trim();
            string sItemName = lvi.SubItems[2].Text.Trim();
            AGENT_IPU_RESTART(sItemType, sItemName, true);
        }

        private void btnStopSelected_Click(object sender, EventArgs e)
        {
            if (listViewApp.SelectedItems.Count <= 0)
                return;
            ListViewItem lvi = listViewApp.SelectedItems[0];
            string sItemType = lvi.SubItems[1].Text.Trim();
            string sItemName = lvi.SubItems[2].Text.Trim();
            AGENT_IPU_STOP(sItemType, sItemName);
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            if (!File.Exists(Application.StartupPath + "\\v.bat"))
            {
                MessageBox.Show("未发现v.bat文件，请检查Agent是否环境正常");
                return;
            }

            //  ConnectSharedFolder.RebuildShareNetDisk(Application.StartupPath + "\\v.bat", this._paramAgent.NetShareDisk);
            if (_paramAgent.NetShareDisk != null)
            {
                //ConnectSharedFolder.DeleteAllDisk();
                for (int i = 0; i < _paramAgent.NetShareDisk.Length; i++)
                {
                    System.IO.DriveInfo di = new DriveInfo($"{_paramAgent.NetShareDisk[i].DiskName}:");
                    if (!di.IsReady)
                    {
                        if (_paramAgent.NetShareDisk[i].Enable)
                        {
                            ConnectSharedFolder.RebuildShareNetDisk(Application.StartupPath + $"\\v.bat", _paramAgent.NetShareDisk[i].IP, _paramAgent.NetShareDisk[i].DiskName.ToLower());
                        }
                    }
                }
            }


            //System.IO.DriveInfo di = new DriveInfo("v:");
            //if (!di.IsReady)
            //{
            //    ConnectSharedFolder.ExecBatFile(Application.StartupPath + "\\v.bat");
            //}
        }


        private void timerCheckApp_Tick(object sender, EventArgs e)
        {

        }

        private void propAgent_PropertyValueChanged(object s, PropertyValueChangedEventArgs e)
        {
            _paramAgent = (ParamAgent)propAgent.SelectedObject;
            ZlxgIniFile ini = new ZlxgIniFile();
            ini.CreateFile(Application.StartupPath + "\\config\\agent.ini");
            ParamHelper.SaveToIni<ParamAgent>(_paramAgent, ini, "Setup");

            NetProcess.Instance.ParamAgent = _paramAgent;
        }

        private void btnDeleteAllDisk_Click(object sender, EventArgs e)
        {
            ConnectSharedFolder.DeleteAllDisk();
        }

        private void btnLockGPU_Click(object sender, EventArgs e)
        {
            RestartGPU($"{Application.StartupPath}\\gpu.bat");
        }
    }

    public class ExeAppItem
    {
        public int Index { get; set; } = -1;
        public string Type { get; set; } = "";
        public string Name { get; set; } = "";
        public int Delay { get; set; } = 0;
        public string File { get; set; } = "";

    }
}
