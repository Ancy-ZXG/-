﻿using System.Runtime.InteropServices;
using System;
using System.IO;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ZlxgLib;

namespace AK.Tools.Agent
{
    public class ConnectSharedFolder
    {
        public struct NETRESOURCE
        {
            public int dwScope;
            public int dwType;
            public int dwDisplayType;
            public int dwUsage;
            public string lpLocalName;
            public string lpRemoteName;
            public string lpComment;
            public string lpProvider;
        }

        [DllImport("mpr.dll", CharSet = CharSet.Ansi, EntryPoint = "WNetAddConnection2A", ExactSpelling = true, SetLastError = true)]
        public static extern int WNetAddConnection2(ref NETRESOURCE lpNetResource, [MarshalAs(UnmanagedType.VBByRefStr)] ref string lpPassword, [MarshalAs(UnmanagedType.VBByRefStr)] ref string lpUserName, int dwFlags);

        [DllImport("mpr.dll", CharSet = CharSet.Ansi, EntryPoint = "WNetCancelConnection2A", ExactSpelling = true, SetLastError = true)]
        public static extern int WNetCancelConnection2([MarshalAs(UnmanagedType.VBByRefStr)] ref string lpName, int dwFlags, int fForce);

        public static bool BeginConnect(string localDrive, string sharePath, string userName, string UserPassword)
        {
            NETRESOURCE nETRESOURCE = default(NETRESOURCE);
            nETRESOURCE.dwScope = 2;
            nETRESOURCE.dwType = 1;
            nETRESOURCE.dwDisplayType = 3;
            nETRESOURCE.dwUsage = 1;
            nETRESOURCE.lpLocalName = localDrive;
            nETRESOURCE.lpRemoteName = sharePath;
            int num = WNetAddConnection2(ref nETRESOURCE, ref UserPassword, ref userName, 1);
            return num == 0;
        }

        public static bool EndConnect(string localDrive)
        {
            int num = WNetCancelConnection2(ref localDrive, 1, 0);
            return num == 0;
        }


        /// <summary>
        /// 打开控制台执行拼接完成的批处理命令字符串
        /// </summary>
        /// <param name="inputAction">需要执行的命令委托方法：每次调用 <paramref name="inputAction"/> 中的参数都会执行一次</param>
        public static void ExecBatCommand(Action<Action<string>> inputAction)
        {
            Process pro = null;
            StreamWriter sIn = null;
            StreamReader sOut = null;
            try
            {
                pro = new Process();
                pro.StartInfo.FileName = "cmd.exe";
                pro.StartInfo.UseShellExecute = false;
                pro.StartInfo.CreateNoWindow = true;
                pro.StartInfo.RedirectStandardInput = true;
                pro.StartInfo.RedirectStandardOutput = true;
                pro.StartInfo.RedirectStandardError = true;

                pro.OutputDataReceived += (sender, e) => Console.WriteLine(e.Data);
                pro.ErrorDataReceived += (sender, e) => Console.WriteLine(e.Data);

                pro.Start();
                sIn = pro.StandardInput;
                sIn.AutoFlush = true;

                pro.BeginOutputReadLine();
                inputAction(value => sIn.WriteLine(value));

                pro.WaitForExit();
            }
            finally
            {
                if (pro != null && !pro.HasExited)
                    pro.Kill();

                if (sIn != null)
                    sIn.Close();
                if (sOut != null)
                    sOut.Close();
                if (pro != null)
                    pro.Close();
            }
        }

        public static void ExecBatFile(string sBatFile)
        {
            Process proc = null;
            try
            {
                string sFile = Path.GetFileName(sBatFile);
                string sPath = Path.GetDirectoryName(sBatFile);//this is where mybatch.bat lies
                proc = new Process();
                proc.StartInfo.WorkingDirectory = sPath;
                proc.StartInfo.FileName = sFile;
                //proc.StartInfo.Arguments = string.Format("10");//this is argument
                //proc.StartInfo.UseShellExecute = false;
                //proc.StartInfo.CreateNoWindow = true;
                proc.Start();
                proc.WaitForExit(1500);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Occurred :{0},{1}", ex.Message, ex.StackTrace.ToString());
            }
        }


        public static void RebuildShareNetDisk(string sBatFile, string shareIP, string diskName)
        {
            Process proc = null;
            try
            {
                if (!File.Exists(sBatFile))
                {
                    System.Windows.Forms.MessageBox.Show("未检查到文件存在，请检查代理环境。\r\n" + sBatFile);
                    return;
                }
                string sBatOutFile = sBatFile;
                try
                {
                    StreamReader sr = new StreamReader(sBatFile);
                    string content = sr.ReadToEnd();
                    Regex reg = new Regex(@"v: \\\\\d+\.\d+\.\d+\.\d+\\v");
                    string modified = reg.Replace(content, $"{diskName}: \\\\{shareIP}\\{diskName}");

                    Regex reg2 = new Regex(@"v:\\");
                    modified = reg2.Replace(modified, $"{diskName}:\\");

                    sr.Close();

                    sBatOutFile = Application.StartupPath + $"\\{diskName}.bat";
                    File.WriteAllText(sBatOutFile, modified);
                }
                catch (System.Exception ex)
                {
                    ZlxgLog.Instance.WriteLog(ex.ToString());
                }

                string sFile = Path.GetFileName(sBatOutFile);
                string sPath = Path.GetDirectoryName(sBatOutFile);//this is where mybatch.bat lies
                proc = new Process();
                proc.StartInfo.WorkingDirectory = sPath;
                proc.StartInfo.FileName = sFile;
                //proc.StartInfo.Arguments = string.Format("10");//this is argument
                //proc.StartInfo.UseShellExecute = false;
                //proc.StartInfo.CreateNoWindow = true;
                proc.Start();
                proc.WaitForExit(1500);
            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog("重建共享盘盘失败。" + ex.ToString());
                // Console.WriteLine("Exception Occurred :{0},{1}",ex.Message,ex.StackTrace.ToString());
            }
        }

        public static void DeleteAllDisk()
        {
            Process proc = null;
            try
            {
                string sBatFile = $"{Application.StartupPath.TrimEnd('\\')}\\delete.bat";
                if (!File.Exists(sBatFile))
                {
                    System.Windows.Forms.MessageBox.Show("未检查到文件存在，请检查代理环境。\r\n" + sBatFile);
                    return;
                }
                string sFile = Path.GetFileName(sBatFile);
                string sPath = Path.GetDirectoryName(sBatFile);//this is where mybatch.bat lies
                proc = new Process();
                proc.StartInfo.WorkingDirectory = sPath;
                proc.StartInfo.FileName = sFile;
                //proc.StartInfo.Arguments = string.Format("10");//this is argument
                //proc.StartInfo.UseShellExecute = false;
                //proc.StartInfo.CreateNoWindow = true;
                proc.Start();
                proc.WaitForExit(1500);
            }
            catch (Exception ex)
            {
                ZlxgLog.Instance.WriteLog("删除共享盘盘失败。" + ex.ToString());
                // Console.WriteLine("Exception Occurred :{0},{1}",ex.Message,ex.StackTrace.ToString());
            }

        }

    }
}
