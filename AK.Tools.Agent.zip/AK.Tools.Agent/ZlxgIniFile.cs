﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace ZlxgLib
{
    // 操作INI文件类
    // 作者：陈新
    public class ZlxgIniFile
    {
        private string fileName;

        /// <summary>
        /// 载入INI文件
        /// </summary>
        /// <param name="filename">ini文件名</param>
        public void CreateFile(string filename)
        {
            fileName = filename;
        }

        /// <summary>
        /// 获得INI文件的某一键的字符串
        /// </summary>
        /// <param name="section">INI文件的章节</param>
        /// <param name="key">INI文件的键名</param>
        /// <param name="def">该键名无值时的默认值</param>
        /// <returns>字符串</returns>
        public string GetString(string section, string key, string def)
        {
            System.Text.StringBuilder temp = new System.Text.StringBuilder(1024);
            WinApi.GetPrivateProfileString(section, key, def, temp, 1024, fileName);
            return temp.ToString();
        }

        public List<string> ReadSections()
        {
            List<string> result = new List<string>();
            Byte[] buf = new Byte[65536];
            uint len = WinApi.GetPrivateProfileStringA(null, null, null, buf, buf.Length, fileName);
            int j = 0;
            for (int i = 0; i < len; i++)
            {
                if (buf[i] == 0)
                {
                    result.Add(Encoding.Default.GetString(buf, j, i - j));
                    j = i + 1;
                }
            }
            return result;
        }

        public List<string> ReadKeys(string section)
        {
            List<string> result = new List<string>();
            Byte[] buf = new Byte[65536];
            uint len = WinApi.GetPrivateProfileStringA(section, null, null, buf, buf.Length, fileName);
            int j = 0;
            for (int i = 0; i < len; i++)
            {
                if (buf[i] == 0)
                {
                    result.Add(Encoding.Default.GetString(buf, j, i - j));
                    j = i + 1;
                }
            }
            return result;
        }

        public bool ExistSection(string section)
        {
            Byte[] buf = new Byte[256];
            uint len = WinApi.GetPrivateProfileStringA(section, null, null, buf, buf.Length, fileName);
            return len > 0;
        }

        public bool ExistKey(string section,string key)
        {
            Byte[] buf = new Byte[256];
            uint len = WinApi.GetPrivateProfileStringA(section, key, null, buf, buf.Length, fileName);
            return len > 0;
        }

        /// <summary>
        /// 获得INI文件的某一键的数值
        /// </summary>
        /// <param name="section">INI文件的章节</param>
        /// <param name="key">INI文件的键名</param>
        /// <param name="def">该键名无值时的默认值</param>
        /// <returns>整型</returns>
        public int GetInt(string section, string key, int def)
        {
            return WinApi.GetPrivateProfileInt(section, key, def, fileName);
        }

        /// <summary>
        /// 获得INI文件的某一键的浮点数
        /// </summary>
        /// <param name="section">INI文件的章节</param>
        /// <param name="key">INI文件的键名</param>
        /// <param name="def">该键名无值时的默认值</param>
        /// <returns>双精度浮点数</returns>
        public double GetDouble(string section, string key, double def)
        {
            System.Text.StringBuilder temp = new System.Text.StringBuilder(1024);
            WinApi.GetPrivateProfileString(section, key, def.ToString(), temp, 1024, fileName);
            double fRet = def;
            try{
                fRet = Convert.ToDouble(temp.ToString());
            }
            catch{
                fRet = def;
            }
            return fRet;
        }

        /// <summary>
        /// 获得INI文件的某一键的布尔值
        /// </summary>
        /// <param name="section">INI文件的章节</param>
        /// <param name="key">INI文件的键名</param>
        /// <param name="def">该键名无值时的默认值</param>
        /// <returns>布尔值</returns>
        public bool GetBool(string section, string key, bool def)
        {
            System.Text.StringBuilder temp = new System.Text.StringBuilder(1024);
            WinApi.GetPrivateProfileString(section, key, def ? "TRUE" : "FALSE", temp, 1024, fileName);
            return (temp.ToString().ToUpper() == "TRUE");
        }

        /// <summary>
        /// 设置INI文件的某一键的字符串
        /// </summary>
        /// <param name="section">INI文件的章节</param>
        /// <param name="key">INI文件的键名</param>
        /// <param name="strVal">INI文件的键值</param>
        public void WriteString(string section, string key, string strVal)
        {
            WinApi.WritePrivateProfileString(section, key, strVal, fileName);
        }

        /// <summary>
        /// 设置INI文件的某一键的数值
        /// </summary>
        /// <param name="section">INI文件的章节</param>
        /// <param name="key">INI文件的键名</param>
        /// <param name="iVal">INI文件的键值</param>
        public void WriteInt(string section, string key, int iVal)
        {
            WinApi.WritePrivateProfileString(section, key, iVal.ToString(), fileName);
        }

        /// <summary>
        /// 设置INI文件的某一键的浮点数
        /// </summary>
        /// <param name="section">INI文件的章节</param>
        /// <param name="key">INI文件的键名</param>
        /// <param name="fVal">该键名无值时的默认值</param>
        public void WriteDouble(string section, string key, double fVal)
        {
            WinApi.WritePrivateProfileString(section, key, fVal.ToString(), fileName);
        }

        /// <summary>
        /// 设置INI文件的某一键的布尔值
        /// </summary>
        /// <param name="section">INI文件的章节</param>
        /// <param name="key">INI文件的键名</param>
        /// <param name="bVal">INI文件的键值</param>
        public void WriteBool(string section, string key, bool bVal)
        {
            WinApi.WritePrivateProfileString(section, key, bVal ? "TRUE" : "FALSE", fileName);
        }

        /// <summary>
        /// 删除某一个键
        /// </summary>
        /// <param name="section">INI文件的章节</param>
        /// <param name="key">INI文件的键名</param>
        public void DelKey(string section, string key)
        {
            WinApi.WritePrivateProfileString(section, key, null, fileName);
        }

        /// <summary>
        /// 删除某一个章节
        /// </summary>
        /// <param name="section">INI文件的章节</param>
        public void DelSection(string section)
        {
            WinApi.WritePrivateProfileString(section, null, null, fileName);
        }        
    }
}
