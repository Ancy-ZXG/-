﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace AK.Tools
{
    public enum ZLXG_PACK_DATA_TYPE
    {
        DP_BYTE = 0,        // 字节
        DP_WORD,            // 字
        DP_DWORD,           // 双字
        DP_INT,             // 整形
        DP_FLOAT,           // 单精度浮点
        DP_DOUBLE,          // 双精度浮点
        DP_INT64,           // 四字整数
        DP_LONGDOUBLE,      // 长浮点(10字节)
        DP_STRING,          // 字符串
        DP_TEXT,            // 长文本字符串
        DP_BINARY,          // 二进制
        DP_IMAGE,           // 图像
        DP_POINT            // 指针
    };


    [StructLayout(LayoutKind.Sequential)]
    public struct CDataItem
    {
        [MarshalAs(UnmanagedType.I4)]
        public int m_dpType;       // 数据类型
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 260)]
        public char[] m_sName;          // 名称
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 260)]
        public char[] m_sDesc;         // 说明
        [MarshalAs(UnmanagedType.SysUInt)]
        public IntPtr m_pData;         // 数据
        [MarshalAs(UnmanagedType.I8)]
        public Int64 m_iSize;          // 数据长度
        [MarshalAs(UnmanagedType.SysUInt)]
        public IntPtr m_pCustom;       // 自定义数据
        [MarshalAs(UnmanagedType.I8)]
        public Int64 m_iCustomSize;    // 自定义数据长度
    };

    [StructLayout(LayoutKind.Sequential)]
    public struct CImageDataHeader
    {
        public int m_iWidth;
        public int m_iHeight;
        public int m_iBit;
        public int m_itType;
    }

    public class ZlxgPack
    {
        [DllImport("msvcrt.dll", EntryPoint = "memcpy", CallingConvention = CallingConvention.Cdecl, SetLastError = false)]
        public static extern IntPtr MemCopyArray(byte[] dest, byte[] src, int count);

        [DllImport("msvcrt.dll", EntryPoint = "memcpy", CallingConvention = CallingConvention.Cdecl, SetLastError = false)]
        public static extern IntPtr MemCopyPoint(IntPtr dest, IntPtr src, int count);


        public static object[] GetCDataItem(IntPtr hNode, IntPtr hItem)
        {
            if (hNode == IntPtr.Zero || hItem == IntPtr.Zero)
                return null;

            CDataItem item = (CDataItem)Marshal.PtrToStructure(IntPtr.Add(hItem, 8), typeof(CDataItem));
            object[] objs = new object[5];

            IntPtr hName = Marshal.UnsafeAddrOfPinnedArrayElement(item.m_sName, 0);
            string sName = Marshal.PtrToStringUni(hName);  //PtrToStringAuto

            IntPtr hDesc = Marshal.UnsafeAddrOfPinnedArrayElement(item.m_sDesc, 0);
            string sDesc = Marshal.PtrToStringUni(hDesc);  //PtrToStringAuto

            IntPtr pData = item.m_pData;
            int iSize = (int)item.m_iSize;
            ZLXG_PACK_DATA_TYPE enumType = (ZLXG_PACK_DATA_TYPE)item.m_dpType;

            objs[0] = sName;
            objs[1] = enumType;
            objs[2] = 0;
            objs[3] = 0;
            objs[4] = sDesc;

            unsafe
            {
                switch (enumType)
                {
                    case ZLXG_PACK_DATA_TYPE.DP_BYTE:            // 字节 
                        objs[2] = *((byte*)pData);
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_WORD:            // 字    
                        objs[2] = *((UInt16*)pData);
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_DWORD:            // 双字   
                        objs[2] = *((UInt32*)pData);
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_INT:            // 整形    
                        objs[2] = *((Int32*)pData);
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_FLOAT:          // 单精度浮点
                        objs[2] = *((float*)pData);
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_DOUBLE:          // 双精度浮点
                        objs[2] = *((double*)pData);
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_INT64:          // 四字整数
                        objs[2] = *((Int64*)pData);
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_STRING:          // 字符串
                        objs[2] = Marshal.PtrToStringAnsi(pData); 
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_TEXT:           // 长文本字符串
                        objs[2] = Marshal.PtrToStringAnsi(pData);
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_BINARY:          // 二进制
                        objs[2] = pData;
                        objs[3] = iSize;
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_IMAGE:          // 图像
                        objs[2] = GetImageEx(hNode, sName);
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_POINT:          // 指针
                        objs[2] = GetPoint(hNode, sName);
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_LONGDOUBLE:     // 长浮点(10字节)
                        objs[2] = (decimal)0;  //GetLongDouble(hNode, sName);
                        break;
                    default:
                        objs[2] = (int)0;
                        break;
                }
            }
            return objs;
        }

        [DllImport("ZlxgPack.dll", EntryPoint = "ExpFind")]
        public static extern IntPtr Find(IntPtr a_hHnd, string a_sName);
        /// <summary>
        /// 指定节点下查找指定名字的属性
        /// </summary>
        /// <param name="a_hHnd">节点句柄</param>
        /// <param name="a_sName">属性名称</param>
        /// <returns>返回object[5],0:名称,1:类型,2:数据,3:附加,4:说明</returns>
        public static object[] FindEx(IntPtr a_hHnd, string a_sName)
        {
            IntPtr hItem = Find(a_hHnd, a_sName);
            object[] objs = GetCDataItem(a_hHnd, hItem);
            return objs;
        }

        [DllImport("ZlxgPack.dll", EntryPoint = "ExpBegin")]
        public static extern IntPtr Begin(IntPtr a_hHnd);
        /// <summary>
        /// 开始遍历指定节点下的属性
        /// </summary>
        /// <param name="a_hHnd">节点句柄</param>
        /// <returns>返回object[5],0:名称,1:类型,2:数据,3:附加,4:说明</returns>
        public static object[] BeginEx(IntPtr a_hHnd)
        {
            IntPtr hItem = Begin(a_hHnd);
            object[] objs = GetCDataItem(a_hHnd, hItem);
            return objs;
        }

        [DllImport("ZlxgPack.dll", EntryPoint = "ExpNext")]
        public static extern IntPtr Next(IntPtr a_hHnd);
        /// <summary>
        /// 继续遍历指定节点下的属性,直到返回值为null
        /// </summary>
        /// <param name="a_hHnd">节点句柄</param>
        /// <returns>返回object[5],0:名称,1:类型,2:数据,3:附加,4:说明</returns>
        public static object[] NextEx(IntPtr a_hHnd)
        {
            IntPtr hItem = Next(a_hHnd);
            object[] objs = GetCDataItem(a_hHnd, hItem);
            return objs;
        }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpCreateZlxgPack")]
        public static extern IntPtr CreateZlxgPack(string lpName);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpDestroyZlxgPack")]
        public static extern void DestroyZlxgPack(IntPtr a_hHnd);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpLock")]
        public static extern void Lock(IntPtr a_hHnd);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpUnlock")]
        public static extern void Unlock(IntPtr a_hHnd);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpSetByte")]
        public static extern bool SetByte(IntPtr a_hHnd,string a_sName,byte value);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpSetWord")]
        public static extern bool SetWord(IntPtr a_hHnd,string a_sName,UInt16 value);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpSetDword")]
        public static extern bool SetDword(IntPtr a_hHnd,string a_sName,UInt32 value);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpSetInt")]
        public static extern bool SetInt(IntPtr a_hHnd,string a_sName,int value);


        public static bool SetBool(IntPtr a_hHnd, string a_sName, bool value) { return SetInt(a_hHnd, a_sName, value ? 1 : 0); }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpSetFloat")]
        public static extern bool SetFloat(IntPtr a_hHnd,string a_sName,float value);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpSetDouble")]
        public static extern bool SetDouble(IntPtr a_hHnd,string a_sName,double value);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpSetInt64")]
        public static extern bool SetInt64(IntPtr a_hHnd,string a_sName,Int64 value);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpSetString")]
        public static extern bool SetString(IntPtr a_hHnd,string a_sName,string value);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpSetText")]
        public static extern bool SetText(IntPtr a_hHnd,string a_sName,string value);


        [DllImport("ZlxgPack.dll", EntryPoint = "SetBinary")]
        public static extern bool SetBinary(IntPtr a_hHnd,string a_sName,byte[] value,int a_iSize,byte [] custom,int a_iCustomSize);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpSetImage")]
        public static extern bool SetImage(IntPtr a_hHnd, string a_sName, int a_iWidth, int a_iHeight, int a_iBit, IntPtr a_pImage, int a_itType);
        public static bool SetImageEx(IntPtr a_hHnd, string a_sName,Bitmap a_Bmp)
        {
            int nWidth = a_Bmp.Width;
            int nHeight = a_Bmp.Height;
            PixelFormat fmt = a_Bmp.PixelFormat;
            int nBits = 24;
            switch (fmt)
            {
                case PixelFormat.Format8bppIndexed:
                    nBits = 8;
                    break;
                case PixelFormat.Format24bppRgb:
                    nBits = 24;
                    break;
                case PixelFormat.Format32bppRgb:
                    nBits = 32;
                    break;
                case PixelFormat.Format32bppArgb:
                    nBits = 32;
                    break;
            }
            BitmapData bmpData = a_Bmp.LockBits(new Rectangle(0, 0, nWidth, nHeight), ImageLockMode.ReadWrite, fmt);
            unsafe
            {
                ZlxgPack.SetImage(a_hHnd, a_sName, nWidth, nHeight, nBits, bmpData.Scan0, 1);
            }
            a_Bmp.UnlockBits(bmpData);
            return true;
        }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpSetPoint")]
        public static extern bool SetPoint(IntPtr a_hHnd,string a_sName,IntPtr value);

        //设置一个对象，可以是string,bitmap,struct,class
        public static bool SetObject(IntPtr a_hHnd, string a_sName, object a_Obj)
        {
            try
            {
                GCHandle hGC = GCHandle.Alloc(a_Obj, GCHandleType.Normal);
                IntPtr hPtr = GCHandle.ToIntPtr(hGC);
                ZlxgPack.SetInt64(a_hHnd, a_sName, hPtr.ToInt64());
            }
            catch
            {
                return false;
            }
            return true;
        }



        [DllImport("ZlxgPack.dll", EntryPoint = "ExpGetByte")]
        public static extern byte GetByteDef(IntPtr a_hHnd,string a_sName,byte a_Def);
        public static byte GetByte(IntPtr a_hHnd, string a_sName) { return GetByteDef(a_hHnd, a_sName, 0); }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpGetWord")]
        public static extern UInt16 GetWordDef(IntPtr a_hHnd,string a_sName,UInt16 a_Def);
        public static UInt16 GetWord(IntPtr a_hHnd, string a_sName) { return GetWordDef(a_hHnd, a_sName, 0); }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpGetDword")]
        public static extern UInt32 GetDwordDef(IntPtr a_hHnd, string a_sName, UInt32 a_Def);
        public static UInt32 GetDword(IntPtr a_hHnd, string a_sName) { return GetDwordDef(a_hHnd, a_sName, 0); }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpGetInt")]
        public static extern int GetIntDef(IntPtr a_hHnd,string a_sName,int a_Def);
        public static int GetInt(IntPtr a_hHnd, string a_sName) { return GetIntDef(a_hHnd, a_sName, 0); }


        public static bool GetBool(IntPtr a_hHnd, string a_sName) { return GetIntDef(a_hHnd, a_sName, 0) != 0; }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpGetFloat")]
        public static extern float GetFloatDef(IntPtr a_hHnd,string a_sName,float aDef);
        public static float GetFloat(IntPtr a_hHnd, string a_sName) { return GetFloatDef(a_hHnd, a_sName, 0); }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpGetDouble")]
        public static extern double GetDoubleDef(IntPtr a_hHnd,string a_sName,double aDef);
        public static double GetDouble(IntPtr a_hHnd, string a_sName) { return GetDoubleDef(a_hHnd, a_sName, 0); }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpGetInt64")]
        public static extern Int64 GetInt64Def(IntPtr a_hHnd,string a_sName,Int64 aDef);
        public static Int64 GetInt64(IntPtr a_hHnd, string a_sName) { return GetInt64Def(a_hHnd, a_sName, 0); }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpGetString")]
        public static extern IntPtr GetString(IntPtr a_hHnd, string a_sName);
        public static string GetStringEx(IntPtr a_hHnd, string a_sName)
        {
            //没有则返回null
            IntPtr hStr = GetString(a_hHnd, a_sName);
            return Marshal.PtrToStringAnsi(hStr);
        }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpGetText")]
        public static extern IntPtr GetText(IntPtr a_hHnd, string a_sName);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpGetBinary")]
        public static extern IntPtr GetBinary(IntPtr a_hHnd, string a_sName, ref int a_iSize);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpGetImage")]
        public static extern IntPtr GetImage(IntPtr a_hHnd,string a_sName,ref CImageDataHeader a_ithImageInfo);
        public static Bitmap GetImageEx(IntPtr a_hHnd,string a_sName)
        {
            if (a_hHnd == null) return null;
            CImageDataHeader head;
            head.m_iHeight = head.m_iWidth = head.m_itType = head.m_iBit = 0;
            IntPtr hBuf = ZlxgPack.GetImage(a_hHnd, a_sName, ref head);
            if (head.m_iHeight == 0 || head.m_iWidth == 0) return null;
            PixelFormat fmt = PixelFormat.Format24bppRgb;
            switch (head.m_iBit)
            {
                case 8:
                    fmt = PixelFormat.Format8bppIndexed;
                    break;
                case 24:
                    fmt = PixelFormat.Format24bppRgb;
                    break;
                case 32:
                    fmt = PixelFormat.Format32bppRgb;
                    break;
            }
            Bitmap bmp = new Bitmap(head.m_iWidth, head.m_iHeight, fmt);
            if (fmt == PixelFormat.Format8bppIndexed)
            {
                ColorPalette tempPalette = bmp.Palette;
                for (int i = 0; i < 256; i++)
                    tempPalette.Entries[i] = Color.FromArgb(i, i, i);
                bmp.Palette = tempPalette;
            }
            BitmapData bmpData = bmp.LockBits(new Rectangle(0, 0, head.m_iWidth, head.m_iHeight), ImageLockMode.WriteOnly, fmt);
            int nLineBytesD = bmpData.Stride;
            int nLineBytesS = nLineBytesD;
            if (head.m_itType == 0)
                nLineBytesS = head.m_iBit * head.m_iWidth / 8;
            int t0 = Environment.TickCount;
            if (nLineBytesD == nLineBytesS)
            {
                unsafe
                {
                    byte* ptrS = (byte*)hBuf;
                    byte* ptrD = (byte*)(bmpData.Scan0);
                    MemCopyPoint((IntPtr)ptrD, (IntPtr)ptrS, head.m_iHeight * nLineBytesS);               
                 }
            }
            else
            {
                unsafe
                {
                    byte* ptrS = (byte*)hBuf;
                    byte* ptrD = (byte*)(bmpData.Scan0);
                    byte* pLineD = ptrD;
                    byte* pLineS = ptrS;
                    for (int i = 0; i < head.m_iHeight; i++)
                    {
                        pLineD = ptrD + nLineBytesD * i;
                        pLineS = ptrS + nLineBytesS * i;
                        MemCopyPoint((IntPtr)pLineD, (IntPtr)pLineS, nLineBytesS);  
                    }
                }
            }
            int t1 = Environment.TickCount - t0;
            bmp.UnlockBits(bmpData);
            bmp.Tag = head.m_itType;
            return bmp;
        }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpGetPoint")]
        public static extern IntPtr GetPointDef(IntPtr a_hHnd,string a_sName,IntPtr aDef);
        public static IntPtr GetPoint(IntPtr a_hHnd, string a_sName) { return GetPointDef(a_hHnd, a_sName, IntPtr.Zero); }


        //获取一个对象，可以是string,bitmap,struct,class
        public static object GetObject(IntPtr a_hHnd, string a_sName)
        {
            IntPtr hPtr = (IntPtr)ZlxgPack.GetInt64(a_hHnd, a_sName);
            if (hPtr == IntPtr.Zero)
                return false;

            GCHandle hGC = GCHandle.FromIntPtr(hPtr);
            object obj = hGC.Target;
            hGC.Free();
            return obj;    
        }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpClear")]
        public static extern bool Clear(IntPtr a_hHnd);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpDelete")]
        public static extern bool Delete(IntPtr a_hHnd,string a_sName);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpGetCount")]
        public static extern int GetCount(IntPtr a_hHnd);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpGetParent")]
        public static extern IntPtr GetParent(IntPtr a_hHnd);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpSetName")]
        public static extern void SetName(IntPtr a_hHnd,string a_sName);


        [DllImport("ZlxgPack.dll",EntryPoint="ExpGetName")]
        public static extern IntPtr GetName(IntPtr a_hHnd);
        public static string GetNameEx(IntPtr a_hHnd)
        {
            if (a_hHnd == IntPtr.Zero)
                return "";
            IntPtr hStr = GetName(a_hHnd);
            return Marshal.PtrToStringAnsi(hStr);
        }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpSetParamDesc")]
        public static extern void SetParamDesc(IntPtr a_hHnd,string a_sName,string a_sDesc);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpCalcDataSize")]
        public static extern int CalcDataSize(IntPtr a_hHnd);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpSaveToBuffer")]
        public static extern bool SaveToBuffer(IntPtr a_hHnd,byte [] a_pBuf,int a_iSize);
        public static byte[] SaveToBufferEx(IntPtr a_hHnd)
        {
            int iSize = CalcDataSize(a_hHnd);
            byte[] a_pBuf = new byte[iSize];
            SaveToBuffer(a_hHnd, a_pBuf, iSize);
            return a_pBuf;
        }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpLoadFromBuffer")]
        public static extern bool LoadFromBuffer(IntPtr a_hHnd,byte [] a_pBuf,int a_iSize);
        public static IntPtr LoadFromBufferEx(byte[] a_pBuf, int a_iSize)
        {
            IntPtr hPack = ZlxgPack.CreateZlxgPack("root");
            if (ZlxgPack.LoadFromBuffer(hPack, a_pBuf, a_iSize))
                return hPack;
            ZlxgPack.DestroyZlxgPack(hPack);
            return IntPtr.Zero;
        }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpSaveToFile")]
        public static extern bool SaveToFile(IntPtr a_hHnd,string a_sFileName);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpLoadFromFile")]
        public static extern bool LoadFromFile(IntPtr a_hHnd,string a_sFileName);
        public static IntPtr LoadFromFileEx(string a_sFileName)
        {
            IntPtr hPack = ZlxgPack.CreateZlxgPack("root");
            if (ZlxgPack.LoadFromFile(hPack, a_sFileName))
                return hPack;
            ZlxgPack.DestroyZlxgPack(hPack);
            return IntPtr.Zero;
        }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpAddChild")]
        public static extern void AddChild(IntPtr a_hHnd,IntPtr a_hChild);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpClearChild")]
        public static extern bool ClearChild(IntPtr a_hHnd);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpDeleteChild")]
        public static extern bool DeleteChild(IntPtr a_hHnd,string a_sName);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpGetChildCount")]
        public static extern int GetChildCount(IntPtr a_hHnd);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpChildBegin")]
        public static extern IntPtr ChildBegin(IntPtr a_hHnd);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpChildNext")]
        public static extern IntPtr ChildNext(IntPtr a_hHnd);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpFindChild")]
        public static extern IntPtr FindChild(IntPtr a_hHnd,string a_sName);

        public static IntPtr FindChildEx(IntPtr a_hHnd, params string[] aNodes)
        {
            IntPtr hNode = a_hHnd;
            for (int i = 0; i < aNodes.Length; i++)
            {
                if (hNode == IntPtr.Zero)
                    break;
                hNode = ZlxgPack.FindChild(hNode, aNodes[i]);
            }
            return hNode;
        }


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpTranZlxgPackToXML")]
        public static extern bool TranZlxgPackToXML(IntPtr a_hHnd,ref char [] a_sOut,ref int a_iLevel,string a_sEncoding);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpTranZlxgPackToXMLEx")]
        public static extern bool TranZlxgPackToXMLEx(IntPtr a_hHnd,char [] a_sOut,ref int a_iLevel,ref bool a_bGetSize,ref int a_iLen,string a_sEncoding);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpCreateInstance")]
        public static extern IntPtr CreateInstance(IntPtr a_hHnd);


        [DllImport("ZlxgPack.dll", EntryPoint = "ExpAssign")]
        public static extern void Assign(IntPtr a_hHnd, IntPtr a_hFrom);


        public static IntPtr AddChild(IntPtr a_hHnd, string a_sName)
        {
            IntPtr hNode = FindChild(a_hHnd, a_sName);
            if (hNode != IntPtr.Zero)
                return hNode;
            hNode = CreateZlxgPack(a_sName);
            AddChild(a_hHnd, hNode);
            return hNode;
        }

        public static Rectangle GetRectangle(IntPtr a_hHnd)
        {
            return new Rectangle(GetInt(a_hHnd, "Left"), GetInt(a_hHnd, "Top"),
                GetInt(a_hHnd, "Width"), GetInt(a_hHnd, "Height"));
        }

        public static bool SetRectangle(IntPtr a_hHnd, Rectangle rect)
        {
            SetInt(a_hHnd, "Left", rect.Left);
            SetInt(a_hHnd, "Top", rect.Top);
            SetInt(a_hHnd, "Width", rect.Width);
            SetInt(a_hHnd, "Height", rect.Height);
            return true;
        }


        public static RectangleF GetRectangleF(IntPtr a_hHnd)
        {
            return new RectangleF(GetFloat(a_hHnd, "Left"), GetFloat(a_hHnd, "Top"),
                GetFloat(a_hHnd, "Width"), GetFloat(a_hHnd, "Height"));
        }


        public static bool SetRectangleF(IntPtr a_hHnd, RectangleF rect)
        {
            SetFloat(a_hHnd, "Left", rect.Left);
            SetFloat(a_hHnd, "Top", rect.Top);
            SetFloat(a_hHnd, "Width", rect.Width);
            SetFloat(a_hHnd, "Height", rect.Height);
            return true;
        }


        public static Rectangle GetRectangleWithChild(IntPtr a_hHnd, string a_sName)
        {
            IntPtr hNode = FindChild(a_hHnd, a_sName);
            if (hNode == IntPtr.Zero)
                return new Rectangle(0,0,0,0);
            return new Rectangle(GetInt(hNode, "Left"), GetInt(hNode, "Top"), 
                GetInt(hNode, "Width"), GetInt(hNode, "Height"));
        }


        public static bool SetRectangleWithChild(IntPtr a_hHnd, string a_sName, Rectangle rect)
        {
            IntPtr hNode = FindChild(a_hHnd, a_sName);
            if (hNode == IntPtr.Zero)
            {
                hNode = CreateZlxgPack(a_sName);
                AddChild(a_hHnd, hNode);
            }
            SetInt(hNode, "Left", rect.Left);
            SetInt(hNode, "Top", rect.Top);
            SetInt(hNode, "Width", rect.Width);
            SetInt(hNode, "Height", rect.Height);
            return true;
        }


        public static RectangleF GetRectangleFWithChild(IntPtr a_hHnd, string a_sName)
        {
            IntPtr hNode = FindChild(a_hHnd, a_sName);
            if (hNode == IntPtr.Zero)
                return new RectangleF(0, 0, 0, 0);
            return new RectangleF(GetFloat(hNode, "Left"), GetFloat(hNode, "Top"),
                GetFloat(hNode, "Width"), GetFloat(hNode, "Height"));
        }


        public static bool SetRectangleFWithChild(IntPtr a_hHnd, string a_sName, RectangleF rect)
        {
            IntPtr hNode = FindChild(a_hHnd, a_sName);
            if (hNode == IntPtr.Zero)
            {
                hNode = CreateZlxgPack(a_sName);
                AddChild(a_hHnd, hNode);
            }
            SetFloat(hNode, "Left", rect.Left);
            SetFloat(hNode, "Top", rect.Top);
            SetFloat(hNode, "Width", rect.Width);
            SetFloat(hNode, "Height", rect.Height);
            return true;
        }


        public static List<T> GetList<T>(IntPtr a_hHnd, string a_sName,out string a_sTag)
        {
            Type tp = typeof(T);
            a_sTag = "";
            IntPtr hNode = FindChild(a_hHnd, a_sName);
            if (hNode == IntPtr.Zero)
                return null;
            int iItemNum = GetInt(hNode, "ItemNum");
            a_sTag = GetStringEx(hNode, "ItemTag");
            if (iItemNum == 0)
                return null;
            List<T> lsResult = new List<T>();
            string sItemType = GetStringEx(hNode, "ItemType");
            if (sItemType == "int" || sItemType == "enum")
            {
                for (int i = 0;i < iItemNum;i++)
                    lsResult.Add((T)(object)GetInt(hNode,i.ToString()));
            }
            if (sItemType == "bool")
            {
                for (int i = 0; i < iItemNum; i++)
                    lsResult.Add((T)(object)GetBool(hNode, i.ToString()));
            }
            else if (sItemType == "string")
            {
                for (int i = 0;i < iItemNum;i++)
                    lsResult.Add((T)(object)GetStringEx(hNode,i.ToString()));
            }
            else if (sItemType == "double")
            {
                for (int i = 0; i < iItemNum; i++)
                    lsResult.Add((T)(object)GetDouble(hNode, i.ToString()));
            }
            else if (sItemType == "Point")
            {
                for (int i = 0; i < iItemNum; i++)
                {
                    int ix = GetInt(hNode, string.Format("X{0}", i));
                    int iy = GetInt(hNode, string.Format("Y{0}", i));
                    lsResult.Add((T)(object)(new Point(ix, iy)));
                }
                    
            }
            else if (sItemType == "PointF")
            {
                for (int i = 0; i < iItemNum; i++)
                {
                    float fx = GetFloat(hNode, string.Format("X{0}", i));
                    float fy = GetFloat(hNode, string.Format("Y{0}", i));
                    lsResult.Add((T)(object)(new PointF(fx, fy)));
                }

            }
            return lsResult;
        }


        public static bool SetList<T>(IntPtr a_hHnd, string a_sName, List<T> a_List,string a_sTag = "")
        {
            Type tp = typeof(T);
            IntPtr hNode = FindChild(a_hHnd, a_sName);
            if (hNode == IntPtr.Zero)
            {
                hNode = CreateZlxgPack(a_sName);
                AddChild(a_hHnd, hNode);
            }
            SetInt(hNode, "ItemNum", a_List.Count);
            SetString(hNode, "ItemTag", a_sTag);
            int idx = 0;
            if (tp.Equals(typeof(int)) || tp.IsEnum)
            {
                SetString(hNode, "ItemType","int");
                foreach (object item in a_List)
                     SetInt(hNode, idx++.ToString(), (int)item);
                return true;
            }
            if (tp.Equals(typeof(bool)))
            {
                SetString(hNode, "ItemType", "bool");
                foreach (object item in a_List)
                    SetBool(hNode, idx++.ToString(), (bool)item);
                return true;
            }
            else if (tp.Equals(typeof(string)))
            {
                SetString(hNode, "ItemType", "string");
                foreach (object item in a_List)
                    SetString(hNode, idx++.ToString(), (string)item);
                return true;
            }
            else if (tp.Equals(typeof(double)))
            {
                SetString(hNode, "ItemType", "double");
                foreach (object item in a_List)
                    SetDouble(hNode, idx++.ToString(), (double)item);
                return true;
            }
            else if (tp.Equals(typeof(Point)))
            {
                SetString(hNode, "ItemType", "Point");
                foreach (object item in a_List)
                {
                    Point pt = (Point)item;
                    SetInt(hNode, string.Format("X{0}", idx), pt.X);
                    SetInt(hNode, string.Format("Y{0}", idx), pt.Y);
                    idx++;
                }
                return true;
            }
            else if (tp.Equals(typeof(PointF)))
            {
                SetString(hNode, "ItemType", "PointF");
                foreach (object item in a_List)
                {
                    PointF pt = (PointF)item;
                    SetFloat(hNode, string.Format("X{0}", idx), pt.X);
                    SetFloat(hNode, string.Format("Y{0}", idx), pt.Y);
                    idx++;
                }
                return true;
            }
            return false;
        }


        public static IntPtr MakeClientPack(string sServerIp, int nServerPort, IntPtr hSendData)
        {
            IntPtr hPack = ZlxgPack.CreateZlxgPack("RequestCommunication");
            ZlxgPack.SetString(hPack, "类型", "发送数据包");
            ZlxgPack.SetInt(hPack, "使用服务器发送", 0);
            ZlxgPack.SetString(hPack, "主机地址", sServerIp);
            ZlxgPack.SetInt(hPack, "端口", nServerPort);
            ZlxgPack.SetPoint(hPack, "数据包地址", hSendData);
            return hPack;
        }


        public static IntPtr MakeConnectServerPack(string sServerIp, int nServerPort)
        {
            IntPtr hPack = ZlxgPack.CreateZlxgPack("RequestCommunication");
            ZlxgPack.SetString(hPack, "类型", "连接服务器");
            ZlxgPack.SetString(hPack, "主机地址", sServerIp);
            ZlxgPack.SetInt(hPack, "端口", nServerPort);
            return hPack;
        }


        public static IntPtr MakeDisconnectServerPack(string sServerIp, int nServerPort)
        {
            IntPtr hPack = ZlxgPack.CreateZlxgPack("RequestCommunication");
            ZlxgPack.SetString(hPack, "类型", "断开与服务器的连接");
            ZlxgPack.SetString(hPack, "主机地址", sServerIp);
            ZlxgPack.SetInt(hPack, "端口", nServerPort);
            return hPack;
        }


        public static IntPtr MakePackFromFile(string sFileName)
        {
            IntPtr hPack = ZlxgPack.CreateZlxgPack("Root");
            ZlxgPack.LoadFromFile(hPack, sFileName);
            return hPack;
        }


        public static IntPtr Clone(IntPtr hPack)
        {
            IntPtr hCopy = ZlxgPack.CreateZlxgPack("Root");
            ZlxgPack.Assign(hCopy, hPack);
            string sName = GetNameEx(hPack);
            SetName(hCopy,sName);
            return hCopy;
        }

        /// <summary>
        /// 把两个包包合并函数
        /// </summary>
        /// <param name="hPack1"></param>
        /// <param name="hPack2"></param>
        /// <param name="bMergeChild"></param>
        /// <returns></returns>
        public static IntPtr Merge(IntPtr hPack1,IntPtr hPack2,bool bMergeChild = false)
        {
            IntPtr hMerge = ZlxgPack.Clone(hPack1);
            object[] objs = ZlxgPack.BeginEx(hPack2);
            while (objs != null)
            {
                string sName = (string)objs[0];
                ZLXG_PACK_DATA_TYPE enumType = (ZLXG_PACK_DATA_TYPE)objs[1];
                object oValue = objs[2];
                switch (enumType)
                {
                    case ZLXG_PACK_DATA_TYPE.DP_BYTE:            // 字节 
                        SetByte(hMerge,sName,(byte)oValue);
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_INT:            // 整形    
                        SetInt(hMerge,sName,(int)oValue);
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_FLOAT:          // 单精度浮点
                        SetFloat(hMerge,sName,(float)oValue);
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_DOUBLE:          // 双精度浮点
                        SetDouble(hMerge,sName,(double)oValue);
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_INT64:          // 八字整数
                        SetInt64(hMerge,sName,(Int64)oValue);
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_STRING:          // 字符串
                        SetString(hMerge,sName,(string)oValue);
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_IMAGE:          // 图像
                        SetImageEx(hMerge,sName,(Bitmap)oValue);
                        break;
                    case ZLXG_PACK_DATA_TYPE.DP_POINT:          // 指针
                        SetPoint(hMerge,sName,(IntPtr)oValue);
                        break;
                }
                objs = ZlxgPack.NextEx(hPack2);
            }
            if (bMergeChild)
            {
                IntPtr hChild = ZlxgPack.ChildBegin(hPack2);
                while (hChild != IntPtr.Zero)
                {
                    IntPtr hChildClone = ZlxgPack.Clone(hChild);
                    ZlxgPack.AddChild(hMerge, hChildClone);
                    hChild = ZlxgPack.ChildNext(hPack2);
                }
            }
            return hMerge;
        }

        /// <summary>
        /// 在节点下，或者iLevel级节点下找某个名称的属性
        /// </summary>
        /// <param name="hPack">包</param>
        /// <param name="sName">属性名称</param>
        /// <param name="iLevel">遍历级别</param>
        /// <returns></returns>
        public static object GetValue(IntPtr hPack,string sName, int iLevel = 0)
        {
            object[] objs = ZlxgPack.BeginEx(hPack);
            while (objs != null)
            {
                if (sName == (string)objs[0])
                    return objs[2];
                objs = ZlxgPack.NextEx(hPack);
            }
            if (iLevel > 0)
            {
                IntPtr hChild = ZlxgPack.ChildBegin(hPack);
                while (hChild != IntPtr.Zero)
                {
                    object oValue = GetValue(hChild, sName, iLevel - 1);
                    if (oValue != null)
                        return oValue;
                    hChild = ZlxgPack.ChildNext(hPack);
                }
            }
            return null;
        }

        /// <summary>
        /// 在0-iLevel级节点下找某个名称和类型相符的属性值
        /// </summary>
        /// <param name="hPack">包</param>
        /// <param name="sName">属性名称</param>
        /// <param name="iLevel">遍历级别</param>
        /// <returns></returns>
        public static T GetValueEx<T>(IntPtr hPack, string sName, T tDefault = default(T),int iLevel = 0)
        {
            object oValue = GetValue(hPack, sName, iLevel);
            if (oValue != null)
            {
                if (oValue.GetType() == typeof(T))
                    return (T)oValue;
            }
            return tDefault;
        }

        public static T GetValueEx<T>(IntPtr hPack, string sName, T tDefault = default(T),params string[] aNodes)
        {
            IntPtr hNode = hPack;
            for (int i = 0; i < aNodes.Length; i++)
            {
                if (hNode == IntPtr.Zero)
                    break;
                hNode = ZlxgPack.FindChild(hNode, aNodes[i]);
            }
            if (hNode == IntPtr.Zero)
                return tDefault;
            object oValue = GetValue(hNode, sName, 0);
            if (oValue != null)
            {
                if (oValue.GetType() == typeof(T))
                    return (T)oValue;
            }
            return tDefault;
        }


        public static void SetValue(IntPtr hPack, string sName, object oValue)
        {
            string sTypeName = oValue.GetType().Name;
            switch (sTypeName)
            {
                case  "Byte":          // 字节 
                    SetByte(hPack, sName, (byte)oValue);
                    break;
                case "Int32":            // 整形    
                    SetInt(hPack, sName, (int)oValue);
                    break;
                case "Single":          // 单精度浮点
                    SetFloat(hPack, sName, (float)oValue);
                    break;
                case "Double":          // 双精度浮点
                    SetDouble(hPack, sName, (double)oValue);
                    break;
                case "Int64":          // 八字整数
                    SetInt64(hPack, sName, (Int64)oValue);
                    break;
                case "String":          // 字符串
                    SetString(hPack, sName, (string)oValue);
                    break;
                case "Bitmap":          // 图像
                    SetImageEx(hPack, sName, (Bitmap)oValue);
                    break;
                case "IntPtr":          // 指针
                    SetPoint(hPack, sName, (IntPtr)oValue);
                    break;
            }
        }

        public static void SetValueT<T>(IntPtr hPack, string sName, T tValue)
        {
            object oValue = (object)tValue;
            SetValue(hPack, sName, oValue);
        }

        public static void SetValueEx<T>(IntPtr hPack, string sName, T tValue, params string[] aNodes)
        {
            IntPtr hNode = hPack;
            for (int i = 0; i < aNodes.Length; i++)
                hNode = ZlxgPack.AddChild(hNode, aNodes[i]);
            ZlxgPack.SetValue(hNode, sName, tValue);
        }


    }
}
